<?php
/**
 * Hello Elementor Child Theme functions and definitions.
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'HELLO_CHILD_VERSION', '3.0.12' );
define( 'HELLO_CHILD_DIR', get_stylesheet_directory() );
define( 'HELLO_CHILD_URI', get_stylesheet_directory_uri() );

/**
 * 부모 + 자식 테마 스타일시트 로드
 */
function hello_child_enqueue_styles() {
	// Pretendard — dynamic subset (사용된 글자만 로드)
	wp_enqueue_style(
		'pretendard',
		'https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard-dynamic-subset.min.css',
		[],
		null
	);

	wp_enqueue_style(
		'hello-elementor-parent',
		get_template_directory_uri() . '/style.css',
		[ 'pretendard' ],
		HELLO_CHILD_VERSION
	);

	wp_enqueue_style(
		'hello-elementor-child',
		HELLO_CHILD_URI . '/style.css',
		[ 'hello-elementor-parent' ],
		HELLO_CHILD_VERSION
	);

	wp_enqueue_style(
		'hello-child-global',
		HELLO_CHILD_URI . '/assets/css/global.css',
		[ 'hello-elementor-child' ],
		HELLO_CHILD_VERSION
	);

	wp_enqueue_style(
		'hello-child-custom',
		HELLO_CHILD_URI . '/assets/css/custom.css',
		[ 'hello-child-global' ],
		HELLO_CHILD_VERSION . '.' . filemtime( HELLO_CHILD_DIR . '/assets/css/custom.css' )
	);

}

/**
 * Pretendard CDN — preconnect로 DNS 선점 (로딩 최적화)
 */
function hello_child_preconnect_pretendard() {
	echo '<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>' . "\n";
}
add_action( 'wp_head', 'hello_child_preconnect_pretendard', 1 );
add_action( 'wp_enqueue_scripts', 'hello_child_enqueue_styles' );

/**
 * 싱글 포스트 CSS — 부모 테마/Elementor CSS 뒤에 로드 (우선순위 99)
 */
function hello_child_enqueue_single_post_styles() {
	if ( is_singular( 'post' ) ) {
		wp_enqueue_style(
			'hello-child-single-post',
			HELLO_CHILD_URI . '/assets/css/single-post.css',
			[ 'hello-child-custom' ],
			HELLO_CHILD_VERSION
		);
	}
}
add_action( 'wp_enqueue_scripts', 'hello_child_enqueue_single_post_styles', 99 );

/**
 * Home v2 CSS — 동적 숏코드 (courses / freepdf / blog) 가 사용되는 페이지에서만 로드.
 *
 * @since 3.0.0
 */
function hello_child_enqueue_home_v2_styles() {
	$should_load = is_front_page() || is_home();

	if ( ! $should_load ) {
		global $post;
		if ( $post instanceof WP_Post ) {
			$content = $post->post_content;
			$thv2_shortcodes = array(
				'terra_home_v2',
				'terra_home_v2_hero',
				'terra_home_v2_stats',
				'terra_home_v2_problem',
				'terra_home_v2_solution',
				'terra_home_v2_roadmap',
				'terra_home_v2_faq',
				'terra_home_v2_final_cta',
				'terra_courses_grid',
				'terra_freepdf_cta',
				'terra_blog_grid',
			);
			foreach ( $thv2_shortcodes as $sc ) {
				if ( has_shortcode( $content, $sc ) ) {
					$should_load = true;
					break;
				}
			}
		}
	}

	if ( ! $should_load ) {
		return;
	}

	wp_enqueue_style(
		'hello-child-home-v2',
		HELLO_CHILD_URI . '/assets/css/home-v2.css',
		array( 'hello-child-custom' ),
		HELLO_CHILD_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'hello_child_enqueue_home_v2_styles', 99 );

/**
 * terms / privacy 페이지에 body 클래스 추가 (슬러그 기반)
 */
function hello_child_legal_body_class( $classes ) {
	if ( is_page( array( 'terms', 'privacy' ) ) ) {
		$classes[] = 'hc-legal-page';
	}
	return $classes;
}
add_filter( 'body_class', 'hello_child_legal_body_class' );

/**
 * Shop 페이지 CSS — Woodmart 스타일 상품 그리드 (우선순위 99)
 */
function hello_child_enqueue_shop_styles() {
	$pg_shop_page = get_page_by_path( 'pg-shop' );
	$is_pg_shop   = $pg_shop_page && is_page( $pg_shop_page->ID );
	if ( function_exists( 'is_shop' ) && ( is_shop() || is_product_category() || is_product_tag() || $is_pg_shop ) ) {
		wp_enqueue_style(
			'hello-child-shop',
			HELLO_CHILD_URI . '/assets/css/shop.css',
			[ 'hello-child-custom' ],
			HELLO_CHILD_VERSION
		);
	}
}
add_action( 'wp_enqueue_scripts', 'hello_child_enqueue_shop_styles', 99 );

/**
 * 싱글 프로덕트 CSS/JS — Swiper + 커스텀 레이아웃 (우선순위 99)
 */
function hello_child_enqueue_single_product_assets() {
	if ( ! is_singular( 'product' ) ) {
		return;
	}

	// Swiper CDN
	wp_enqueue_style(
		'swiper',
		'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css',
		[],
		'11.0.0'
	);
	wp_enqueue_script(
		'swiper',
		'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js',
		[],
		'11.0.0',
		true
	);

	// 싱글 프로덕트 스타일
	wp_enqueue_style(
		'hello-child-single-product',
		HELLO_CHILD_URI . '/assets/css/single-product.css',
		[ 'hello-child-custom', 'swiper' ],
		HELLO_CHILD_VERSION
	);

	// 싱글 프로덕트 스크립트
	wp_enqueue_script(
		'hello-child-single-product',
		HELLO_CHILD_URI . '/assets/js/single-product.js',
		[ 'swiper' ],
		HELLO_CHILD_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'hello_child_enqueue_single_product_assets', 99 );

/**
 * 싱글 프로덕트 — 장바구니 버튼 텍스트 변경 (바로구매 → 장바구니 담기)
 */
add_filter( 'woocommerce_product_single_add_to_cart_text', 'hello_child_single_cart_btn_text', 9999 );
function hello_child_single_cart_btn_text( $text ) {
	return '장바구니 담기';
}

/**
 * 싱글 프로덕트 — WooCommerce 기본 브레드크럼 제거 (사이드바에 별도 표시)
 */
add_action( 'wp', 'hello_child_remove_wc_breadcrumb' );
function hello_child_remove_wc_breadcrumb() {
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
}

/**
 * 부모 테마 콘텐츠 너비 제한 해제 — 전체너비 레이아웃
 */
function hello_child_content_width() {
	$GLOBALS['content_width'] = 1920;
}
add_action( 'after_setup_theme', 'hello_child_content_width', 1 );

/**
 * 커스텀 JS 로드
 */
function hello_child_enqueue_scripts() {
	wp_enqueue_script(
		'hello-child-custom',
		HELLO_CHILD_URI . '/assets/js/custom.js',
		[],
		HELLO_CHILD_VERSION,
		true
	);

	if ( is_singular( 'post' ) ) {
		wp_enqueue_script(
			'hello-child-single-toc',
			HELLO_CHILD_URI . '/assets/js/single-toc.js',
			[],
			HELLO_CHILD_VERSION,
			true
		);
	}
}
add_action( 'wp_enqueue_scripts', 'hello_child_enqueue_scripts' );

/**
 * includes 파일 로드
 */
require_once HELLO_CHILD_DIR . '/includes/hooks.php';
require_once HELLO_CHILD_DIR . '/includes/helpers.php';
require_once HELLO_CHILD_DIR . '/includes/meta-boxes.php';
require_once HELLO_CHILD_DIR . '/includes/auto-content.php';
require_once HELLO_CHILD_DIR . '/includes/dashboard.php';
require_once HELLO_CHILD_DIR . '/includes/shortcode-home.php';
require_once HELLO_CHILD_DIR . '/includes/shortcode-home-v2.php';
require_once HELLO_CHILD_DIR . '/includes/class-theme-setup.php';
Hello_Child_Theme_Setup::init();


/**
 * Open Graph + Twitter Card 메타 태그 (GEO 최적화)
 * 핵심 답변 메타박스 데이터를 description으로 사용
 */
add_action( 'wp_head', 'hello_child_og_meta_tags', 5 );
function hello_child_og_meta_tags() {
	if ( ! is_singular( 'post' ) ) {
		return;
	}

	$post_id     = get_the_ID();
	$title       = get_the_title();
	$url         = get_permalink();
	$key_answer  = get_post_meta( $post_id, '_hello_child_key_answer', true );
	$description = $key_answer ? $key_answer : wp_trim_words( get_the_excerpt(), 30, '...' );
	$thumb_url   = get_the_post_thumbnail_url( $post_id, 'full' );
	$site_name   = get_bloginfo( 'name' );

	echo '<meta property="og:type" content="article">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( $site_name ) . '">' . "\n";
	if ( $thumb_url ) {
		echo '<meta property="og:image" content="' . esc_url( $thumb_url ) . '">' . "\n";
	}
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta name="twitter:description" content="' . esc_attr( $description ) . '">' . "\n";
	if ( $thumb_url ) {
		echo '<meta name="twitter:image" content="' . esc_url( $thumb_url ) . '">' . "\n";
	}
}

/**
 * 구텐베르크 비활성화 — 클래식 에디터로 글 작성
 * (post 타입만 비활성화, page는 Elementor 사용 가능)
 */
add_filter( 'use_block_editor_for_post_type', 'hello_child_disable_gutenberg', 10, 2 );
function hello_child_disable_gutenberg( $use, $post_type ) {
	if ( 'post' === $post_type || 'page' === $post_type ) {
		return false;
	}
	return $use;
}

/**
 * 모든 페이지에서 상단 타이틀 비활성화
 */
add_filter( 'hello_elementor_page_title', '__return_false' );

/**
 * 커스텀 Elementor 위젯 등록
 */
function hello_child_register_widgets( $widgets_manager ) {
	$widget_files = glob( HELLO_CHILD_DIR . '/widgets/*.php' );

	foreach ( $widget_files as $file ) {
		require_once $file;
	}
}
add_action( 'elementor/widgets/register', 'hello_child_register_widgets' );
