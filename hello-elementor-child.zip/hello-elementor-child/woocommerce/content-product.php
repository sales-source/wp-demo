<?php
/**
 * 상품 카드 템플릿 — Woodmart 스타일
 *
 * 호버 시 info 영역이 위로 슬라이드하며 바로구매 버튼 노출
 *
 * @package HelloElementorChild
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ) {
	return;
}

// 할인율 계산
$discount_pct = '';
if ( $product->is_on_sale() ) {
	$regular = (float) $product->get_regular_price();
	$sale    = (float) $product->get_sale_price();
	if ( $regular > 0 && $sale > 0 ) {
		$discount_pct = '-' . round( ( ( $regular - $sale ) / $regular ) * 100 ) . '%';
	}
}

$permalink = get_permalink( $product->get_id() );
?>
<li <?php wc_product_class( 'hc-product-card', $product ); ?>>
	<div class="hc-product-card__inner">
		<!-- 이미지 영역 (클릭 시 상품 상세) -->
		<div class="hc-product-card__image-wrap">
			<a href="<?php echo esc_url( $permalink ); ?>" class="hc-product-card__image-link">
				<?php echo $product->get_image( 'woocommerce_thumbnail', [ 'class' => 'hc-product-card__img' ] ); ?>
			</a>

			<?php if ( $discount_pct ) : ?>
				<span class="hc-product-card__badge"><?php echo esc_html( $discount_pct ); ?></span>
			<?php endif; ?>
		</div>

		<!-- 상품 정보 + 호버 바로구매 -->
		<div class="hc-product-card__info">
			<a href="<?php echo esc_url( $permalink ); ?>" class="hc-product-card__title-link">
				<h2 class="hc-product-card__title"><?php echo get_the_title(); ?></h2>
			</a>

			<div class="hc-product-card__price">
				<?php echo $product->get_price_html(); ?>
			</div>

			<!-- 호버 시 위로 밀려 올라오는 바로구매 버튼 -->
			<div class="hc-product-card__actions">
				<?php
				if ( $product->is_purchasable() && $product->is_in_stock() ) {
					$buy_now_url = add_query_arg( [
						'add-to-cart' => $product->get_id(),
						'quantity'    => 1,
						'buy_now'     => 1,
					], wc_get_checkout_url() );
					printf(
						'<a href="%s" class="hc-product-card__buy-now">%s</a>',
						esc_url( $buy_now_url ),
						'바로 구매'
					);
				} else {
					printf(
						'<a href="%s" class="hc-product-card__buy-now hc-product-card__buy-now--disabled">%s</a>',
						esc_url( $permalink ),
						'자세히 보기'
					);
				}
				?>
			</div>
		</div>
	</div>
</li>
