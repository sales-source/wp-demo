<?php
/**
 * 싱글 프로덕트 상세 페이지 — 와디즈 스타일 레이아웃
 *
 * 좌측: 대표 이미지 + 갤러리 + 탭(상세/리뷰)
 * 우측: sticky 위젯 (상품명, 가격, [공유+바로구매], 배송/환불)
 *
 * @package HelloElementorChild
 * @version 4.2.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form();
	return;
}

$gallery_ids   = $product->get_gallery_image_ids();
$thumbnail_id  = $product->get_image_id();
$gallery_ids   = array_diff( $gallery_ids, [ $thumbnail_id ] );
$has_gallery   = ! empty( $gallery_ids );

$regular_price = (float) $product->get_regular_price();
$sale_price    = (float) $product->get_sale_price();
$discount_pct  = 0;
if ( $product->is_on_sale() && $regular_price > 0 ) {
	$discount_pct = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
}

$is_virtual      = $product->is_virtual();
$shipping_cost   = get_post_meta( $product->get_id(), '_sp_shipping_cost', true ) ?: '무료배송';
$shipping_period = get_post_meta( $product->get_id(), '_sp_shipping_period', true ) ?: '결제 후 2~5일 이내 출고';
$service_period  = get_post_meta( $product->get_id(), '_sp_service_period', true ) ?: '결제 즉시 이용 가능';
$refund_policy   = get_post_meta( $product->get_id(), '_sp_refund_policy', true )
	?: ( $is_virtual
		? "결제 후 7일 이내 환불 가능 (미수강 시)\n수강 시작 후에는 환불 불가\n콘텐츠 특성상 부분 환불 불가"
		: "수령 후 7일 이내 교환/반품 가능\n제품 하자 시 배송비 판매자 부담\n단순 변심 시 왕복 배송비 구매자 부담\n사용 흔적이 있는 경우 반품 불가" );

$review_count = $product->get_review_count();

// freepdf 카테고리 판별
$is_freepdf = function_exists( 'hello_child_is_free_download' ) && hello_child_is_free_download( $product );
?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'sp-wadiz', $product ); ?>>

	<section class="sp-top">
		<div class="sp-top__inner">

			<!-- ── 좌측: 이미지 + 탭(상세/리뷰) ── -->
			<div class="sp-main">
				<?php // 대표 이미지 (16:9 비율 + 좌우 화살표) ?>
				<div class="sp-gallery__featured">
					<div class="sp-gallery__featured-ratio">
						<?php if ( $thumbnail_id ) : ?>
							<?php echo wp_get_attachment_image( $thumbnail_id, 'woocommerce_single', false, [
								'class' => 'sp-gallery__featured-img',
								'id'    => 'sp-featured-img',
							] ); ?>
						<?php else : ?>
							<div class="sp-gallery__placeholder">
								<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#B0B8C1" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
							</div>
						<?php endif; ?>

						<?php if ( $has_gallery ) : ?>
							<button type="button" class="sp-gallery__arrow sp-gallery__arrow--prev" aria-label="이전 이미지">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
							</button>
							<button type="button" class="sp-gallery__arrow sp-gallery__arrow--next" aria-label="다음 이미지">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
							</button>
						<?php endif; ?>
					</div>
				</div>

				<?php if ( $has_gallery ) : ?>
					<div class="sp-gallery__carousel">
						<div class="swiper sp-gallery-swiper">
							<div class="swiper-wrapper">
								<?php if ( $thumbnail_id ) : ?>
									<div class="swiper-slide">
										<button type="button" class="sp-gallery__thumb is-active" data-img-id="<?php echo esc_attr( $thumbnail_id ); ?>">
											<?php echo wp_get_attachment_image( $thumbnail_id, 'thumbnail', false, [ 'class' => 'sp-gallery__thumb-img' ] ); ?>
										</button>
									</div>
								<?php endif; ?>
								<?php foreach ( $gallery_ids as $gid ) : ?>
									<div class="swiper-slide">
										<button type="button" class="sp-gallery__thumb" data-img-id="<?php echo esc_attr( $gid ); ?>">
											<?php echo wp_get_attachment_image( $gid, 'thumbnail', false, [ 'class' => 'sp-gallery__thumb-img' ] ); ?>
										</button>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				<?php endif; ?>

				<?php // ── 탭 네비게이션 ── ?>
				<nav class="sp-tabs" id="sp-tabs">
					<button type="button" class="sp-tabs__btn is-active" data-tab="detail">상세 설명</button>
					<button type="button" class="sp-tabs__btn" data-tab="reviews">리뷰 (<?php echo esc_html( $review_count ); ?>)</button>
				</nav>

				<?php // ── 탭 패널: 상세 설명 ── ?>
				<div class="sp-panel is-active" id="sp-panel-detail">

					<?php
					// ── 메타 데이터 로드 ──
					$sp_why        = get_post_meta( $product->get_id(), '_sp_why', true );
					$sp_benefits   = get_post_meta( $product->get_id(), '_sp_benefits', true );
					$sp_targets    = get_post_meta( $product->get_id(), '_sp_targets', true );
					$sp_curriculum = get_post_meta( $product->get_id(), '_sp_curriculum', true );
					$sp_instructor = get_post_meta( $product->get_id(), '_sp_instructor', true );
					$sp_faq        = get_post_meta( $product->get_id(), '_sp_faq', true );

					$has_why        = is_array( $sp_why ) && ! empty( $sp_why['title'] );
					$has_benefits   = is_array( $sp_benefits ) && ! empty( $sp_benefits );
					$has_targets    = is_array( $sp_targets ) && array_filter( $sp_targets, function( $t ) { return ! empty( $t['text'] ); } );
					$has_curriculum = is_array( $sp_curriculum ) && array_filter( $sp_curriculum, function( $s ) { return ! empty( $s['title'] ) || ! empty( $s['items'] ); } );
					$has_instructor = is_array( $sp_instructor ) && ! empty( $sp_instructor['name'] );
					$has_faq        = is_array( $sp_faq ) && array_filter( $sp_faq, function( $f ) { return ! empty( $f['q'] ); } );
					?>

					<?php // ── 왜 이 강의인가요? ── ?>
					<?php if ( $has_why ) : ?>
						<section class="sp-section sp-section--why">
							<span class="sp-section__label">WHO IS THIS FOR</span>
							<h2 class="sp-section__title"><?php echo $is_freepdf ? '왜 이 콘텐츠인가요?' : '왜 이 강의인가요?'; ?></h2>
							<h3 class="sp-why__headline"><?php echo esc_html( $sp_why['title'] ); ?></h3>
							<p class="sp-why__body"><?php echo nl2br( esc_html( $sp_why['body'] ) ); ?></p>
						</section>
					<?php endif; ?>

					<?php // ── WHAT YOU GET ── ?>
					<?php if ( $has_benefits ) : ?>
						<section class="sp-section sp-section--benefits">
							<span class="sp-section__label">WHAT YOU GET</span>
							<div class="sp-benefits-grid">
								<?php foreach ( $sp_benefits as $benefit ) :
									if ( empty( $benefit['title'] ) ) continue;
									$icon = $benefit['icon'] ?? 'play-circle';
								?>
									<div class="sp-benefit-card">
										<div class="sp-benefit-card__icon">
											<?php echo hello_child_get_feather_icon( $icon ); ?>
										</div>
										<div class="sp-benefit-card__content">
											<h3 class="sp-benefit-card__title"><?php echo esc_html( $benefit['title'] ); ?></h3>
											<?php if ( ! empty( $benefit['desc'] ) ) : ?>
												<p class="sp-benefit-card__desc"><?php echo esc_html( $benefit['desc'] ); ?></p>
											<?php endif; ?>
										</div>
									</div>
								<?php endforeach; ?>
							</div>
						</section>
					<?php endif; ?>

					<?php // ── 본문 (the_content) — 메타에 없는 추가 내용용 ── ?>
					<?php
					$content = get_the_content();
					if ( trim( strip_tags( $content ) ) ) {
						the_content();
					}
					?>

					<?php // ── 누구를 위한 강의인가 ── ?>
					<?php if ( $has_targets ) : ?>
						<section class="sp-section sp-section--target">
							<span class="sp-section__label">WHO IS THIS FOR</span>
							<h2 class="sp-section__title"><?php echo $is_freepdf ? '이런 분들을 위한 콘텐츠입니다.' : '이런 분께 꼭 맞는 강의입니다.'; ?></h2>
							<div class="sp-target-columns">
								<?php foreach ( $sp_targets as $target ) :
									if ( empty( $target['text'] ) ) continue;
									$img_html = '';
									if ( ! empty( $target['img_id'] ) ) {
										$img_html = wp_get_attachment_image( $target['img_id'], 'medium', false, [ 'class' => 'sp-target-col__img' ] );
									}
								?>
									<div class="sp-target-col">
										<?php if ( $img_html ) : ?>
											<div class="sp-target-col__image"><?php echo $img_html; ?></div>
										<?php endif; ?>
										<h3 class="sp-target-col__text"><?php echo esc_html( $target['text'] ); ?></h3>
									</div>
								<?php endforeach; ?>
							</div>
						</section>
					<?php endif; ?>

					<?php // ── 커리큘럼 ── ?>
					<?php if ( $has_curriculum ) :
						$lesson_num = 1;
					?>
						<section class="sp-section sp-section--curriculum">
							<span class="sp-section__label">CURRICULUM</span>
							<h2 class="sp-section__title"><?php echo $is_freepdf ? '목차' : '커리큘럼'; ?></h2>
							<div class="sp-curriculum-list">
								<?php foreach ( $sp_curriculum as $section ) :
									if ( empty( $section['title'] ) && empty( $section['items'] ) ) continue;
									$items = isset( $section['items'] ) && is_array( $section['items'] ) ? $section['items'] : array();
								?>
									<?php foreach ( $items as $item ) :
										if ( empty( $item['title'] ) ) continue;
									?>
										<div class="sp-faq-item sp-curriculum-item is-open">
											<div class="sp-faq-item__question">
												<span class="sp-faq-item__label"><?php echo $is_freepdf ? esc_html( $lesson_num ) . '장' : esc_html( $lesson_num ) . '강'; ?></span>
												<span><?php echo esc_html( $item['title'] ); ?></span>
											</div>
											<?php if ( ! empty( $item['desc'] ) ) : ?>
												<div class="sp-faq-item__answer">
													<p><?php echo esc_html( $item['desc'] ); ?></p>
												</div>
											<?php endif; ?>
										</div>
									<?php $lesson_num++; endforeach; ?>
								<?php endforeach; ?>
							</div>
						</section>
					<?php endif; ?>

					<?php // ── 강사 소개 ── ?>
					<?php if ( $has_instructor ) : ?>
						<section class="sp-section sp-section--instructor">
							<span class="sp-section__label">INSTRUCTOR</span>
							<h2 class="sp-section__title"><?php echo $is_freepdf ? '저자 소개' : '강사 소개'; ?></h2>
							<div class="sp-instructor-card">
								<?php if ( ! empty( $sp_instructor['photo_id'] ) ) : ?>
									<div class="sp-instructor-card__photo">
										<?php echo wp_get_attachment_image( $sp_instructor['photo_id'], 'medium', false, [ 'class' => 'sp-instructor-card__img' ] ); ?>
									</div>
								<?php endif; ?>
								<div class="sp-instructor-card__info">
									<h3 class="sp-instructor-card__name"><?php echo esc_html( $sp_instructor['name'] ); ?></h3>
									<?php if ( ! empty( $sp_instructor['title'] ) ) : ?>
										<p class="sp-instructor-card__title"><?php echo esc_html( $sp_instructor['title'] ); ?></p>
									<?php endif; ?>
									<?php if ( ! empty( $sp_instructor['bio'] ) ) : ?>
										<p class="sp-instructor-card__bio"><?php echo nl2br( esc_html( $sp_instructor['bio'] ) ); ?></p>
									<?php endif; ?>
									<?php if ( ! empty( $sp_instructor['tags'] ) ) : ?>
										<div class="sp-instructor-card__tags">
											<?php foreach ( explode( ',', $sp_instructor['tags'] ) as $tag ) :
												$tag = trim( $tag );
												if ( $tag ) : ?>
													<span class="sp-instructor-card__tag"><?php echo esc_html( $tag ); ?></span>
											<?php endif; endforeach; ?>
										</div>
									<?php endif; ?>
								</div>
							</div>
						</section>
					<?php endif; ?>

					<?php // ── FAQ ── ?>
					<?php if ( $has_faq ) : ?>
						<section class="sp-section sp-section--faq">
							<span class="sp-section__label">FAQ</span>
							<h2 class="sp-section__title">자주 묻는 질문</h2>
							<div class="sp-faq-list">
								<?php foreach ( $sp_faq as $faq ) :
									if ( empty( $faq['q'] ) ) continue;
								?>
									<div class="sp-faq-item is-open">
										<div class="sp-faq-item__question">
											<span class="sp-faq-item__label">Q.</span>
											<span><?php echo esc_html( $faq['q'] ); ?></span>
										</div>
										<div class="sp-faq-item__answer">
											<span class="sp-faq-item__label sp-faq-item__label--a">A.</span>
											<p><?php echo nl2br( esc_html( $faq['a'] ) ); ?></p>
										</div>
									</div>
								<?php endforeach; ?>
							</div>
						</section>
					<?php endif; ?>
				</div>

				<?php // ── 탭 패널: 리뷰 ── ?>
				<div class="sp-panel" id="sp-panel-reviews">
					<?php comments_template(); ?>
				</div>
			</div>

			<!-- ── 우측: sticky 사이드바 ── -->
			<aside class="sp-sidebar">
				<div class="sp-sidebar__widget">

					<h1 class="sp-sidebar__title"><?php the_title(); ?></h1>

					<?php if ( $thumbnail_id ) : ?>
						<?php echo wp_get_attachment_image( $thumbnail_id, 'woocommerce_single', false, [
							'class' => 'sp-sidebar__thumb-mobile',
						] ); ?>
					<?php endif; ?>

					<?php if ( $product->get_short_description() ) : ?>
						<p class="sp-sidebar__excerpt"><?php echo wp_strip_all_tags( $product->get_short_description() ); ?></p>
					<?php endif; ?>

					<div class="sp-sidebar__price-block">
						<?php if ( $is_freepdf ) : ?>
							<div class="sp-sidebar__prices sp-sidebar__prices--freepdf">
								<?php if ( $regular_price > 0 ) : ?>
									<span class="sp-sidebar__original-price"><del><?php echo wp_kses_post( wc_price( $regular_price ) ); ?></del></span>
								<?php endif; ?>
								<span class="sp-sidebar__current-price sp-sidebar__current-price--free">무료</span>
							</div>
						<?php else : ?>
							<?php if ( $product->is_on_sale() && $discount_pct > 0 ) : ?>
								<span class="sp-sidebar__discount"><?php echo esc_html( $discount_pct ); ?>%</span>
							<?php endif; ?>
							<div class="sp-sidebar__prices">
								<span class="sp-sidebar__current-price"><?php echo wp_kses_post( wc_price( $product->get_price() ) ); ?></span>
								<?php if ( $product->is_on_sale() ) : ?>
									<span class="sp-sidebar__original-price"><?php echo wp_kses_post( wc_price( $regular_price ) ); ?></span>
								<?php endif; ?>
							</div>
						<?php endif; ?>
					</div>

					<?php // ── 액션 행: [공유] + [바로구매] 한 줄 ── ?>
					<div class="sp-sidebar__actions">
						<button type="button" class="sp-action-share" id="sp-share-toggle" aria-label="공유하기">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
						</button>
						<?php if ( $is_freepdf ) : ?>
							<div class="sp-sidebar__cart sp-sidebar__cart--freepdf">
								<?php if ( is_user_logged_in() ) : ?>
									<a href="<?php echo esc_url( add_query_arg( 'freepdf', $product->get_id(), home_url( '/freepdf-download/' ) ) ); ?>" class="sp-freepdf-btn sp-freepdf-btn--download">
										<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
										무료 신청
									</a>
								<?php else : ?>
									<?php
									$freepdf_redirect = add_query_arg( 'freepdf', $product->get_id(), home_url( '/freepdf-download/' ) );
									$kakao_login_url  = add_query_arg( 'redirect', urlencode( $freepdf_redirect ), home_url( '/klogin' ) );
									?>
									<a href="<?php echo esc_url( $kakao_login_url ); ?>" class="sp-freepdf-btn sp-freepdf-btn--kakao">
										<svg width="20" height="20" viewBox="0 0 256 256"><path fill="#3C1E1E" d="M128 36C70.562 36 24 72.713 24 118c0 29.279 19.466 54.97 48.748 69.477-1.593 5.494-10.237 35.344-10.581 37.689 0 0-.207 1.762.934 2.434s2.483.15 2.483.15c3.272-.457 37.943-24.811 43.944-29.03 5.995.849 12.168 1.28 18.472 1.28 57.438 0 104-36.712 104-82c0-45.287-46.562-82-104-82"/></svg>
										카카오 로그인 후 다운로드
									</a>
								<?php endif; ?>
							</div>
						<?php else : ?>
							<div class="sp-sidebar__cart">
								<?php woocommerce_template_single_add_to_cart(); ?>
							</div>
						<?php endif; ?>
					</div>

					<?php // ── 공유 팝업 ── ?>
					<div class="sp-share-popup" id="sp-share-popup">
						<div class="sp-share-popup__header">
							<span class="sp-share-popup__title">공유하기</span>
							<button type="button" class="sp-share-popup__close" id="sp-share-close" aria-label="닫기">
								<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
							</button>
						</div>
						<div class="sp-share-popup__body">
							<button type="button" class="sp-share-option" id="sp-share-kakao" aria-label="카카오톡">
								<span class="sp-share-option__icon sp-share-option__icon--kakao">
									<svg width="22" height="22" viewBox="0 0 256 256"><path fill="#3C1E1E" d="M128 36C70.562 36 24 72.713 24 118c0 29.279 19.466 54.97 48.748 69.477-1.593 5.494-10.237 35.344-10.581 37.689 0 0-.207 1.762.934 2.434s2.483.15 2.483.15c3.272-.457 37.943-24.811 43.944-29.03 5.995.849 12.168 1.28 18.472 1.28 57.438 0 104-36.712 104-82c0-45.287-46.562-82-104-82"/></svg>
								</span>
							</button>
							<button type="button" class="sp-share-option" id="sp-share-threads" aria-label="쓰레드">
								<span class="sp-share-option__icon sp-share-option__icon--threads">
									<svg width="22" height="22" viewBox="0 0 24 24" fill="#000000"><path d="M12.186 24h-.007c-3.581-.024-6.334-1.205-8.184-3.509C2.35 18.44 1.5 15.586 1.472 12.01v-.017c.03-3.579.879-6.43 2.525-8.482C5.845 1.205 8.6.024 12.18 0h.014c2.746.02 5.043.725 6.826 2.098 1.677 1.29 2.858 3.13 3.509 5.467l-2.04.569c-1.104-3.96-3.898-5.984-8.304-6.015-2.91.022-5.11.936-6.54 2.717C4.307 6.504 3.616 8.914 3.59 12c.025 3.086.718 5.496 2.057 7.164 1.432 1.781 3.632 2.695 6.54 2.717 2.227-.02 4.03-.6 5.362-1.725 1.483-1.252 2.235-3.082 2.235-5.438 0-1.207-.333-2.18-1.003-2.895-.636-.68-1.527-1.07-2.604-1.158a4.68 4.68 0 0 1 .462 1.56c.388.156.705.4.944.726.39.53.586 1.238.586 2.098 0 .993-.217 1.903-.645 2.702a4.862 4.862 0 0 1-1.857 1.903c-.82.476-1.79.718-2.883.718-1.296 0-2.383-.405-3.23-1.205-.83-.784-1.27-1.86-1.307-3.2-.03-1.09.248-2.09.826-2.972.567-.863 1.382-1.563 2.422-2.08a13.856 13.856 0 0 1-.183-1.715l.004-.2c.027-1.178.343-2.126.94-2.822.627-.73 1.508-1.1 2.619-1.1 1.627 0 2.614.98 3.088 1.903a8.352 8.352 0 0 1 .485 1.202c1.358.26 2.49.88 3.338 1.838.987 1.114 1.488 2.572 1.488 4.33 0 2.868-.95 5.17-2.822 6.84-1.737 1.548-4.058 2.36-6.9 2.383zM9.77 15.103c.024.88.28 1.553.762 2.004.49.46 1.15.69 1.96.69.694 0 1.313-.15 1.84-.45a2.927 2.927 0 0 0 1.158-1.228c.268-.502.403-1.06.403-1.66 0-1.367-.598-2.095-1.78-2.168a7.042 7.042 0 0 0-.57-.01c-1.073.06-1.94.4-2.578 1.012-.614.587-.94 1.304-.957 2.13l-.002.058-.003.052c0 .086-.01.237-.032.456zm3.39-5.51c-.327-.834-.88-1.283-1.694-1.283-.593 0-1.063.205-1.397.61-.328.396-.506.963-.528 1.685a10.202 10.202 0 0 0 .096 1.038 7.966 7.966 0 0 1 2.39-.846c.26-.09.498-.168.713-.24a5.59 5.59 0 0 0-.343-.727l-.003-.004-.002-.005z"/></svg>
								</span>
							</button>
							<button type="button" class="sp-share-option" id="sp-share-facebook" aria-label="페이스북">
								<span class="sp-share-option__icon sp-share-option__icon--facebook">
									<svg width="22" height="22" viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
								</span>
							</button>
							<button type="button" class="sp-share-option" id="sp-share-instagram" aria-label="인스타그램">
								<span class="sp-share-option__icon sp-share-option__icon--instagram">
									<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><defs><linearGradient id="ig-grad" x1="0%" y1="100%" x2="100%" y2="0%"><stop offset="0%" stop-color="#FEDA75"/><stop offset="25%" stop-color="#FA7E1E"/><stop offset="50%" stop-color="#D62976"/><stop offset="75%" stop-color="#962FBF"/><stop offset="100%" stop-color="#4F5BD5"/></linearGradient></defs><rect x="2" y="2" width="20" height="20" rx="5" stroke="url(#ig-grad)" stroke-width="2"/><circle cx="12" cy="12" r="5" stroke="url(#ig-grad)" stroke-width="2"/><circle cx="17.5" cy="6.5" r="1.5" fill="url(#ig-grad)"/></svg>
								</span>
							</button>
							<button type="button" class="sp-share-option" id="sp-share-link" aria-label="링크 복사">
								<span class="sp-share-option__icon sp-share-option__icon--link">
									<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
								</span>
							</button>
						</div>
					</div>

					<hr class="sp-sidebar__divider">

					<?php // ── 배송/서비스 + 환불 규정 (freepdf 상품은 숨김) ── ?>
					<?php if ( ! $is_freepdf ) : ?>
					<div class="sp-sidebar__info-sections">
						<?php if ( $is_virtual ) : ?>
							<details class="sp-info-accordion" open>
								<summary class="sp-info-accordion__header">
									<span class="sp-info-accordion__icon">
										<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
									</span>
									<span class="sp-info-accordion__title">서비스 정보</span>
									<svg class="sp-info-accordion__chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
								</summary>
								<div class="sp-info-accordion__body">
									<ul class="sp-info-list">
										<li>수강 기간: <strong><?php echo esc_html( $service_period ); ?></strong></li>
										<li>결제 후 즉시 이용 가능</li>
									</ul>
								</div>
							</details>
						<?php else : ?>
							<details class="sp-info-accordion" open>
								<summary class="sp-info-accordion__header">
									<span class="sp-info-accordion__icon">
										<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
									</span>
									<span class="sp-info-accordion__title">배송 정보</span>
									<svg class="sp-info-accordion__chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
								</summary>
								<div class="sp-info-accordion__body">
									<ul class="sp-info-list">
										<li>배송비: <strong><?php echo esc_html( $shipping_cost ); ?></strong></li>
										<li>배송 기간: <?php echo esc_html( $shipping_period ); ?></li>
										<li>도서/산간 지역은 추가 배송비가 발생할 수 있습니다</li>
									</ul>
								</div>
							</details>
						<?php endif; ?>

						<details class="sp-info-accordion">
							<summary class="sp-info-accordion__header">
								<span class="sp-info-accordion__icon">
									<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/></svg>
								</span>
								<span class="sp-info-accordion__title">환불 규정</span>
								<svg class="sp-info-accordion__chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
							</summary>
							<div class="sp-info-accordion__body">
								<ul class="sp-info-list">
									<?php foreach ( explode( "\n", $refund_policy ) as $line ) :
										$line = trim( $line );
										if ( $line ) : ?>
											<li><?php echo esc_html( $line ); ?></li>
									<?php endif; endforeach; ?>
								</ul>
							</div>
						</details>
					</div>
					<?php endif; // ! $is_freepdf ?>

				</div>
			</aside>

		</div>
	</section>

	<!-- ── 모바일 하단 고정 바 ── -->
	<div class="sp-mobile-bar">
		<div class="sp-mobile-bar__inner">
			<?php if ( $is_freepdf ) : ?>
				<div class="sp-mobile-bar__price">
					<?php if ( $regular_price > 0 ) : ?>
						<del class="sp-mobile-bar__original"><?php echo wp_kses_post( wc_price( $regular_price ) ); ?></del>
					<?php endif; ?>
					<span class="sp-mobile-bar__amount">무료</span>
				</div>
				<?php if ( is_user_logged_in() ) : ?>
					<a href="<?php echo esc_url( add_query_arg( 'freepdf', $product->get_id(), home_url( '/freepdf-download/' ) ) ); ?>" class="sp-mobile-bar__btn sp-mobile-bar__btn--download">
						무료 신청
					</a>
				<?php else : ?>
					<a href="<?php echo esc_url( $kakao_login_url ); ?>" class="sp-mobile-bar__btn sp-mobile-bar__btn--kakao">
						카카오 로그인 후 다운로드
					</a>
				<?php endif; ?>
			<?php else : ?>
				<div class="sp-mobile-bar__price">
					<?php if ( $product->is_on_sale() && $discount_pct > 0 ) : ?>
						<span class="sp-mobile-bar__discount"><?php echo esc_html( $discount_pct ); ?>%</span>
					<?php endif; ?>
					<span class="sp-mobile-bar__amount"><?php echo wp_kses_post( wc_price( $product->get_price() ) ); ?></span>
				</div>
				<?php if ( $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() ) : ?>
					<a href="<?php echo esc_url( add_query_arg( [ 'add-to-cart' => $product->get_id(), 'buy_now' => 1 ], wc_get_checkout_url() ) ); ?>" class="sp-mobile-bar__btn">
						바로 구매
					</a>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>

</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>
