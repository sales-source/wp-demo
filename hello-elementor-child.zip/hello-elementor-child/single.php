<?php
/**
 * 블로그 글 싱글 포스트 템플릿
 *
 * GEO 최적화 레이아웃:
 * - 일반 글: [좌측 TOC] | [중앙 콘텐츠] | [우측 홍보 위젯]
 * - GEO 글 (FAQ/용어집): 1컬럼 클린 레이아웃 (h2+p, TL;DR만)
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

// ── GEO 카테고리 감지 ──
$is_geo = has_category( 'geo' );

if ( $is_geo ) :
	// ── GEO 레이아웃: AI 인용 최적화 (h2 + p 클린 구조) ──
	hello_child_render_geo_single();
else :
	// ── 일반 블로그 레이아웃 ──
	hello_child_render_default_single();
endif;

get_footer();

/* =============================================================================
   GEO 레이아웃 — AI 인용 최적화 (FAQ / 용어집)
   ============================================================================= */

function hello_child_render_geo_single() {
	$raw_content = get_the_content();
	$raw_content = apply_filters( 'the_content', $raw_content );

	// H2에 id 속성 삽입
	$h2_items = array();
	if ( preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $raw_content, $matches ) ) {
		foreach ( $matches[1] as $i => $heading_text ) {
			$clean_text = wp_strip_all_tags( $heading_text );
			$slug       = 'section-' . ( $i + 1 );
			$h2_items[] = array( 'slug' => $slug, 'text' => $clean_text );
		}

		$counter = 0;
		$raw_content = preg_replace_callback( '/<h2([^>]*)>(.*?)<\/h2>/si', function ( $m ) use ( &$counter, $h2_items ) {
			$slug = $h2_items[ $counter ]['slug'];
			$counter++;
			return '<h2' . $m[1] . ' id="' . esc_attr( $slug ) . '">' . $m[2] . '</h2>';
		}, $raw_content );
	}

	// FAQ 슬러그 감지 (Schema 분기용)
	$is_faq = ( get_post_field( 'post_name', get_the_ID() ) === 'faq' )
		|| stripos( get_the_title(), 'FAQ' ) !== false
		|| stripos( get_the_title(), '자주 묻는' ) !== false;
	?>

	<div class="hc-geo-layout">
		<main class="hc-geo-wrap">
		<?php while ( have_posts() ) : the_post(); ?>
			<article class="hc-single hc-geo-article" itemscope itemtype="https://schema.org/Article">

				<?php // ── 카테고리 + 날짜 ── ?>
				<div class="hc-single-meta">
					<?php
					$categories = get_the_category();
					if ( ! empty( $categories ) ) :
					?>
						<a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>" class="hc-single-cat">
							<?php echo esc_html( $categories[0]->name ); ?>
						</a>
					<?php endif; ?>
					<time class="hc-single-date" datetime="<?php echo get_the_date( 'c' ); ?>" itemprop="datePublished">
						<?php echo get_the_date( 'Y년 n월 j일' ); ?>
					</time>
				</div>

				<?php // ── 제목 ── ?>
				<h1 class="hc-single-title" itemprop="headline"><?php the_title(); ?></h1>

				<?php
				// ── 3줄 요약 (AI 인용 블럭) ──
				$tldr = get_post_meta( get_the_ID(), '_hello_child_tldr', true );
				$tldr_filled = is_array( $tldr ) ? array_filter( $tldr ) : array();
				if ( ! empty( $tldr_filled ) ) :
				?>
					<div class="hc-tldr hc-geo-summary" role="doc-abstract">
						<h2 class="hc-tldr-title">요약</h2>
						<ul class="hc-tldr-list">
							<?php foreach ( $tldr_filled as $line ) : ?>
								<li><?php echo esc_html( $line ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>

				<?php // ── 본문 (h2 + p 클린 구조) ── ?>
				<div class="hc-single-content hc-geo-content" itemprop="articleBody">
					<?php echo $raw_content; ?>
				</div>

			</article>
		<?php endwhile; ?>
		</main>
	</div>

	<?php
	// ── Schema JSON-LD ──
	hello_child_render_geo_schema( $is_faq, $raw_content, $h2_items );
}

/* =============================================================================
   GEO Schema JSON-LD — FAQPage / DefinedTermSet
   ============================================================================= */

function hello_child_render_geo_schema( $is_faq, $raw_content, $h2_items ) {
	if ( $is_faq ) {
		// FAQPage Schema: h2를 질문, 바로 뒤 p를 답변으로 매핑
		$faq_entries = array();
		if ( preg_match_all( '/<h2[^>]*>(.*?)<\/h2>\s*<p>(.*?)<\/p>/si', $raw_content, $faq_matches, PREG_SET_ORDER ) ) {
			foreach ( $faq_matches as $faq ) {
				$faq_entries[] = array(
					'@type'          => 'Question',
					'name'           => wp_strip_all_tags( $faq[1] ),
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => wp_strip_all_tags( $faq[2] ),
					),
				);
			}
		}

		if ( ! empty( $faq_entries ) ) {
			$schema = array(
				'@context'   => 'https://schema.org',
				'@type'      => 'FAQPage',
				'mainEntity' => $faq_entries,
			);
			echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
		}
	} else {
		// DefinedTermSet Schema: h2를 용어, 바로 뒤 p를 정의로 매핑
		$terms = array();
		if ( preg_match_all( '/<h2[^>]*>(.*?)<\/h2>\s*<p>(.*?)<\/p>/si', $raw_content, $term_matches, PREG_SET_ORDER ) ) {
			foreach ( $term_matches as $t ) {
				$terms[] = array(
					'@type'       => 'DefinedTerm',
					'name'        => wp_strip_all_tags( $t[1] ),
					'description' => wp_strip_all_tags( $t[2] ),
				);
			}
		}

		if ( ! empty( $terms ) ) {
			$schema = array(
				'@context'    => 'https://schema.org',
				'@type'       => 'DefinedTermSet',
				'name'        => get_the_title(),
				'description' => get_the_excerpt(),
				'hasDefinedTerm' => $terms,
			);
			echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
		}
	}
}

/* =============================================================================
   일반 블로그 레이아웃 (기존)
   ============================================================================= */

function hello_child_render_default_single() {
	// ── 본문에서 H2 목차 추출 (서버사이드 — GEO 파싱 가능) ──
	$raw_content = get_the_content();
	$raw_content = apply_filters( 'the_content', $raw_content );
	$toc_items   = array();

	if ( preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/si', $raw_content, $matches ) ) {
		foreach ( $matches[1] as $i => $heading_text ) {
			$clean_text  = wp_strip_all_tags( $heading_text );
			$slug        = 'section-' . ( $i + 1 );
			$toc_items[] = array( 'slug' => $slug, 'text' => $clean_text );
		}

		// H2에 id 속성 삽입
		$counter = 0;
		$raw_content = preg_replace_callback( '/<h2([^>]*)>(.*?)<\/h2>/si', function ( $m ) use ( &$counter, $toc_items ) {
			$slug = $toc_items[ $counter ]['slug'];
			$counter++;
			return '<h2' . $m[1] . ' id="' . esc_attr( $slug ) . '">' . $m[2] . '</h2>';
		}, $raw_content );
	}

	// ── 사이드바 홍보 위젯 데이터 ──
	$sidebar_widget = hello_child_get_sidebar_widget( get_the_ID() );
	$has_sidebar    = ! empty( $sidebar_widget['title'] );
	?>

	<div class="hc-single-layout <?php echo $has_sidebar ? 'hc-has-sidebar' : ''; ?>">

		<?php // ── 좌측: 목차 ── ?>
		<?php if ( ! empty( $toc_items ) ) : ?>
			<aside class="hc-toc-sidebar">
				<nav class="hc-toc" aria-label="목차">
					<h2 class="hc-toc-heading">목차</h2>
					<ul class="hc-toc-list">
						<?php foreach ( $toc_items as $item ) : ?>
							<li>
								<a href="#<?php echo esc_attr( $item['slug'] ); ?>" class="hc-toc-link">
									<?php echo esc_html( $item['text'] ); ?>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				</nav>
			</aside>
		<?php endif; ?>

		<?php // ── 중앙: 메인 콘텐츠 ── ?>
		<main class="hc-single-wrap">
		<?php while ( have_posts() ) : the_post(); ?>
			<article class="hc-single" itemscope itemtype="https://schema.org/Article">

				<?php // ── 카테고리 + 날짜 ── ?>
				<div class="hc-single-meta">
					<?php
					$categories = get_the_category();
					if ( ! empty( $categories ) ) :
					?>
						<a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>" class="hc-single-cat">
							<?php echo esc_html( $categories[0]->name ); ?>
						</a>
					<?php endif; ?>
					<time class="hc-single-date" datetime="<?php echo get_the_date( 'c' ); ?>" itemprop="datePublished">
						<?php echo get_the_date( 'Y년 n월 j일' ); ?>
					</time>
				</div>

				<?php // ── 제목 ── ?>
				<h1 class="hc-single-title" itemprop="headline"><?php the_title(); ?></h1>

				<?php
				// ── 핵심 답변 ──
				$key_answer = get_post_meta( get_the_ID(), '_hello_child_key_answer', true );
				if ( $key_answer ) :
				?>
					<div class="hc-key-answer" itemprop="description">
						<p><?php echo esc_html( $key_answer ); ?></p>
					</div>
				<?php endif; ?>

				<?php
				// ── 3줄 요약 ──
				$tldr = get_post_meta( get_the_ID(), '_hello_child_tldr', true );
				$tldr_filled = is_array( $tldr ) ? array_filter( $tldr ) : array();
				if ( ! empty( $tldr_filled ) ) :
				?>
					<div class="hc-tldr">
						<h2 class="hc-tldr-title">3줄 요약</h2>
						<ul class="hc-tldr-list">
							<?php foreach ( $tldr_filled as $line ) : ?>
								<li><?php echo esc_html( $line ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>

				<?php // ── 본문 (H2에 id 삽입된 버전) ── ?>
				<div class="hc-single-content" itemprop="articleBody">
					<?php echo $raw_content; ?>
				</div>

				<?php
				// ── 관련글 (같은 카테고리 자동) ──
				$cats = wp_get_post_categories( get_the_ID() );
				if ( ! empty( $cats ) ) :
					$related = get_posts( array(
						'category__in'   => $cats,
						'post__not_in'   => array( get_the_ID() ),
						'posts_per_page' => 3,
						'orderby'        => 'date',
						'order'          => 'DESC',
					) );

					if ( ! empty( $related ) ) :
					?>
						<div class="hc-related">
							<h2 class="hc-related-title">관련글</h2>
							<div class="hc-related-grid">
								<?php foreach ( $related as $r ) : ?>
									<a href="<?php echo get_permalink( $r->ID ); ?>" class="hc-related-card">
										<?php if ( has_post_thumbnail( $r->ID ) ) : ?>
											<div class="hc-related-thumb">
												<?php echo get_the_post_thumbnail( $r->ID, 'medium' ); ?>
											</div>
										<?php endif; ?>
										<div class="hc-related-info">
											<h3 class="hc-related-card-title"><?php echo esc_html( $r->post_title ); ?></h3>
											<time class="hc-related-date"><?php echo get_the_date( 'Y.n.j', $r->ID ); ?></time>
										</div>
									</a>
								<?php endforeach; ?>
							</div>
						</div>
					<?php
					endif;
				endif;
				?>

				<?php
				// ── 용어 정리 ──
				$glossary = get_post_meta( get_the_ID(), '_hello_child_glossary', true );
				$glossary_filled = is_array( $glossary ) ? array_filter( $glossary, function( $g ) {
					return ! empty( $g['term'] ) && ! empty( $g['definition'] );
				} ) : array();

				if ( ! empty( $glossary_filled ) ) :
				?>
					<div class="hc-glossary">
						<div class="hc-glossary-label">꼭 알아야 할 용어</div>
						<?php foreach ( $glossary_filled as $item ) : ?>
							<div class="hc-glossary-item">
								<div class="hc-glossary-term"><?php echo esc_html( $item['term'] ); ?></div>
								<div class="hc-glossary-row">
									<span class="hc-glossary-row-label">정의</span>
									<span class="hc-glossary-row-text"><?php echo esc_html( $item['definition'] ); ?></span>
								</div>
								<?php if ( ! empty( $item['easy'] ) ) : ?>
									<div class="hc-glossary-row hc-glossary-easy-row">
										<span class="hc-glossary-row-label">쉽게 말하면</span>
										<span class="hc-glossary-row-text"><?php echo esc_html( $item['easy'] ); ?></span>
									</div>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

			<?php
				// ── CTA ──
				$ctas = get_post_meta( get_the_ID(), '_hello_child_cta', true );
				$ctas = is_array( $ctas ) ? array_filter( $ctas, function ( $c ) {
					return ! empty( $c['text'] ) && ! empty( $c['url'] );
				} ) : array();

				if ( ! empty( $ctas ) ) :
				?>
					<div class="hc-cta">
						<h3 class="hc-cta-title">관련 정보 보기</h3>
						<?php foreach ( $ctas as $cta ) : ?>
							<div class="hc-cta-row">
								<span class="hc-cta-text"><?php echo esc_html( $cta['text'] ); ?></span>
								<a href="<?php echo esc_url( $cta['url'] ); ?>" class="hc-cta-btn">바로 가기<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"/></svg></a>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

			</article>
		<?php endwhile; ?>
		</main>

		<?php // ── 우측: 홍보 위젯 ── ?>
		<?php if ( $has_sidebar ) : ?>
			<aside class="hc-promo-sidebar">
				<div class="hc-promo-widget">
					<?php
					$sw_thumb_url = ! empty( $sidebar_widget['thumb_id'] )
						? wp_get_attachment_image_url( $sidebar_widget['thumb_id'], 'medium' )
						: '';
					if ( $sw_thumb_url ) :
					?>
						<div class="hc-promo-thumb">
							<img src="<?php echo esc_url( $sw_thumb_url ); ?>" alt="<?php echo esc_attr( $sidebar_widget['title'] ); ?>">
						</div>
					<?php endif; ?>
					<h3 class="hc-promo-title"><?php echo esc_html( $sidebar_widget['title'] ); ?></h3>
					<?php if ( ! empty( $sidebar_widget['url'] ) ) : ?>
						<a href="<?php echo esc_url( $sidebar_widget['url'] ); ?>" class="hc-promo-btn">바로가기</a>
					<?php endif; ?>
				</div>
			</aside>
		<?php endif; ?>

	</div>
	<?php
	// ── Schema JSON-LD (일반 블로그 글) ──
	hello_child_render_post_schema();
}

/* =============================================================================
   일반 글 Schema JSON-LD — Article + DefinedTermSet
   ============================================================================= */

function hello_child_render_post_schema() {
	$post_id = get_the_ID();

	// ── BlogPosting Schema ──
	$key_answer = get_post_meta( $post_id, '_hello_child_key_answer', true );
	$thumb_url  = get_the_post_thumbnail_url( $post_id, 'full' );

	$article = array(
		'@context'      => 'https://schema.org',
		'@type'         => 'BlogPosting',
		'headline'      => get_the_title(),
		'description'   => $key_answer ? $key_answer : wp_trim_words( get_the_excerpt(), 30 ),
		'datePublished' => get_the_date( 'c' ),
		'dateModified'  => get_the_modified_date( 'c' ),
		'url'           => get_permalink(),
		'author'        => array(
			'@type' => 'Organization',
			'name'  => get_bloginfo( 'name' ),
			'url'   => home_url(),
		),
		'publisher'     => array(
			'@type' => 'Organization',
			'name'  => get_bloginfo( 'name' ),
			'url'   => home_url(),
		),
	);

	if ( $thumb_url ) {
		$article['image'] = $thumb_url;
	}

	// 3줄 요약 → abstract
	$tldr = get_post_meta( $post_id, '_hello_child_tldr', true );
	$tldr_filled = is_array( $tldr ) ? array_filter( $tldr ) : array();
	if ( ! empty( $tldr_filled ) ) {
		$article['abstract'] = implode( ' ', $tldr_filled );
	}

	echo '<script type="application/ld+json">' . wp_json_encode( $article, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";

	// ── DefinedTermSet Schema (용어 데이터 있을 때만) ──
	$glossary = get_post_meta( $post_id, '_hello_child_glossary', true );
	$glossary_filled = is_array( $glossary ) ? array_filter( $glossary, function( $g ) {
		return ! empty( $g['term'] ) && ! empty( $g['definition'] );
	} ) : array();

	if ( ! empty( $glossary_filled ) ) {
		$defined_terms = array();
		foreach ( $glossary_filled as $item ) {
			$defined_terms[] = array(
				'@type'       => 'DefinedTerm',
				'name'        => $item['term'],
				'description' => $item['definition'],
			);
		}

		$term_set = array(
			'@context'       => 'https://schema.org',
			'@type'          => 'DefinedTermSet',
			'name'           => '꼭 알아야 할 용어 — ' . get_the_title(),
			'hasDefinedTerm' => $defined_terms,
		);

		echo '<script type="application/ld+json">' . wp_json_encode( $term_set, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
	}
}
