<?php
/**
 * Template Name: PG Shop
 *
 * PG 심사용 상품 페이지 — WooCommerce Shop 레이아웃 동일 적용
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main hc-pg-shop-main" role="main">

		<?php
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
		?>

	</main>
</div>

<?php
get_footer();
