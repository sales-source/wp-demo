<?php
/**
 * Template Name: 블로그 모음
 * Template Post Type: page
 *
 * 블로그 글 모음 페이지 — 한 줄에 4개 카드 그리드.
 * 엘리멘토 편집 불가, 테마 활성화 시 자동 생성.
 *
 * @package HelloElementorChild
 */

defined( 'ABSPATH' ) || exit;

get_header();

// 페이지네이션
$paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;

$args = array(
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'posts_per_page' => 12,
    'paged'          => $paged,
    'orderby'        => 'date',
    'order'          => 'DESC',
    // Uncategorized 기본 카테고리 + 'geo' 카테고리(FAQ/용어집 등 AI 인용 최적화)는 제외
    'category__not_in' => array_filter( array(
        (int) get_option( 'default_category' ),
        (int) ( get_term_by( 'slug', 'geo', 'category' )->term_id ?? 0 ),
    ) ),
);

$blog_query = new WP_Query( $args );
?>

<style>
/* ===== 블로그 모음 스타일 ===== */
.terra-blog-archive {
    max-width: 1280px;
    margin: 0 auto;
    padding: 60px 24px 80px;
}

.terra-blog-archive__title {
    font-family: 'Roboto Slab', serif;
    font-size: 2.25rem;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 48px;
    letter-spacing: -0.02em;
}

.terra-blog-archive__desc {
    font-family: 'Roboto', sans-serif;
    font-size: 1.0625rem;
    color: #64748b;
    margin-bottom: 48px;
    line-height: 1.6;
}

/* 4열 그리드 */
.terra-blog-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 28px;
}

/* 카드 */
.terra-blog-card {
    background: #fff;
    border-radius: 14px;
    overflow: hidden;
    border: 1px solid #e8ecf1;
    transition: box-shadow 0.25s ease, transform 0.25s ease;
    cursor: pointer;
    display: flex;
    flex-direction: column;
}

.terra-blog-card:hover {
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
    transform: translateY(-4px);
}

@media (prefers-reduced-motion: reduce) {
    .terra-blog-card,
    .terra-blog-card__thumb img {
        transition: none !important;
    }
    .terra-blog-card:hover,
    .terra-blog-card:hover .terra-blog-card__thumb img {
        transform: none !important;
    }
}

/* 썸네일 */
.terra-blog-card__thumb {
    position: relative;
    width: 100%;
    aspect-ratio: 16 / 10;
    overflow: hidden;
    background: #f1f5f9;
}

.terra-blog-card__thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    transition: transform 0.4s ease;
}

.terra-blog-card:hover .terra-blog-card__thumb img {
    transform: scale(1.05);
}

/* 썸네일 없을 때 */
.terra-blog-card__thumb--empty {
    display: flex;
    align-items: center;
    justify-content: center;
}

.terra-blog-card__thumb--empty svg {
    width: 48px;
    height: 48px;
    color: #cbd5e1;
}

/* 카테고리 뱃지 */
.terra-blog-card__cat {
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--color-primary, #0064FF);
    background: none;
    padding: 0;
    border-radius: 0;
    letter-spacing: 0.02em;
    text-transform: uppercase;
    margin-bottom: 10px;
}

/* 본문 영역 */
.terra-blog-card__body {
    padding: 20px;
    display: flex;
    flex-direction: column;
    flex: 1;
}

.terra-blog-card__title {
    font-family: 'Roboto Slab', serif;
    font-size: 1.0625rem;
    font-weight: 600;
    color: #1e293b;
    line-height: 1.45;
    margin-bottom: 10px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.terra-blog-card__title a {
    color: inherit;
    text-decoration: none;
}

.terra-blog-card__title a:hover {
    color: #6366f1;
}

.terra-blog-card__title a:focus-visible {
    outline: 2px solid #6366f1;
    outline-offset: 2px;
    border-radius: 4px;
}

.terra-blog-card__excerpt {
    font-family: 'Roboto', sans-serif;
    font-size: 0.875rem;
    color: #64748b;
    line-height: 1.6;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    margin-bottom: 16px;
    flex: 1;
}

/* 메타 (날짜 + 읽기시간) */
.terra-blog-card__meta {
    display: flex;
    align-items: center;
    gap: 12px;
    font-family: 'Roboto', sans-serif;
    font-size: 0.8125rem;
    color: #94a3b8;
    padding-top: 14px;
    border-top: 1px solid #f1f5f9;
    margin-top: auto;
}

.terra-blog-card__meta svg {
    width: 14px;
    height: 14px;
    flex-shrink: 0;
}

.terra-blog-card__meta-item {
    display: flex;
    align-items: center;
    gap: 4px;
}

/* 페이지네이션 */
.terra-blog-pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 6px;
    margin-top: 56px;
    font-family: 'Roboto', sans-serif;
}

.terra-blog-pagination a,
.terra-blog-pagination span {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 40px;
    height: 40px;
    padding: 0 12px;
    border-radius: 10px;
    font-size: 0.9375rem;
    font-weight: 500;
    text-decoration: none;
    transition: background 0.2s ease, color 0.2s ease;
}

.terra-blog-pagination a {
    color: #475569;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    cursor: pointer;
}

.terra-blog-pagination a:hover {
    background: #6366f1;
    color: #fff;
    border-color: #6366f1;
}

.terra-blog-pagination a:focus-visible {
    outline: 2px solid #6366f1;
    outline-offset: 2px;
}

.terra-blog-pagination .current {
    background: #6366f1;
    color: #fff;
    border: 1px solid #6366f1;
    font-weight: 600;
}

.terra-blog-pagination .dots {
    color: #94a3b8;
    border: none;
    background: none;
}

/* 빈 상태 */
.terra-blog-empty {
    text-align: center;
    padding: 80px 20px;
}

.terra-blog-empty svg {
    width: 64px;
    height: 64px;
    color: #cbd5e1;
    margin-bottom: 20px;
}

.terra-blog-empty__title {
    font-family: 'Roboto Slab', serif;
    font-size: 1.25rem;
    font-weight: 600;
    color: #334155;
    margin-bottom: 8px;
}

.terra-blog-empty__desc {
    font-family: 'Roboto', sans-serif;
    font-size: 0.9375rem;
    color: #94a3b8;
}

/* ===== 반응형 ===== */

/* 태블릿 */
@media (max-width: 1024px) {
    .terra-blog-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 22px;
    }

    .terra-blog-archive__title {
        font-size: 1.875rem;
    }
}

/* 모바일 */
@media (max-width: 640px) {
    .terra-blog-archive {
        padding: 40px 16px 60px;
    }

    .terra-blog-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    .terra-blog-archive__title {
        font-size: 1.5rem;
    }

    .terra-blog-archive__desc {
        font-size: 0.9375rem;
        margin-bottom: 32px;
    }
}
</style>

<main id="content" class="terra-blog-archive" role="main">
    <h1 class="terra-blog-archive__title"><?php echo esc_html( get_the_title() ); ?></h1>

    <?php if ( $blog_query->have_posts() ) : ?>
        <div class="terra-blog-grid">
            <?php while ( $blog_query->have_posts() ) : $blog_query->the_post(); ?>
                <?php
                // 카테고리
                $categories = get_the_category();
                $cat_name   = ! empty( $categories ) ? $categories[0]->name : '';

                // 읽기 시간 계산 (한국어: 글자 수 기준, 분당 ~500자)
                $content      = get_the_content();
                $char_count   = mb_strlen( strip_tags( $content ) );
                $reading_time = max( 1, ceil( $char_count / 500 ) );

                // 발췌문
                $excerpt = get_the_excerpt();
                ?>
                <article class="terra-blog-card">
                    <div class="terra-blog-card__thumb<?php echo ! has_post_thumbnail() ? ' terra-blog-card__thumb--empty' : ''; ?>">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <a href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( get_the_title() ); ?>">
                                <?php the_post_thumbnail( 'medium_large', array(
                                    'alt'     => esc_attr( get_the_title() ),
                                    'loading' => 'lazy',
                                ) ); ?>
                            </a>
                        <?php else : ?>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.2" stroke="currentColor" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909M3.75 21h16.5A2.25 2.25 0 0 0 22.5 18.75V5.25A2.25 2.25 0 0 0 20.25 3H3.75A2.25 2.25 0 0 0 1.5 5.25v13.5A2.25 2.25 0 0 0 3.75 21Z" />
                            </svg>
                        <?php endif; ?>
                    </div>

                    <div class="terra-blog-card__body">
                        <?php if ( $cat_name ) : ?>
                            <span class="terra-blog-card__cat"><?php echo esc_html( $cat_name ); ?></span>
                        <?php endif; ?>

                        <h2 class="terra-blog-card__title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>

                        <div class="terra-blog-card__meta">
                            <span class="terra-blog-card__meta-item">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5" />
                                </svg>
                                <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></time>
                            </span>
                            <span class="terra-blog-card__meta-item">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                </svg>
                                <?php echo esc_html( $reading_time ); ?>분 읽기
                            </span>
                        </div>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>

        <?php
        // 페이지네이션
        $total_pages = $blog_query->max_num_pages;
        if ( $total_pages > 1 ) :
        ?>
            <nav class="terra-blog-pagination" aria-label="블로그 페이지 네비게이션">
                <?php
                echo paginate_links( array(
                    'total'     => $total_pages,
                    'current'   => $paged,
                    'prev_text' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" /></svg><span class="screen-reader-text">이전</span>',
                    'next_text' => '<span class="screen-reader-text">다음</span><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" /></svg>',
                ) );
                ?>
            </nav>
        <?php endif; ?>

        <?php wp_reset_postdata(); ?>

    <?php else : ?>
        <div class="terra-blog-empty">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.2" stroke="currentColor" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5" />
            </svg>
            <h2 class="terra-blog-empty__title">아직 작성된 글이 없습니다</h2>
            <p class="terra-blog-empty__desc">곧 새로운 콘텐츠가 업로드됩니다.</p>
        </div>
    <?php endif; ?>
</main>

<?php
get_footer();
