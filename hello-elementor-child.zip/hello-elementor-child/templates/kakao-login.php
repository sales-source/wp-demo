<?php
/**
 * Template Name: 카카오 로그인
 *
 * 테라 플러그인 카카오 REST API 키 기반 자동 로그인 페이지.
 * 숏코드 없이 API 키만 설정하면 버튼이 자동 렌더링됨.
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$rest_api_key = get_option( 'terra_kakao_rest_api_key', '' );
$is_logged_in = is_user_logged_in();
?>

<div class="hello-child-login-wrap">
	<div class="hello-child-login-box">

		<?php if ( $is_logged_in ) : ?>
			<?php
			$user        = wp_get_current_user();
			$current_url = home_url( '/login' );
			$logout_url  = wp_logout_url( $current_url );
			$switch_url  = add_query_arg( 'switch', '1', home_url( '/klogin' ) );
			?>
			<div class="hello-child-login-greeting">
				<p>안녕하세요, <strong><?php echo esc_html( $user->display_name ); ?></strong>님!</p>
				<div class="hello-child-login-actions">
					<a href="<?php echo esc_url( $logout_url ); ?>" class="hello-child-btn hello-child-btn-outline">로그아웃</a>
					<a href="<?php echo esc_url( $switch_url ); ?>" class="hello-child-btn hello-child-btn-outline">다른 계정으로 로그인</a>
				</div>
			</div>

		<?php elseif ( ! empty( $rest_api_key ) ) : ?>
			<?php $login_url = home_url( '/klogin' ); ?>
			<h2 class="hello-child-login-title">로그인</h2>
			<a href="<?php echo esc_url( $login_url ); ?>" class="hello-child-kakao-btn">
				<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 256 256">
					<path fill="#000000" d="M128 36C70.562 36 24 72.713 24 118c0 29.279 19.466 54.97 48.748 69.477-1.593 5.494-10.237 35.344-10.581 37.689 0 0-.207 1.762.934 2.434s2.483.15 2.483.15c3.272-.457 37.943-24.811 43.944-29.03 5.995.849 12.168 1.28 18.472 1.28 57.438 0 104-36.712 104-82c0-45.287-46.562-82-104-82"/>
				</svg>
				<span>카카오로 로그인</span>
			</a>

		<?php else : ?>
			<div class="hello-child-login-notice">
				<p>카카오 로그인이 아직 설정되지 않았습니다.</p>
				<?php if ( current_user_can( 'manage_options' ) ) : ?>
					<p>관리자 메뉴 > 테라 플러그인 > 카카오 로그인 > API 설정에서 REST API 키를 입력해주세요.</p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

	</div>
</div>

<?php get_footer(); ?>
