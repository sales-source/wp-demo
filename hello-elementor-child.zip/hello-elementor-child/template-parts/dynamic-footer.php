<?php
/**
 * 차일드 테마 푸터
 *
 * - 3컬럼: 회사정보 / 바로가기 / 고객지원
 * - 하단 카피라이트
 * - Elementor Theme Builder로 오버라이드 가능
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$site_name    = get_bloginfo( 'name' );
$biz_name     = get_option( 'terra_business_name', '' );
$biz_ceo      = get_option( 'terra_business_ceo', '' );
$biz_number   = get_option( 'terra_business_number', '' );
$biz_phone    = get_option( 'terra_business_phone', '' );
$biz_address  = get_option( 'terra_business_address', '' );
$biz_email    = get_option( 'terra_business_email', '' );
$biz_privacy  = get_option( 'terra_business_privacy_officer', '' );

$footer_nav_menu = wp_nav_menu( array(
	'theme_location' => 'menu-2',
	'fallback_cb'    => false,
	'container'      => false,
	'menu_class'     => 'hello-child-footer-links',
	'echo'           => false,
) );
?>

<footer id="site-footer" class="site-footer hello-child-footer dynamic-footer">
	<div class="hello-child-footer-main">
		<div class="hello-child-footer-inner">
			<div class="hello-child-footer-col hello-child-footer-left">
				<h4 class="hello-child-footer-brand"><?php echo esc_html( $biz_name ?: $site_name ); ?></h4>
			</div>

			<div class="hello-child-footer-col hello-child-footer-right">
				<?php if ( $footer_nav_menu ) : ?>
					<?php echo $footer_nav_menu; ?>
				<?php else : ?>
					<ul class="hello-child-footer-links">
						<li><a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>">이용약관</a></li>
						<li><a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>">개인정보 처리방침</a></li>
					</ul>
				<?php endif; ?>

				<div class="hello-child-footer-biz">
					<?php if ( $biz_ceo ) : ?>
						<span>회사명 : <?php echo esc_html( $biz_name ?: $site_name ); ?></span>
					<?php endif; ?>
					<?php if ( $biz_ceo ) : ?>
						<span>대표자 : <?php echo esc_html( $biz_ceo ); ?></span>
					<?php endif; ?>
					<?php if ( $biz_address ) : ?>
						<span>사업장 소재지 : <?php echo esc_html( $biz_address ); ?></span>
					<?php endif; ?>
				</div>
				<div class="hello-child-footer-biz">
					<?php if ( $biz_number ) : ?>
						<span>사업자등록번호 : <?php echo esc_html( $biz_number ); ?></span>
					<?php endif; ?>
					<?php if ( $biz_email ) : ?>
						<span>이메일 : <?php echo esc_html( $biz_email ); ?></span>
					<?php endif; ?>
					<?php if ( $biz_phone ) : ?>
						<span>고객 센터 : <?php echo esc_html( $biz_phone ); ?></span>
					<?php endif; ?>
					<?php if ( $biz_privacy ) : ?>
						<span>개인정보관리책임자 : <?php echo esc_html( $biz_privacy ); ?></span>
					<?php endif; ?>
				</div>

				<p class="hello-child-footer-copyright">&copy; <?php echo esc_html( date( 'Y' ) ); ?> <?php echo esc_html( $biz_name ?: $site_name ); ?>. All rights reserved.</p>
			</div>
		</div>
	</div>
</footer>
