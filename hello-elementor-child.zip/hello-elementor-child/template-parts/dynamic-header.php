<?php
/**
 * 차일드 테마 헤더
 *
 * - 사이트 제목 (WP 설정 > 사이트 제목)
 * - 내비게이션 메뉴
 * - 동적 CTA: 비로그인 → 로그인(/login/), 로그인 → 마이페이지(/my-account/)
 * - Elementor Theme Builder로 오버라이드 가능
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$site_name = get_bloginfo( 'name' );
$menu_args = array(
	'theme_location' => 'menu-1',
	'fallback_cb'    => false,
	'container'      => false,
	'echo'           => false,
);
$header_nav_menu        = wp_nav_menu( $menu_args );
$header_mobile_nav_menu = wp_nav_menu( $menu_args );

if ( is_user_logged_in() ) {
	$cta_text = '마이페이지';
	$cta_url  = home_url( '/my-account/' );
} else {
	$cta_text = '로그인';
	$cta_url  = home_url( '/my-account/' );
}
?>

<header id="site-header" class="site-header hello-child-header dynamic-header">
	<div class="hello-child-header-inner">
		<div class="hello-child-header-logo">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="hello-child-site-title">
					<?php echo esc_html( $site_name ); ?>
				</a>
			<?php endif; ?>
		</div>

		<div class="hello-child-header-right">
			<?php if ( $header_nav_menu ) : ?>
				<nav class="hello-child-header-nav" aria-label="<?php echo esc_attr__( 'Main menu', 'hello-elementor' ); ?>">
					<?php echo $header_nav_menu; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</nav>
			<?php endif; ?>

			<div class="hello-child-header-actions">
				<a href="<?php echo esc_url( $cta_url ); ?>" class="hello-child-header-cta">
					<?php echo esc_html( $cta_text ); ?>
				</a>

				<a href="<?php echo esc_url( home_url( '/my-account/' ) ); ?>" class="hello-child-header-user" aria-label="마이 페이지">
					<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
						<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
						<circle cx="12" cy="7" r="4"/>
					</svg>
				</a>

				<?php if ( $header_mobile_nav_menu ) : ?>
					<button type="button" class="hello-child-menu-toggle" aria-label="메뉴">
						<span></span><span></span><span></span>
					</button>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<?php if ( $header_mobile_nav_menu ) : ?>
		<nav class="hello-child-mobile-nav" aria-label="Mobile menu" aria-hidden="true">
			<?php echo $header_mobile_nav_menu; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<a href="<?php echo esc_url( $cta_url ); ?>" class="hello-child-mobile-cta">
				<?php echo esc_html( $cta_text ); ?>
			</a>
		</nav>
	<?php endif; ?>
</header>
