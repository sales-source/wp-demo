<?php
/**
 * 차일드 테마 Header
 *
 * 부모 테마의 기본 헤더를 완전 교체.
 * Elementor Theme Builder 헤더가 있으면 그것을 우선 사용.
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$viewport_content = apply_filters( 'hello_elementor_viewport_content', 'width=device-width, initial-scale=1' );
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="<?php echo esc_attr( $viewport_content ); ?>">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<?php wp_body_open(); ?>

<?php
// Elementor Pro Theme Builder 헤더가 활성화되어 있으면 그것을 우선 사용.
// 없을 때만 테마의 dynamic-header로 폴백. LMS 주메뉴 주입은
// create_menus / 위젯 필터 쪽에서 처리하므로 여기서는 location 체크만 한다.
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'header' ) ) {
	get_template_part( 'template-parts/dynamic-header' );
}
