<?php echo HELLO_CHILD_VERSION ?? "not defined"; ?>
