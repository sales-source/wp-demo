<?php
/**
 * 차일드 테마 Footer
 *
 * 부모 테마의 기본 푸터를 완전 교체.
 * Elementor Theme Builder 푸터가 있으면 그것을 우선 사용.
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) {
	get_template_part( 'template-parts/dynamic-footer' );
}
?>

<?php wp_footer(); ?>

</body>
</html>
