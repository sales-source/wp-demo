/**
 * Hello Elementor Child — 커스텀 스크립트
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var toggle = document.querySelector('.hello-child-menu-toggle');
		var mobileNav = document.querySelector('.hello-child-mobile-nav');

		if (toggle && mobileNav) {
			toggle.addEventListener('click', function () {
				mobileNav.classList.toggle('is-open');
			});
		}

		// 검수 미통과 #126: 홈 FAQ 섹션의 첫 번째 toggle 항목 기본 열림.
		// Elementor free 의 toggle 위젯은 per-tab default state 를 지원하지 않으므로
		// 클라이언트에서 첫 아이템에 active 클래스를 부여하고 tab-content 를 연다.
		var faqToggles = document.querySelectorAll('.thv2-faq-toggle .elementor-toggle-item');
		if (faqToggles.length > 0) {
			var firstItem = faqToggles[0];
			var firstTitle = firstItem.querySelector('.elementor-tab-title');
			var firstContent = firstItem.querySelector('.elementor-tab-content');
			if (firstTitle && firstContent) {
				firstItem.classList.add('elementor-active');
				firstTitle.classList.add('elementor-active');
				firstTitle.setAttribute('aria-expanded', 'true');
				firstTitle.setAttribute('aria-selected', 'true');
				firstContent.classList.add('elementor-active');
				firstContent.style.display = 'block';
			}
		}
	});
})();
