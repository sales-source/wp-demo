/**
 * Terra Dashboard v3 — 현황판 + 온보딩 페이지
 *
 * 현황판: KPI 4컬럼 + 3위젯 (온보딩미니+진단+사이트정보)
 * 온보딩: 6카테고리 전체 펼침 + 글로벌 체크리스트
 * window.terraDashboard 에서 서버 데이터를 읽어 렌더링한다.
 */
(function () {
  'use strict';

  var CFG   = window.terraDashboard || {};
  var LINKS = CFG.links || {};
  var AUTO  = CFG.onboarding || {};
  var DIAG  = CFG.diagnosis || [];
  var BIZ   = CFG.business || {};
  var SITE  = CFG.siteSettings || {};
  var KPI   = { orders: '—', revenue: '—', members: '—', ordersChange: '', revenueChange: '', membersChange: '' };

  var pgReviewMode = !!CFG.pgReviewMode;

  var CHK = '<svg class="td-check-svg" viewBox="0 0 16 16" fill="none"><path d="M4 8l3 3 5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  // 우측 화살표 (내부 세팅 바로가기)
  var ARR = '<svg viewBox="0 0 16 16" fill="currentColor"><path d="M6 3l5 5-5 5V3z"/></svg>';
  // 외부 링크 (가이드 보기)
  var EXT = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 8.5v5a1.5 1.5 0 01-1.5 1.5h-8A1.5 1.5 0 011 13.5v-8A1.5 1.5 0 012.5 4H7"/><path d="M10 1h5v5M15 1L7 9" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  // ── 3스텝 온보딩 (16 태스크) ──
  var A = CFG.adminUrl || '/wp-admin/';
  var S = CFG.siteUrl || '';
  var STEPS = [
    { num:1, key:'payment', title:'결제 연동', desc:'토스페이먼츠 PG 신청부터 실결제 전환까지 진행합니다.', subs:[
      { tag:'pg_apply', title:'온라인 PG 신청', desc:'토스페이먼트 온라인 신청 및 PG 승인을 위한 결제 기능 세팅합니다.',
        goto:{ label:'설정 바로가기', url:A+'admin.php?page=terra-kakao#/tosspay/onboarding' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/toss/online-pg/', color:'guide' } },
      { tag:'product_create', title:'판매 상품 등록', desc:'판매 상품명 가격 이미지를 입력하고 공개합니다.',
        goto:{ label:'설정 바로가기', url:A+'edit.php?post_type=product' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/woocommerce/create-product/', color:'guide' } },
      { tag:'pg_page', title:'PG 신청용 페이지 생성', desc:'PG 심사용 상품을 생성하고 PG 신청 페이지를 생성합니다.',
        pgToggle: true,
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/toss/pgpage/', color:'guide' } },
      { tag:'test_payment', title:'테스트 결제 확인', desc:'비회원 모드에서 상품 결제 테스트로 기능 검수합니다.',
        goto:{ label:'설정 바로가기', url:S+'/pg-shop/' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/toss/pay-test/', color:'guide' } },
      { tag:'safe_plan', title:'안심 정산 플랜 결제', desc:'토스페이먼트로부터 안심정산플랜을 결제합니다.',
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/toss/toss-setup/', color:'guide' } },
      { tag:'card_review', title:'카드사 심사 완료 후 세팅', desc:'카드심사가 완료되면, 운영 모드로 전환하여 실제 결제를 받을 수 있는 상태로 변경합니다.',
        goto:{ label:'설정 바로가기', url:A+'admin.php?page=terra-kakao#/tosspay/gateway' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/toss/toss-setup/', color:'guide' } }
    ]},
    { num:2, key:'kakao', title:'카카오 로그인', desc:'카카오 간편 로그인 및 자동 친구추가를 설정합니다.', subs:[
      { tag:'kakao_login', title:'카카오 로그인 신청', desc:'카카오 로그인 기능 사용을 위한 카카오앱 생성 및 등록을 진행합니다.',
        goto:{ label:'설정 바로가기', url:A+'admin.php?page=terra-kakao#/kakao/settings' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/kakaologin/kakao-login-setup/', color:'guide' } },
      { tag:'login_page', title:'로그인 페이지 생성', desc:'카카오 로그인 전용 페이지를 생성합니다.',
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/kakaologin/login-page/', color:'guide' } },
      { tag:'biz_channel', title:'비지니스 채널 개설', desc:'카카오 자동 친구추가 기능 세팅을 위해 비지니스 채널 개설을 진행합니다.',
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/kakaologin/kakao-biz/', color:'guide' } },
      { tag:'auto_friend', title:'카카오 자동 친구 추가 세팅', desc:'카카오 비지니스 채널 승인 후 카카오 자동 친구 추가 기능을 세팅합니다.',
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/kakaologin/auto-friend-setup/', color:'guide' } }
    ]},
    { num:3, key:'smart_noti', title:'스마트 알림', desc:'카카오 알림톡, 문자, 이메일 발송을 설정합니다.', subs:[
      { tag:'kakao_ch', title:'카카오 채널 연동', desc:'카카오 비지니스 채널을 웹사이트에 연동 및 관리자 정보를 등록합니다.',
        goto:{ label:'설정 바로가기', url:A+'admin.php?page=terra-kakao#/alimtalk/settings' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/smart-noti/kakao-ch-setup/', color:'guide' } },
      { tag:'alimtalk_tpl', title:'알림톡 템플릿 등록', desc:'고객에게 발송할 카카오 알림톡 메시지의 내용을 사전에 등록하여 검수합니다.',
        goto:{ label:'설정 바로가기', url:A+'admin.php?page=terra-kakao#/alimtalk/templates?tab=alimtalk' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/smart-noti/st-templated/', color:'guide' } },
      { tag:'alimtalk_test', title:'알림톡 발송 테스트', desc:'승인된 알림톡 템플릿으로 발송 테스트를 진행합니다.',
        goto:{ label:'설정 바로가기', url:A+'admin.php?page=terra-kakao#/alimtalk/send' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/smart-noti/send-st/', color:'guide' } },
      { tag:'brand_msg', title:'브랜드 메세지 발송 테스트', desc:'채널 친구에게 프로모션 톡 메세지 발송하는 기능으로, 발송 테스트 진행합니다.',
        goto:{ label:'설정 바로가기', url:A+'admin.php?page=terra-kakao#/alimtalk/send' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/smart-noti/brand-me/', color:'guide' } },
      { tag:'sms_test', title:'문자 발송 테스트', desc:'문자 발송 기능 검수를 위해 문자 발송 테스트를 진행합니다.',
        goto:{ label:'설정 바로가기', url:A+'admin.php?page=terra-kakao#/alimtalk/send' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/smart-noti/send-sms/', color:'guide' } },
      { tag:'email_test', title:'이메일 발송 테스트', desc:'이메일 발송 기능 검수를 위해 이메일 발송 테스트를 진행합니다.',
        goto:{ label:'설정 바로가기', url:A+'admin.php?page=terra-kakao#/alimtalk/send' },
        ext:{ text:'가이드 보기', url:'https://teraflow.net/docs/funnelpack01/smart-noti/email-tem/', color:'guide' } }
    ]}
  ];

  var TOTAL_TASKS = STEPS.reduce(function(a,s){ return a+s.subs.length; },0);
  var checked = new Set();
  var currentPage = 'overview';

  function applyAutoDetected() {
    // 스텝 레벨 (하위 호환)
    STEPS.forEach(function(step) {
      if (AUTO[step.key]) { step.subs.forEach(function(s){ checked.add(s.tag); }); }
    });
    // 태스크 레벨 자동 감지
    var tasks = AUTO.tasks || {};
    Object.keys(tasks).forEach(function(tag) {
      if (tasks[tag]) checked.add(tag);
    });
  }

  function isStepDone(num) {
    var s = STEPS.find(function(x){ return x.num===num; });
    return s ? s.subs.every(function(x){ return checked.has(x.tag); }) : false;
  }

  function pct() { return Math.round((checked.size/TOTAL_TASKS)*100); }
  function esc(s) { var d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }

  // ── 페이지 전환 ──
  function switchPage(name) {
    currentPage = name;
    document.querySelectorAll('.td-page').forEach(function(p){ p.classList.toggle('active', p.id==='td-page-'+name); });
  }

  // 스텝별 완료 태스크 수
  function stepDoneCount(num) {
    var s = STEPS.find(function(x){ return x.num===num; });
    if (!s) return 0;
    return s.subs.filter(function(x){ return checked.has(x.tag); }).length;
  }

  // ══════════════════════════════════════
  // 현황판
  // ══════════════════════════════════════
  function renderOverview() {
    var el = document.getElementById('td-page-overview');
    if (!el) return;
    var p = pct();
    var html = '';

    // KPI
    html += '<div class="td-kpi-row">';
    html += kpiCard('오늘 주문', KPI.orders, KPI.ordersChange);
    html += kpiCard('이번달 매출', KPI.revenue, KPI.revenueChange);
    html += kpiCard('회원 수', KPI.members, KPI.membersChange);
    html += kpiCard('온보딩 진행률', p+'%', checked.size+' / '+TOTAL_TASKS+' 완료');
    html += '</div>';

    // 2컬럼: 사이트 현황 + 사이트 정보
    html += '<div class="td-overview-grid">';

    // ── 온보딩 가이드 (영상 7 + 체크리스트 3) ──
    html += '<div class="td-card"><div class="td-card-header" style="flex-wrap:wrap"><div style="width:100%;display:flex;align-items:center;justify-content:space-between">';
    html += '<div class="td-card-title td-ob-guide-title">온보딩 가이드</div>';
    html += '<button class="td-btn-start" data-page="onboarding">세팅 시작 '+ARR+'</button></div>';
    html += '<div class="td-ob-guide-desc">웹 사이트 오픈에 필요한 필수 설정을 단계별로 초고속 세팅 진행합니다.</div>';
    html += '</div>';
    html += '<div class="td-card-body">';

    // 영상(7) + 체크리스트(3)
    html += '<div class="td-status-row">';

    // 영상 컬럼
    html += '<div>';
    html += '<div class="td-status-video"><div style="text-align:center;padding:20px"><svg width="36" height="36" viewBox="0 0 24 24" fill="#fff" opacity=".6"><polygon points="5 3 19 12 5 21"/></svg><div style="margin-top:6px;opacity:.7;font-size:11px">온보딩 설명 영상</div></div></div></div>';

    // 체크리스트 + 프로그레스 바 (제목 바로 하단)
    html += '<div class="td-status-cl">';
    html += '<div class="td-status-cl-title">사이트 기본 세팅 현황</div>';
    html += '<div class="td-scl-progress"><div class="td-status-pbar"><div class="td-status-pbar-fill" style="width:'+p+'%"></div></div>';
    html += '<span class="td-status-pct">'+p+'%</span></div>';
    STEPS.forEach(function(s) {
      var allDone = isStepDone(s.num);
      html += '<div class="td-scl-section">';
      html += '<div class="td-scl-label'+(allDone?' completed':'')+'">'+esc(s.title)+'</div>';
      s.subs.forEach(function(sub) {
        var d = checked.has(sub.tag);
        html += '<div class="td-scl-item'+(d?' done':'')+'">';
        html += '<div class="td-scl-box">'+(d?'✓':'')+'</div>';
        html += '<span>'+esc(sub.title)+'</span></div>';
      });
      html += '</div>';
    });
    html += '</div>';

    html += '</div>'; // status-row
    html += '</div></div>'; // card-body, card

    // ── 사이트 정보 ──
    html += '<div class="td-card td-info-card"><div class="td-card-header"><div class="td-card-title" style="font-size:12px">사이트 정보</div></div>';
    html += '<div class="td-card-body td-info-form">';
    html += '<div class="td-card-note">여기 기재한 내용이 사이트 메뉴와 하단 푸터에 자동 반영됩니다.</div>';
    html += colorField('site_primary_color','강조색',SITE.primary_color||'#1D4ED8');
    html += infoField('site_blogname','사이트 제목',SITE.blogname||'');
    html += infoField('site_blogdescription','태그라인',SITE.blogdescription||'');
    html += '<div class="td-info-divider">사업자 정보</div>';
    html += infoField('biz_name','상호명',BIZ.name||'');
    html += infoField('biz_ceo','대표자',BIZ.ceo||'');
    html += infoField('biz_number','사업자번호',BIZ.number||'');
    html += infoField('biz_phone','전화번호',BIZ.phone||'');
    html += infoField('biz_address','주소',BIZ.address||'');
    html += infoField('biz_email','이메일',BIZ.email||'');
    html += infoField('biz_privacy_officer','개인정보 책임자',BIZ.privacy_officer||'');
    html += '<button class="td-btn-save" id="td-info-save">저장</button>';
    html += '</div></div>';
    html += '</div>';

    el.innerHTML = html;

    el.querySelectorAll('[data-page]').forEach(function(btn){
      btn.addEventListener('click', function(){ switchPage(this.dataset.page); });
    });
    var saveBtn = document.getElementById('td-info-save');
    if (saveBtn) saveBtn.addEventListener('click', saveAllInfo);
  }

  function kpiCard(label, value, sub) {
    return '<div class="td-kpi"><div class="td-kpi-label">'+esc(label)+'</div>'+
      '<div class="td-kpi-value">'+esc(value)+'</div>'+
      '<div class="td-kpi-change">'+esc(sub)+'</div></div>';
  }

  function infoField(name, label, value) {
    return '<label class="td-info-label">'+esc(label)+'</label>'+
      '<input type="text" name="'+name+'" value="'+esc(value)+'" class="td-info-input">';
  }

  function colorField(name, label, value) {
    return '<label class="td-info-label">'+esc(label)+'</label>'+
      '<input type="color" name="'+name+'" value="'+esc(value)+'" class="td-info-input td-info-color">';
  }

  function saveAllInfo() {
    var siteData = {};
    var bizData = {};
    var nameInput  = document.querySelector('input[name="site_blogname"]');
    var descInput  = document.querySelector('input[name="site_blogdescription"]');
    var colorInput = document.querySelector('input[name="site_primary_color"]');
    if (nameInput)  siteData.blogname        = nameInput.value;
    if (descInput)  siteData.blogdescription = descInput.value;
    if (colorInput) siteData.primary_color   = colorInput.value;

    ['name','ceo','number','phone','address','email','privacy_officer'].forEach(function(f){
      var inp = document.querySelector('input[name="biz_'+f+'"]');
      if (inp) bizData[f] = inp.value;
    });

    var headers = { 'Content-Type':'application/json', 'X-WP-Nonce':CFG.nonce };
    Promise.all([
      fetch(CFG.restUrl+'terra-dashboard/v1/site-settings', { method:'POST', credentials:'same-origin', headers:headers, body:JSON.stringify(siteData) }),
      fetch(CFG.restUrl+'terra-dashboard/v1/business', { method:'POST', credentials:'same-origin', headers:headers, body:JSON.stringify(bizData) })
    ]).then(function(){ toast('저장되었습니다.'); }).catch(function(){ toast('저장 실패'); });
  }

  // ══════════════════════════════════════
  // 온보딩 페이지 — 6스텝 전체 펼침
  // ══════════════════════════════════════
  function renderOnboarding() {
    var el = document.getElementById('td-page-onboarding');
    if (!el) return;
    var p = pct();
    var html = '';

    html += '<a class="td-back-link" data-page="overview">← 현황판</a>';
    html += '<div class="td-ob-header"><div class="td-ob-page-title">온보딩 가이드</div>';
    html += '<div class="td-ob-page-desc">사이트 오픈에 필요한 필수 설정을 단계별로 진행합니다. "설정 바로가기"를 클릭하면 해당 설정 페이지로 이동합니다.</div></div>';

    html += '<div class="td-ob-layout">';

    // 좌측: 전체 스텝 펼침
    html += '<div class="td-ob-content">';
    STEPS.forEach(function(step){
      var stepDone = isStepDone(step.num);
      html += '<div class="td-ob-section'+(stepDone?' completed':'')+'">';
      html += '<div class="td-ob-sec-header"><div class="td-ob-sec-title">'+esc(step.title)+'</div>';
      html += '<div class="td-ob-sec-desc">'+esc(step.desc)+'</div></div>';

      html += '<div class="td-task-grid">';
      step.subs.forEach(function(sub){
        var isDone = checked.has(sub.tag);
        html += '<div class="td-task'+(isDone?' done':'')+'">';
        html += '<div class="td-task-check'+(isDone?' done':'')+'" data-tag="'+sub.tag+'">'+
          '<svg viewBox="0 0 16 16" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8l3 3 5-5"/></svg></div>';
        html += '<div class="td-task-title">'+esc(sub.title)+'</div>';
        if (sub.desc) html += '<div class="td-task-desc">'+esc(sub.desc)+'</div>';
        html += '<div class="td-task-btns">';
        if (sub.pgToggle) {
          var pgOn = !!pgReviewMode;
          html += '<button class="td-btn-goto td-btn-pg-toggle'+(pgOn?' active':'')+'" data-pg-toggle="1">'+(pgOn?'심사 모드 OFF':'심사 모드 ON')+'</button>';
        }
        if (sub.goto) html += '<a href="'+sub.goto.url+'" class="td-btn-goto td-btn-settings">'+esc(sub.goto.label)+' '+ARR+'</a>';
        if (sub.ext) html += '<a href="'+sub.ext.url+'" target="_blank" rel="noopener" class="td-btn-goto td-btn-'+sub.ext.color+'">'+esc(sub.ext.text)+' '+EXT+'</a>';
        html += '</div></div>';
      });
      html += '</div></div>';
    });
    html += '</div>';

    // 우측: 글로벌 체크리스트 (세로 중앙 sticky)
    html += '<div class="td-cl-wrap"><div class="td-cl-card">';
    html += '<div class="td-cl-title">체크리스트</div>';
    html += '<div class="td-cl-sub">'+checked.size+' / '+TOTAL_TASKS+' 완료</div>';
    html += '<div class="td-cl-bar"><div class="td-cl-bar-fill" style="width:'+p+'%"></div></div>';
    STEPS.forEach(function(s){
      var allDone = isStepDone(s.num);
      html += '<div class="td-cl-section">';
      html += '<div class="td-cl-sec-label'+(allDone?' completed':'')+'">'+s.num+'. '+esc(s.title)+'</div>';
      s.subs.forEach(function(sub){
        var d = checked.has(sub.tag);
        html += '<div class="td-cl-item'+(d?' done':' remaining')+'" data-tag="'+sub.tag+'">';
        html += '<div class="td-cl-box">'+(d?'✓':'')+'</div><span>'+esc(sub.title)+'</span></div>';
      });
      html += '</div>';
    });
    html += '</div></div>';

    html += '</div>';

    el.innerHTML = html;

    // 이벤트
    el.querySelectorAll('[data-page]').forEach(function(b){ b.addEventListener('click', function(){ switchPage(this.dataset.page); }); });
    el.querySelectorAll('.td-task-check').forEach(function(b){ b.addEventListener('click', function(){ toggleComplete(this.dataset.tag); }); });
    el.querySelectorAll('.td-cl-item').forEach(function(b){ b.addEventListener('click', function(){ toggleComplete(this.dataset.tag); }); });
    el.querySelectorAll('[data-pg-toggle]').forEach(function(b){ b.addEventListener('click', function(){ togglePgReviewMode(); }); });
  }

  // ── 완료 토글 ──
  function toggleComplete(tag) {
    if (checked.has(tag)) checked.delete(tag);
    else { checked.add(tag); saveProgress(); }
    renderAll();
  }

  function saveProgress() {
    if (!CFG.nonce) return;
    var data = {};
    STEPS.forEach(function(s){ data[s.key] = isStepDone(s.num); });
    fetch(CFG.restUrl+'terra-dashboard/v1/onboarding', {
      method:'POST', credentials:'same-origin',
      headers:{ 'Content-Type':'application/json', 'X-WP-Nonce':CFG.nonce },
      body: JSON.stringify(data)
    }).then(function(){
      // payment 카테고리 완료 시 PG 심사 모드 자동 해제 (서버에서도 처리)
      if (data.payment && pgReviewMode) {
        pgReviewMode = false;
        toast('카드사 심사 완료 — 메인 페이지가 원래대로 복원되었습니다.');
        renderAll();
      }
    }).catch(function(){});
  }

  function togglePgReviewMode() {
    if (!CFG.nonce) return;
    var newState = !pgReviewMode;
    fetch(CFG.restUrl+'terra-dashboard/v1/pg-review-mode', {
      method:'POST', credentials:'same-origin',
      headers:{ 'Content-Type':'application/json', 'X-WP-Nonce':CFG.nonce },
      body: JSON.stringify({ enabled: newState })
    }).then(function(r){ return r.json(); })
    .then(function(res){
      if (res.success) {
        pgReviewMode = res.enabled;
        toast(pgReviewMode ? 'PG 심사 모드 ON — 메인 페이지가 상품 페이지로 전환되었습니다.' : 'PG 심사 모드 OFF — 메인 페이지가 원래대로 복원되었습니다.');
        renderAll();
      }
    }).catch(function(){});
  }

  function toast(msg) {
    var el = document.getElementById('td-toast');
    if (!el) return;
    el.textContent = msg; el.classList.add('show');
    setTimeout(function(){ el.classList.remove('show'); }, 2500);
  }

  function renderAll() {
    renderOverview();
    renderOnboarding();
  }

  // ── 레이아웃 빌드 ──
  function buildLayout() {
    var app = document.getElementById('terra-dashboard-app');
    if (!app) return;
    app.innerHTML =
      '<div id="td-toast" class="td-toast"></div>'+
      '<div class="td-page active" id="td-page-overview"></div>'+
      '<div class="td-page" id="td-page-onboarding"></div>';
  }

  // ── WooCommerce KPI fetch ──
  function fetchKPI() {
    if (!CFG.plugins || !CFG.plugins.woocommerce) return;
    var headers = { 'X-WP-Nonce': CFG.nonce };
    var today = new Date(); today.setHours(0,0,0,0);
    var todayISO = today.toISOString();
    var monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString();

    fetch(CFG.restUrl+'wc/v3/orders?after='+encodeURIComponent(todayISO)+'&per_page=1&status=any', {
      credentials:'same-origin', headers:headers
    }).then(function(r){
      if (!r.ok) return;
      KPI.orders = (r.headers.get('X-WP-Total')||'0')+'건';
      updateKpiDOM();
    }).catch(function(){});

    fetch(CFG.restUrl+'wc/v3/orders?after='+encodeURIComponent(monthStart)+'&per_page=100&status=completed,processing', {
      credentials:'same-origin', headers:headers
    }).then(function(r){ return r.json(); }).then(function(orders){
      var total = 0;
      if (Array.isArray(orders)) orders.forEach(function(o){ total += parseFloat(o.total||0); });
      KPI.revenue = '\u20a9'+total.toLocaleString();
      KPI.revenueChange = (Array.isArray(orders) ? orders.length : 0)+'건 주문';
      updateKpiDOM();
    }).catch(function(){});

    fetch(CFG.restUrl+'wp/v2/users?per_page=1&context=edit', {
      credentials:'same-origin', headers:headers
    }).then(function(r){
      if (!r.ok) return;
      KPI.members = (r.headers.get('X-WP-Total')||'0')+'명';
      updateKpiDOM();
    }).catch(function(){});
  }

  function updateKpiDOM() {
    var vals = document.querySelectorAll('.td-kpi-value');
    var subs = document.querySelectorAll('.td-kpi-change');
    if (vals.length >= 4) {
      vals[0].textContent = KPI.orders;
      vals[1].textContent = KPI.revenue;
      vals[2].textContent = KPI.members;
      if (subs[0]) subs[0].textContent = KPI.ordersChange;
      if (subs[1]) subs[1].textContent = KPI.revenueChange;
      if (subs[2]) subs[2].textContent = KPI.membersChange;
    }
  }

  function init() {
    applyAutoDetected();
    buildLayout();
    renderAll();
    fetchKPI();
  }

  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
