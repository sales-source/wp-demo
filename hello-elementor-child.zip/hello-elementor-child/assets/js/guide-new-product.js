/**
 * 상품 등록 인터랙티브 가이드 — TerraGuide 엔진에 등록
 *
 * 대상: post-new.php?post_type=product
 * 순서: teraflow.net/docs/funnelpack01/woocommerce/create-product/ 기준
 * 9스텝: 상품명 → 상품설명 → 배송/환불 → 상품데이터 → 요약설명 → 대표이미지 → 갤러리 → 공개 → 고유주소
 *
 * Step 8 제외 모든 팝업: position: 'fixed-right'
 *   → 뷰포트 세로 중앙 + 우측 사이드바 왼쪽에 고정
 *   → 스크롤해도 팝업 위치 유지, 필드는 자동 스크롤로 이동
 * Step 8(공개): left — 공개 버튼 바로 옆
 * Step 9(고유주소): 공개 후 #sample-permalink 존재 시만 표시
 */
TerraGuide.register({
	id: 'new_product',
	triggerText: '첫 상품을 등록해볼까요? 단계별 가이드를 따라하세요.',
	triggerTarget: '#poststuff',
	steps: [
		{
			target: '#titlediv',
			title: 'Step 1. 상품명 입력',
			desc: '판매할 상품의 이름을 입력하세요.\n\n상품 상세 페이지 제목, 상품 목록, 결제 영수증에 모두 표시됩니다.\nPG 심사를 위해 실제 판매할 상품명을 정확히 입력하세요.',
			position: 'fixed-right',
			scrollTarget: '#titlediv'
		},
		{
			target: '#postdivrich',
			title: 'Step 2. 상품 상세 설명',
			desc: '상품 페이지 본문 영역에 노출됩니다.\n\n"미디어 추가" 버튼으로 미리 제작한 상세 설명 이미지를 업로드하세요.\n여러 장을 순서대로 업로드하면 위에서 아래로 자연스럽게 이어집니다.',
			position: 'fixed-right',
			scrollTarget: '#postdivrich'
		},
		{
			target: '#hello_child_shipping_info',
			title: 'Step 3. 배송 / 환불 정보',
			desc: '배송비, 배송 기간, 환불 규정을 입력하세요.\n비워두면 기본값이 자동 표시됩니다.\n\nPG 심사 시 환불 정책이 상품 페이지에 명시되어야 합니다.',
			position: 'fixed-right',
			scrollTarget: '#hello_child_shipping_info'
		},
		{
			target: '#woocommerce-product-data',
			title: 'Step 4. 상품 데이터 설정',
			desc: '상품 유형과 가격을 설정하는 핵심 영역입니다.\n\n• 가상 — 배송 없는 상품(온라인 강의 등)은 체크\n• 정상 가격 — 숫자만 입력 (쉼표/₩ 금지)\n• 할인 가격 — 할인 적용 시에만 입력\n• 정기결제 — 구독 상품은 체크 후 결제 방식 선택\n• 결제 방식 — 자동결제 선택 시 카드 자동 청구\n• 땡큐페이지 URL — 결제 완료 후 이동할 페이지 지정',
			position: 'fixed-right',
			scrollTarget: '#woocommerce-product-data'
		},
		{
			target: '#postexcerpt',
			title: 'Step 5. 상품 요약 설명',
			desc: '상품 상세 페이지에서 가격·구매 버튼 바로 위에 표시됩니다.\n핵심 정보 2~3줄을 입력하세요.\n\n예: 수강기간 3주 / 환불 구매 후 7일 이내 / 배송 24시간 이내',
			position: 'fixed-right',
			scrollTarget: '#postexcerpt'
		},
		{
			target: '#postimagediv',
			title: 'Step 6. 상품 대표 이미지',
			desc: '"상품 이미지 설정" 링크를 클릭하여 대표 이미지를 업로드하세요.\n\n상품 목록과 상세 페이지 상단에 표시됩니다.\n권장: 800×800px 이상, 정사각형 비율.',
			position: 'fixed-right',
			scrollTarget: '#postimagediv'
		},
		{
			target: '#woocommerce-product-images',
			title: 'Step 7. 상품 갤러리 추가',
			desc: '"상품 갤러리 이미지 추가하기"를 클릭하여 추가 이미지를 등록하세요.\n상세 페이지에서 슬라이드로 표시됩니다.\n\n대표 이미지만으로 충분하면 건너뛰어도 됩니다.',
			position: 'fixed-right',
			scrollTarget: '#woocommerce-product-images'
		},
		{
			target: '#submitdiv',
			title: 'Step 8. 상품 공개',
			desc: '모든 정보를 확인한 후 "공개" 버튼을 클릭하세요.\n\n공개 후 "상품 보기" 링크로 상세 페이지를 확인하세요.\n상품명, 가격, 이미지, "바로 구매하기" 버튼이 정상 표시되면 완료!',
			position: 'left',
			scrollTarget: '#submitdiv'
		}
	]
});
TerraGuide.init();
