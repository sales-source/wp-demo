/**
 * 인터랙티브 온보딩 가이드 — 블로그 글 작성
 *
 * 단계별로 필드를 하이라이트하고 툴팁을 표시하여
 * 사용자가 매뉴얼 없이 글 작성 방법을 익힐 수 있다.
 *
 * @package HelloElementorChild
 */

(function () {
	'use strict';

	/* ── 스텝 정의 ── */
	var steps = [
		{
			target: '#title',
			title: '1단계: 글 제목 입력',
			desc: 'SEO에 최적화된 제목을 입력하세요. 핵심 키워드를 앞쪽에 배치하면 검색 노출에 유리합니다.',
			position: 'bottom'
		},
		{
			target: '#wp-content-editor-container, #wp-content-wrap',
			title: '2단계: 본문 작성',
			desc: 'H2/H3 태그로 구조를 잡고 본문을 작성하세요. 이미지, 리스트, 인용문을 활용하면 가독성이 높아집니다.',
			position: 'bottom'
		},
		{
			target: '#hello_child_key_answer',
			title: '3단계: 핵심 답변',
			desc: '이 글의 핵심을 1~2문장으로 요약하세요. 글 상단에 강조 박스로 자동 표시됩니다. 독자가 "이 글이 내 질문에 답하는가?"를 즉시 판단할 수 있게 합니다.',
			position: 'bottom',
			scrollTarget: '#hello_child_key_answer'
		},
		{
			target: '#hello_child_tldr',
			title: '4단계: 3줄 요약',
			desc: '핵심 포인트 3가지를 입력하세요. 목차 위에 요약 카드로 자동 표시되어, 독자가 글의 가치를 빠르게 파악합니다.',
			position: 'bottom',
			scrollTarget: '#hello_child_tldr'
		},
		{
			target: '#hello_child_cta',
			title: '5단계: CTA (Call to Action)',
			desc: '독자에게 다음 행동을 유도하세요. 예: "무료 상담 신청하기", "강의 보러가기" 등. 설명과 URL을 입력하면 본문 하단에 버튼으로 표시됩니다.',
			position: 'top',
			scrollTarget: '#hello_child_cta'
		},
		{
			target: '#publish',
			title: '6단계: 발행',
			desc: '모든 필드를 확인한 후 "공개" 버튼을 클릭하세요. 미리보기로 프론트엔드를 먼저 확인할 수도 있습니다.',
			position: 'left',
			scrollTarget: '#submitdiv'
		}
	];

	var currentStep = 0;
	var overlay = null;
	var tooltip = null;
	var spotlight = null;

	/* ── 오버레이 + 툴팁 생성 ── */
	function createUI() {
		// 오버레이 (어두운 배경)
		overlay = document.createElement('div');
		overlay.className = 'terra-onboard-overlay';
		document.body.appendChild(overlay);

		// 스포트라이트 (타겟 주변 밝은 영역)
		spotlight = document.createElement('div');
		spotlight.className = 'terra-onboard-spotlight';
		document.body.appendChild(spotlight);

		// 툴팁
		tooltip = document.createElement('div');
		tooltip.className = 'terra-onboard-tooltip';
		tooltip.innerHTML = [
			'<div class="terra-onboard-tooltip__header">',
			'  <span class="terra-onboard-tooltip__step"></span>',
			'  <button type="button" class="terra-onboard-tooltip__close" aria-label="닫기">&times;</button>',
			'</div>',
			'<h4 class="terra-onboard-tooltip__title"></h4>',
			'<p class="terra-onboard-tooltip__desc"></p>',
			'<div class="terra-onboard-tooltip__actions">',
			'  <button type="button" class="terra-onboard-btn terra-onboard-btn--prev">이전</button>',
			'  <button type="button" class="terra-onboard-btn terra-onboard-btn--next">다음</button>',
			'</div>'
		].join('\n');
		document.body.appendChild(tooltip);

		// 이벤트 바인딩
		tooltip.querySelector('.terra-onboard-tooltip__close').addEventListener('click', destroy);
		tooltip.querySelector('.terra-onboard-btn--prev').addEventListener('click', prevStep);
		tooltip.querySelector('.terra-onboard-btn--next').addEventListener('click', nextStep);
		overlay.addEventListener('click', destroy);
	}

	/* ── 스텝 표시 ── */
	function showStep(index) {
		var step = steps[index];
		var target = document.querySelector(step.target);

		if (!target) {
			// 타겟이 없으면 다음 스텝으로
			if (index < steps.length - 1) { showStep(index + 1); }
			return;
		}

		// 스크롤
		var scrollEl = step.scrollTarget ? document.querySelector(step.scrollTarget) : target;
		if (scrollEl) {
			scrollEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
		}

		// 약간의 딜레이 후 위치 계산 (스크롤 완료 대기)
		setTimeout(function () {
			positionSpotlight(target);
			positionTooltip(target, step);
			updateTooltipContent(step, index);
		}, 350);
	}

	/* ── 스포트라이트 위치 ── */
	function positionSpotlight(target) {
		var rect = target.getBoundingClientRect();
		var pad = 8;
		spotlight.style.top = (rect.top + window.scrollY - pad) + 'px';
		spotlight.style.left = (rect.left + window.scrollX - pad) + 'px';
		spotlight.style.width = (rect.width + pad * 2) + 'px';
		spotlight.style.height = (rect.height + pad * 2) + 'px';
	}

	/* ── 툴팁 위치 ── */
	function positionTooltip(target, step) {
		var rect = target.getBoundingClientRect();
		var tw = 360; // tooltip width
		var pos = step.position || 'bottom';

		tooltip.style.width = tw + 'px';

		var top, left;

		if (pos === 'bottom') {
			top = rect.bottom + window.scrollY + 16;
			left = rect.left + window.scrollX + (rect.width / 2) - (tw / 2);
		} else if (pos === 'top') {
			top = rect.top + window.scrollY - tooltip.offsetHeight - 16;
			left = rect.left + window.scrollX + (rect.width / 2) - (tw / 2);
		} else if (pos === 'left') {
			top = rect.top + window.scrollY;
			left = rect.left + window.scrollX - tw - 16;
		} else {
			top = rect.top + window.scrollY;
			left = rect.right + window.scrollX + 16;
		}

		// 화면 밖 보정
		if (left < 10) left = 10;
		if (left + tw > window.innerWidth - 10) left = window.innerWidth - tw - 10;

		tooltip.style.top = top + 'px';
		tooltip.style.left = left + 'px';
	}

	/* ── 툴팁 내용 업데이트 ── */
	function updateTooltipContent(step, index) {
		tooltip.querySelector('.terra-onboard-tooltip__step').textContent =
			(index + 1) + ' / ' + steps.length;
		tooltip.querySelector('.terra-onboard-tooltip__title').textContent = step.title;
		tooltip.querySelector('.terra-onboard-tooltip__desc').textContent = step.desc;

		var prevBtn = tooltip.querySelector('.terra-onboard-btn--prev');
		var nextBtn = tooltip.querySelector('.terra-onboard-btn--next');

		prevBtn.style.visibility = index === 0 ? 'hidden' : 'visible';
		nextBtn.textContent = index === steps.length - 1 ? '완료' : '다음';
	}

	/* ── 네비게이션 ── */
	function nextStep() {
		if (currentStep < steps.length - 1) {
			currentStep++;
			showStep(currentStep);
		} else {
			destroy();
		}
	}

	function prevStep() {
		if (currentStep > 0) {
			currentStep--;
			showStep(currentStep);
		}
	}

	/* ── 키보드 네비게이션 ── */
	function onKeyDown(e) {
		if (!overlay) return;
		if (e.key === 'Escape') destroy();
		if (e.key === 'ArrowRight' || e.key === 'Enter') nextStep();
		if (e.key === 'ArrowLeft') prevStep();
	}

	/* ── 정리 ── */
	function destroy() {
		if (overlay) { overlay.remove(); overlay = null; }
		if (spotlight) { spotlight.remove(); spotlight = null; }
		if (tooltip) { tooltip.remove(); tooltip = null; }
		document.removeEventListener('keydown', onKeyDown);
		// 완료 상태 저장
		try {
			var xhr = new XMLHttpRequest();
			xhr.open('POST', ajaxurl);
			xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			xhr.send('action=terra_onboarding_dismiss&guide=blog_post&_wpnonce=' + (window.terraOnboardingNonce || ''));
		} catch (e) { /* 무시 */ }
	}

	/* ── 시작 ── */
	function startGuide() {
		currentStep = 0;
		createUI();
		document.addEventListener('keydown', onKeyDown);
		showStep(0);
	}

	/* ── 트리거 버튼 삽입 ── */
	function insertTrigger() {
		// 상단에 가이드 시작 배너 삽입
		var wrap = document.querySelector('#poststuff') || document.querySelector('.wrap');
		if (!wrap) return;

		var banner = document.createElement('div');
		banner.className = 'terra-onboard-banner';
		banner.innerHTML = [
			'<div class="terra-onboard-banner__content">',
			'  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>',
			'  <span>처음 글을 작성하시나요? 단계별 가이드를 따라해보세요.</span>',
			'</div>',
			'<div class="terra-onboard-banner__actions">',
			'  <button type="button" class="terra-onboard-banner__start">가이드 시작</button>',
			'  <button type="button" class="terra-onboard-banner__dismiss">닫기</button>',
			'</div>'
		].join('\n');

		wrap.insertBefore(banner, wrap.firstChild);

		banner.querySelector('.terra-onboard-banner__start').addEventListener('click', function () {
			banner.style.display = 'none';
			startGuide();
		});

		banner.querySelector('.terra-onboard-banner__dismiss').addEventListener('click', function () {
			banner.style.display = 'none';
		});
	}

	// DOM 로드 후 실행
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', insertTrigger);
	} else {
		insertTrigger();
	}
})();
