/**
 * 용어 정리 메타박스 — 동적 행 추가/삭제
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var list = document.getElementById('hello-child-glossary-list');
		var addBtn = document.getElementById('hello-child-glossary-add');

		if (!list || !addBtn) {
			return;
		}

		addBtn.addEventListener('click', function () {
			var rows = list.querySelectorAll('.hello-child-glossary-row');
			var idx = rows.length;

			var row = document.createElement('div');
			row.className = 'hello-child-glossary-row';
			row.setAttribute('data-index', idx);
			row.innerHTML =
				'<div class="hello-child-glossary-header">' +
					'<span class="hello-child-glossary-num">' + (idx + 1) + '</span>' +
					'<input type="text" name="hello_child_glossary[' + idx + '][term]" value="" class="hello-child-meta-input hello-child-glossary-term" placeholder="용어 (예: 차일드 테마)">' +
					'<button type="button" class="hello-child-glossary-remove" title="삭제">&times;</button>' +
				'</div>' +
				'<textarea name="hello_child_glossary[' + idx + '][definition]" rows="2" class="hello-child-meta-textarea hello-child-glossary-def" placeholder="정의 (예: 부모 테마를 상속받아 커스터마이징할 수 있는 하위 테마)"></textarea>' +
				'<input type="text" name="hello_child_glossary[' + idx + '][easy]" value="" class="hello-child-meta-input hello-child-glossary-easy" placeholder="쉽게 말하면 (예: 원본은 그대로 두고 복사본에서 수정하는 것)">';

			list.appendChild(row);
		});

		list.addEventListener('click', function (e) {
			if (e.target.classList.contains('hello-child-glossary-remove')) {
				var row = e.target.closest('.hello-child-glossary-row');
				if (row && list.querySelectorAll('.hello-child-glossary-row').length > 1) {
					row.remove();
				}
			}
		});
	});
})();
