/**
 * CTA 메타박스 — 동적 행 추가/삭제
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var list = document.getElementById('hello-child-cta-list');
		var addBtn = document.getElementById('hello-child-cta-add');

		if (!list || !addBtn) {
			return;
		}

		addBtn.addEventListener('click', function () {
			var rows = list.querySelectorAll('.hello-child-cta-row');
			var idx = rows.length;

			var row = document.createElement('div');
			row.className = 'hello-child-cta-row';
			row.setAttribute('data-index', idx);
			row.innerHTML =
				'<input type="text" name="hello_child_cta[' + idx + '][text]" value="" class="hello-child-meta-input hello-child-cta-text" placeholder="CTA 설명 (예: 무료 상담 신청하기)">' +
				'<input type="url" name="hello_child_cta[' + idx + '][url]" value="" class="hello-child-meta-input hello-child-cta-url" placeholder="URL (예: https://example.com)">' +
				'<button type="button" class="hello-child-cta-remove" title="삭제">&times;</button>';

			list.appendChild(row);
		});

		list.addEventListener('click', function (e) {
			if (e.target.classList.contains('hello-child-cta-remove')) {
				var row = e.target.closest('.hello-child-cta-row');
				if (row && list.querySelectorAll('.hello-child-cta-row').length > 1) {
					row.remove();
				}
			}
		});
	});
})();
