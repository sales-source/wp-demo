/**
 * 상품 메타박스 관리자 JS
 * - virtual 토글 (배송/서비스 필드 전환)
 * - 누구를 위한 강의 이미지 업로더
 * - 커리큘럼 리피터
 * - 강사 이미지 업로더
 * - FAQ 리피터
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {

		/* =====================================================================
		   1. Virtual 토글 — WooCommerce 가상 체크박스 감지
		   ===================================================================== */
		var virtualCheckbox = document.getElementById('_virtual');
		var physicalFields  = document.getElementById('sp-shipping-physical-fields');
		var virtualFields   = document.getElementById('sp-shipping-virtual-fields');

		function toggleShippingFields() {
			if (!physicalFields || !virtualFields) return;
			var isVirtual = virtualCheckbox && virtualCheckbox.checked;
			physicalFields.style.display = isVirtual ? 'none' : '';
			virtualFields.style.display  = isVirtual ? '' : 'none';
		}

		if (virtualCheckbox) {
			virtualCheckbox.addEventListener('change', toggleShippingFields);
			toggleShippingFields();
		}

		/* =====================================================================
		   2. 누구를 위한 강의 — 이미지 업로더
		   ===================================================================== */
		document.addEventListener('click', function (e) {
			if (e.target.classList.contains('sp-target-upload')) {
				e.preventDefault();
				var idx = e.target.getAttribute('data-index');
				var frame = wp.media({ title: '이미지 선택', multiple: false, library: { type: 'image' } });
				frame.on('select', function () {
					var att = frame.state().get('selection').first().toJSON();
					document.getElementById('sp-target-img-' + idx).value = att.id;
					var preview = document.getElementById('sp-target-preview-' + idx);
					preview.innerHTML = '<img src="' + (att.sizes.medium ? att.sizes.medium.url : att.url) + '" style="max-width:100%;border-radius:8px;">';
					preview.style.display = '';
					e.target.nextElementSibling.style.display = '';
				});
				frame.open();
			}

			if (e.target.classList.contains('sp-target-remove')) {
				e.preventDefault();
				var idx2 = e.target.getAttribute('data-index');
				document.getElementById('sp-target-img-' + idx2).value = '';
				var preview2 = document.getElementById('sp-target-preview-' + idx2);
				preview2.innerHTML = '';
				preview2.style.display = 'none';
				e.target.style.display = 'none';
			}
		});

		/* =====================================================================
		   3. 커리큘럼 리피터
		   ===================================================================== */
		var curriculumList = document.getElementById('sp-curriculum-list');
		var addSectionBtn  = document.getElementById('sp-curriculum-add-section');

		function renumberCurriculum() {
			if (!curriculumList) return;
			var num = 1;
			var sections = curriculumList.querySelectorAll('.sp-curriculum-section');
			sections.forEach(function (sec, si) {
				sec.querySelector('.sp-curriculum-section__header strong').textContent = '섹션 ' + (si + 1);
				// 섹션 input name 재색인
				var secTitle = sec.querySelector(':scope > input[type="text"]');
				if (secTitle) secTitle.name = 'sp_curriculum[' + si + '][title]';
				var items = sec.querySelectorAll('.sp-curriculum-item');
				items.forEach(function (item, ii) {
					item.querySelector('.sp-curriculum-item__num').textContent = num + '강';
					var inputs = item.querySelectorAll('input[type="text"]');
					if (inputs[0]) inputs[0].name = 'sp_curriculum[' + si + '][items][' + ii + '][title]';
					if (inputs[1]) inputs[1].name = 'sp_curriculum[' + si + '][items][' + ii + '][desc]';
					num++;
				});
			});
		}

		if (addSectionBtn) {
			addSectionBtn.addEventListener('click', function () {
				var si = curriculumList.querySelectorAll('.sp-curriculum-section').length;
				var html = '<div class="sp-curriculum-section" data-section="' + si + '">' +
					'<div class="sp-curriculum-section__header"><strong>섹션 ' + (si + 1) + '</strong>' +
					'<button type="button" class="button sp-curriculum-remove-section" title="섹션 삭제">&times;</button></div>' +
					'<input type="text" name="sp_curriculum[' + si + '][title]" value="" class="hello-child-meta-input" placeholder="섹션 제목" style="margin-bottom:8px;">' +
					'<div class="sp-curriculum-items" data-section="' + si + '">' +
					'<div class="sp-curriculum-item"><span class="sp-curriculum-item__num"></span>' +
					'<input type="text" name="sp_curriculum[' + si + '][items][0][title]" value="" class="hello-child-meta-input" placeholder="강의 제목" style="flex:1;">' +
					'<input type="text" name="sp_curriculum[' + si + '][items][0][desc]" value="" class="hello-child-meta-input" placeholder="설명 (선택)" style="flex:1;">' +
					'<button type="button" class="hello-child-cta-remove sp-curriculum-remove-item" title="삭제">&times;</button></div></div>' +
					'<button type="button" class="button sp-curriculum-add-item" data-section="' + si + '">+ 강의 추가</button></div>';
				curriculumList.insertAdjacentHTML('beforeend', html);
				renumberCurriculum();
			});
		}

		if (curriculumList) {
			curriculumList.addEventListener('click', function (e) {
				if (e.target.classList.contains('sp-curriculum-add-item')) {
					var sec = e.target.closest('.sp-curriculum-section');
					var si2 = Array.from(curriculumList.querySelectorAll('.sp-curriculum-section')).indexOf(sec);
					var itemsWrap = sec.querySelector('.sp-curriculum-items');
					var ii2 = itemsWrap.querySelectorAll('.sp-curriculum-item').length;
					var row = '<div class="sp-curriculum-item"><span class="sp-curriculum-item__num"></span>' +
						'<input type="text" name="sp_curriculum[' + si2 + '][items][' + ii2 + '][title]" value="" class="hello-child-meta-input" placeholder="강의 제목" style="flex:1;">' +
						'<input type="text" name="sp_curriculum[' + si2 + '][items][' + ii2 + '][desc]" value="" class="hello-child-meta-input" placeholder="설명 (선택)" style="flex:1;">' +
						'<button type="button" class="hello-child-cta-remove sp-curriculum-remove-item" title="삭제">&times;</button></div>';
					itemsWrap.insertAdjacentHTML('beforeend', row);
					renumberCurriculum();
				}

				if (e.target.classList.contains('sp-curriculum-remove-item')) {
					var items2 = e.target.closest('.sp-curriculum-items');
					if (items2.querySelectorAll('.sp-curriculum-item').length > 1) {
						e.target.closest('.sp-curriculum-item').remove();
						renumberCurriculum();
					}
				}

				if (e.target.classList.contains('sp-curriculum-remove-section')) {
					if (curriculumList.querySelectorAll('.sp-curriculum-section').length > 1) {
						e.target.closest('.sp-curriculum-section').remove();
						renumberCurriculum();
					}
				}
			});

			renumberCurriculum();
		}

		/* =====================================================================
		   4. 강사 이미지 업로더
		   ===================================================================== */
		var instUpload = document.getElementById('sp-instructor-upload');
		var instRemove = document.getElementById('sp-instructor-remove');

		if (instUpload) {
			instUpload.addEventListener('click', function (e) {
				e.preventDefault();
				var frame = wp.media({ title: '강사 사진 선택', multiple: false, library: { type: 'image' } });
				frame.on('select', function () {
					var att = frame.state().get('selection').first().toJSON();
					document.getElementById('sp-instructor-photo-id').value = att.id;
					var preview = document.getElementById('sp-instructor-preview');
					preview.innerHTML = '<img src="' + (att.sizes.medium ? att.sizes.medium.url : att.url) + '" style="max-width:100%;border-radius:8px;">';
					preview.style.display = '';
					instRemove.style.display = '';
				});
				frame.open();
			});
		}

		if (instRemove) {
			instRemove.addEventListener('click', function (e) {
				e.preventDefault();
				document.getElementById('sp-instructor-photo-id').value = '';
				var preview = document.getElementById('sp-instructor-preview');
				preview.innerHTML = '';
				preview.style.display = 'none';
				instRemove.style.display = 'none';
			});
		}

		/* =====================================================================
		   5. WHAT YOU GET 리피터
		   ===================================================================== */
		var benefitList = document.getElementById('sp-benefits-list');
		var benefitAdd  = document.getElementById('sp-benefit-add');

		if (benefitAdd) {
			benefitAdd.addEventListener('click', function () {
				var idx = benefitList.querySelectorAll('.sp-benefit-row').length;
				var opts = '<option value="play-circle">VOD / 영상</option><option value="check-square">체크리스트</option><option value="award">수료증 / 인증</option><option value="gift">선물 / 보너스</option><option value="message-circle">Q&A / 커뮤니티</option><option value="users">커뮤니티 / 그룹</option><option value="file-text">템플릿 / 문서</option><option value="book-open">워크북 / 교재</option><option value="zap">자동화 / 효율</option><option value="trending-up">성장 / 스케일</option><option value="video">라이브 / 화상</option><option value="headphones">1:1 상담</option>';
				var html = '<div class="sp-benefit-row" data-index="' + idx + '">' +
					'<select name="sp_benefits[' + idx + '][icon]" style="width:140px;">' + opts + '</select>' +
					'<input type="text" name="sp_benefits[' + idx + '][title]" value="" class="hello-child-meta-input" placeholder="제목" style="flex:1;">' +
					'<input type="text" name="sp_benefits[' + idx + '][desc]" value="" class="hello-child-meta-input" placeholder="설명" style="flex:2;">' +
					'<button type="button" class="hello-child-cta-remove sp-benefit-remove" title="삭제">&times;</button></div>';
				benefitList.insertAdjacentHTML('beforeend', html);
			});
		}

		if (benefitList) {
			benefitList.addEventListener('click', function (e) {
				if (e.target.classList.contains('sp-benefit-remove')) {
					if (benefitList.querySelectorAll('.sp-benefit-row').length > 1) {
						e.target.closest('.sp-benefit-row').remove();
					}
				}
			});
		}

		/* =====================================================================
		   6. FAQ 리피터
		   ===================================================================== */
		var faqList = document.getElementById('sp-faq-list');
		var faqAdd  = document.getElementById('sp-faq-add');

		if (faqAdd) {
			faqAdd.addEventListener('click', function () {
				var idx = faqList.querySelectorAll('.sp-faq-row').length;
				var html = '<div class="sp-faq-row" data-index="' + idx + '">' +
					'<input type="text" name="sp_faq[' + idx + '][q]" value="" class="hello-child-meta-input" placeholder="질문" style="margin-bottom:4px;">' +
					'<textarea name="sp_faq[' + idx + '][a]" rows="2" class="hello-child-meta-textarea" placeholder="답변"></textarea>' +
					'<button type="button" class="hello-child-cta-remove sp-faq-remove" title="삭제" style="position:absolute;top:8px;right:8px;">&times;</button></div>';
				faqList.insertAdjacentHTML('beforeend', html);
			});
		}

		if (faqList) {
			faqList.addEventListener('click', function (e) {
				if (e.target.classList.contains('sp-faq-remove')) {
					if (faqList.querySelectorAll('.sp-faq-row').length > 1) {
						e.target.closest('.sp-faq-row').remove();
					}
				}
			});
		}

	});
})();
