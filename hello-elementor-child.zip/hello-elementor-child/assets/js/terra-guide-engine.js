/**
 * Terra Guide Engine — 범용 인터랙티브 가이드 시스템
 *
 * 어떤 wp-admin 페이지에서든 가이드를 등록하고 실행할 수 있다.
 * Vue SPA 페이지 대응 (MutationObserver로 DOM 대기).
 * URL 파라미터 terra-guide={id} 로 자동 시작 지원.
 *
 * 사용법:
 *   TerraGuide.register({ id, steps, triggerText, ... });
 *
 * @package HelloElementorChild
 */
window.TerraGuide = (function () {
	'use strict';

	var registry = {};     // 등록된 가이드 { id: config }
	var activeGuide = null; // 현재 실행 중인 가이드 ID
	var currentStep = 0;
	var activeTarget = null; // 현재 하이라이트된 타겟 (z-index 복원용)
	var activeTargetOriginalStyles = {}; // 원래 스타일 백업

	// DOM 요소
	var overlay = null;
	var spotlight = null;
	var tooltip = null;
	var observer = null;

	// ═══════════════════════════════════════════════════
	// 공개 API
	// ═══════════════════════════════════════════════════

	/**
	 * 가이드 등록
	 * @param {Object} config
	 * @param {string} config.id            - 고유 ID (예: 'tosspay_settings')
	 * @param {Array}  config.steps         - 스텝 배열 [{target, title, desc, position, scrollTarget}]
	 * @param {string} [config.triggerText]  - 배너 메시지 (기본: '단계별 가이드를 따라해보세요.')
	 * @param {string} [config.triggerTarget]- 배너 삽입 위치 CSS 선택자 (기본: '.wrap')
	 * @param {string} [config.hash]        - Vue SPA 해시 라우트 (예: '#/kakao/settings')
	 * @param {boolean}[config.autoStart]   - 배너 없이 바로 시작 (URL 파라미터 시)
	 */
	function register(config) {
		if (!config.id || !config.steps || !config.steps.length) return;
		registry[config.id] = config;
	}

	/**
	 * 가이드 시작
	 * @param {string} guideId
	 */
	function start(guideId) {
		var config = registry[guideId];
		if (!config) return;

		activeGuide = guideId;
		currentStep = 0;

		createUI();
		document.addEventListener('keydown', onKeyDown);

		// Vue SPA 대응: hash 라우트 이동
		if (config.hash && window.location.hash !== config.hash) {
			window.location.hash = config.hash;
		}

		// 이벤트 버블링 후 실행되도록 지연
		setTimeout(function () { showStep(0); }, 100);
	}

	/**
	 * 가이드 종료
	 */
	function stop() {
		destroy();
	}

	/**
	 * 현재 페이지에 맞는 가이드 초기화
	 * - URL 파라미터 terra-guide={id} → 자동 시작
	 * - 등록된 가이드가 있으면 배너 표시
	 */
	function init() {
		var urlGuideId = getUrlParam('terra-guide');

		if (urlGuideId && registry[urlGuideId]) {
			// URL 파라미터로 자동 시작 — 배너 없이 바로
			var config = registry[urlGuideId];

			// dismiss 체크
			if (isDismissed(urlGuideId)) {
				insertBanner(urlGuideId);
				return;
			}

			start(urlGuideId);
			return;
		}

		// URL 파라미터 없으면 배너만 표시
		Object.keys(registry).forEach(function (id) {
			if (!isDismissed(id)) {
				insertBanner(id);
			}
		});
	}

	// ═══════════════════════════════════════════════════
	// UI 생성/제거
	// ═══════════════════════════════════════════════════

	function createUI() {
		// 기존 UI DOM만 정리 (activeGuide는 유지)
		if (observer) { observer.disconnect(); observer = null; }
		if (overlay) { overlay.remove(); overlay = null; }
		if (spotlight) { spotlight.remove(); spotlight = null; }
		if (tooltip) { tooltip.remove(); tooltip = null; }

		overlay = document.createElement('div');
		overlay.className = 'terra-onboard-overlay';
		document.body.appendChild(overlay);

		spotlight = document.createElement('div');
		spotlight.className = 'terra-onboard-spotlight';
		document.body.appendChild(spotlight);

		tooltip = document.createElement('div');
		tooltip.className = 'terra-onboard-tooltip';
		tooltip.innerHTML =
			'<div class="terra-onboard-tooltip__header">' +
			'  <span class="terra-onboard-tooltip__step"></span>' +
			'  <button type="button" class="terra-onboard-tooltip__close" aria-label="\ub2eb\uae30">&times;</button>' +
			'</div>' +
			'<h4 class="terra-onboard-tooltip__title"></h4>' +
			'<p class="terra-onboard-tooltip__desc"></p>' +
			'<img class="terra-onboard-tooltip__img" style="display:none;" />' +
			'<div class="terra-onboard-tooltip__actions">' +
			'  <button type="button" class="terra-onboard-btn terra-onboard-btn--prev">\uc774\uc804</button>' +
			'  <a class="terra-onboard-btn terra-onboard-btn--doc" target="_blank" rel="noopener" style="display:none;">\uc0c1\uc138 \ubcf4\uae30</a>' +
			'  <button type="button" class="terra-onboard-btn terra-onboard-btn--next">\ub2e4\uc74c</button>' +
			'</div>';
		document.body.appendChild(tooltip);

		tooltip.querySelector('.terra-onboard-tooltip__close').addEventListener('click', function () { destroy(); });
		tooltip.querySelector('.terra-onboard-btn--prev').addEventListener('click', prevStep);
		tooltip.querySelector('.terra-onboard-btn--next').addEventListener('click', nextStep);
		// overlay 자체 클릭만 감지 (자식 요소 클릭이나 이벤트 버블링 무시)
		overlay.addEventListener('click', function (e) {
			if (e.target === overlay) { destroy(); }
		});
	}

	function destroy(skipSave) {
		var closedGuideId = activeGuide;
		restoreTarget();
		if (observer) { observer.disconnect(); observer = null; }
		if (overlay) { overlay.remove(); overlay = null; }
		if (spotlight) { spotlight.remove(); spotlight = null; }
		if (tooltip) { tooltip.remove(); tooltip = null; }
		document.removeEventListener('keydown', onKeyDown);

		if (!skipSave && closedGuideId) {
			saveDismiss(closedGuideId);
			// 플로팅 "가이드 다시 보기" 버튼 표시
			showResumeButton(closedGuideId);
		}
		activeGuide = null;
	}

	// 가이드 닫힌 후 다시 시작할 수 있는 플로팅 버튼
	function showResumeButton(guideId) {
		// 이미 있으면 제거
		var existing = document.getElementById('terra-guide-resume');
		if (existing) existing.remove();

		var btn = document.createElement('button');
		btn.id = 'terra-guide-resume';
		btn.className = 'terra-guide-resume-btn';
		btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg> \uac00\uc774\ub4dc \ub2e4\uc2dc \ubcf4\uae30';
		document.body.appendChild(btn);

		btn.addEventListener('click', function () {
			btn.remove();
			// dismiss 상태 초기화
			try {
				var dismissed = JSON.parse(localStorage.getItem('terra_guide_dismissed') || '{}');
				delete dismissed[guideId];
				localStorage.setItem('terra_guide_dismissed', JSON.stringify(dismissed));
			} catch (e) {}
			start(guideId);
		});

		// 10초 후 자동 페이드아웃 (완전 제거는 아님, 호버하면 다시 보임)
		setTimeout(function () {
			if (btn.parentNode) btn.classList.add('terra-guide-resume-fade');
		}, 10000);
	}

	// ═══════════════════════════════════════════════════
	// 스텝 표시
	// ═══════════════════════════════════════════════════

	function getSteps() {
		if (!activeGuide || !registry[activeGuide]) return [];
		return registry[activeGuide].steps;
	}

	function showStep(index) {
		var steps = getSteps();
		var step = steps[index];
		if (!step) return;

		var target = document.querySelector(step.target);
		if (!target) {
			// 타겟이 없으면 MutationObserver로 대기 (최대 3초)
			waitForTarget(step.target, function (el) {
				if (el) {
					renderStep(el, step, index);
				} else if (index < steps.length - 1) {
					// 시간 초과 시 다음 스텝
					currentStep = index + 1;
					showStep(currentStep);
				}
			}, 3000);
			return;
		}

		renderStep(target, step, index);
	}

	// 이전 타겟의 스타일 복원
	function restoreTarget() {
		if (activeTarget) {
			activeTarget.style.position = activeTargetOriginalStyles.position || '';
			activeTarget.style.zIndex = activeTargetOriginalStyles.zIndex || '';
			activeTarget.style.pointerEvents = activeTargetOriginalStyles.pointerEvents || '';
			activeTarget = null;
			activeTargetOriginalStyles = {};
		}
	}

	// 타겟을 overlay 위로 올려서 클릭/입력 가능하게
	function elevateTarget(target) {
		restoreTarget();
		activeTarget = target;
		activeTargetOriginalStyles = {
			position: target.style.position,
			zIndex: target.style.zIndex,
			pointerEvents: target.style.pointerEvents
		};
		// position이 static이면 relative로 변경해야 z-index 적용됨
		var computed = window.getComputedStyle(target);
		if (computed.position === 'static') {
			target.style.position = 'relative';
		}
		target.style.zIndex = '99995'; // overlay(99990) + spotlight(99991) 위
		target.style.pointerEvents = 'auto';
	}

	function renderStep(target, step, index) {
		var steps = getSteps();
		if (!steps || !steps.length) return;

		// 타겟을 overlay 위로 올려서 입력 가능하게
		elevateTarget(target);

		// 스크롤
		var scrollEl = step.scrollTarget ? document.querySelector(step.scrollTarget) : target;
		if (scrollEl) {
			scrollEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
		}

		function applyPosition() {
			if (!spotlight || !tooltip) return;
			positionSpotlight(target);

			// 이미지가 있으면 넓은 팝업 + 왼쪽 오프셋
			if (step.image) {
				tooltip.classList.add('terra-onboard-tooltip--wide');
			} else {
				tooltip.classList.remove('terra-onboard-tooltip--wide');
			}

			positionTooltip(target, step);

			// 툴팁 내용
			tooltip.querySelector('.terra-onboard-tooltip__step').textContent =
				(index + 1) + ' / ' + steps.length;
			tooltip.querySelector('.terra-onboard-tooltip__title').textContent = step.title;
			var descEl = tooltip.querySelector('.terra-onboard-tooltip__desc');
			descEl.innerHTML = escHtml(step.desc).replace(/\n/g, '<br>');

			var prevBtn = tooltip.querySelector('.terra-onboard-btn--prev');
			var docBtn = tooltip.querySelector('.terra-onboard-btn--doc');
			var nextBtn = tooltip.querySelector('.terra-onboard-btn--next');
			var imgEl = tooltip.querySelector('.terra-onboard-tooltip__img');

			prevBtn.style.visibility = index === 0 ? 'hidden' : 'visible';
			nextBtn.textContent = index === steps.length - 1 ? '\uc644\ub8cc' : '\ub2e4\uc74c';

			// 상세 보기 버튼 (외부 문서 링크)
			if (step.docUrl) {
				docBtn.href = step.docUrl;
				docBtn.style.display = 'inline-flex';
			} else {
				docBtn.style.display = 'none';
			}

			// 참고 이미지
			if (step.image) {
				imgEl.src = step.image;
				imgEl.alt = step.title;
				imgEl.style.display = 'block';
			} else {
				imgEl.style.display = 'none';
			}
		}

		// 즉시 한번 + 스크롤 완료 후 한번
		requestAnimationFrame(applyPosition);
		setTimeout(applyPosition, 400);
	}

	// ═══════════════════════════════════════════════════
	// 위치 계산
	// ═══════════════════════════════════════════════════

	function positionSpotlight(target) {
		var rect = target.getBoundingClientRect();
		var pad = 8;
		spotlight.style.top = (rect.top + window.scrollY - pad) + 'px';
		spotlight.style.left = (rect.left + window.scrollX - pad) + 'px';
		spotlight.style.width = (rect.width + pad * 2) + 'px';
		spotlight.style.height = (rect.height + pad * 2) + 'px';
	}

	function positionTooltip(target, step) {
		// tooltipAnchor: 팝업 위치를 다른 요소 기준으로 계산
		var anchorEl = step.tooltipAnchor ? document.querySelector(step.tooltipAnchor) : null;
		var rect = (anchorEl || target).getBoundingClientRect();
		var isWide = tooltip.classList.contains('terra-onboard-tooltip--wide');
		var tw = isWide ? Math.min(520, window.innerWidth - 40) : Math.min(360, window.innerWidth - 40);
		var pos = step.position || 'bottom';

		tooltip.style.width = tw + 'px';
		tooltip.style.position = 'absolute'; // 기본값 복원

		var top, left;

		if (pos === 'fixed-right') {
			// 뷰포트 세로 중앙 + 우측 사이드바 왼쪽에 fixed 위치
			// wp-admin 사이드바 패널의 왼쪽 = 본문 영역의 오른쪽 끝
			var sidePanel = document.getElementById('postbox-container-1') || document.getElementById('side-sortables');
			var sideLeft = sidePanel ? sidePanel.getBoundingClientRect().left : (window.innerWidth - 300);
			var th = tooltip.offsetHeight || 280;

			tooltip.style.position = 'fixed';
			tooltip.style.top = Math.max(60, (window.innerHeight - th) / 2) + 'px';
			tooltip.style.left = Math.max(10, sideLeft - tw - 20) + 'px';
			return;
		}

		if (pos === 'bottom') {
			top = rect.bottom + window.scrollY + 16;
			left = rect.left + window.scrollX + (rect.width / 2) - (tw / 2);
		} else if (pos === 'top') {
			top = rect.top + window.scrollY - tooltip.offsetHeight - 16;
			left = rect.left + window.scrollX + (rect.width / 2) - (tw / 2);
		} else if (pos === 'left') {
			top = rect.top + window.scrollY;
			left = rect.left + window.scrollX - tw - 16;
		} else {
			// right
			top = rect.top + window.scrollY;
			left = isWide
				? rect.left + window.scrollX + rect.width - tw + 40
				: rect.right + window.scrollX + 16;
		}

		if (left < 10) left = 10;
		if (left + tw > window.innerWidth - 10) left = window.innerWidth - tw - 10;

		tooltip.style.top = top + 'px';
		tooltip.style.left = left + 'px';
	}

	// ═══════════════════════════════════════════════════
	// 네비게이션
	// ═══════════════════════════════════════════════════

	function nextStep() {
		var steps = getSteps();
		if (currentStep < steps.length - 1) {
			currentStep++;
			showStep(currentStep);
		} else {
			destroy();
		}
	}

	function prevStep() {
		if (currentStep > 0) {
			currentStep--;
			showStep(currentStep);
		}
	}

	function onKeyDown(e) {
		if (!overlay) return;
		if (e.key === 'Escape') destroy();
		if (e.key === 'ArrowRight' || e.key === 'Enter') nextStep();
		if (e.key === 'ArrowLeft') prevStep();
	}

	// ═══════════════════════════════════════════════════
	// 배너
	// ═══════════════════════════════════════════════════

	function insertBanner(guideId) {
		var config = registry[guideId];
		if (!config) return;

		var wrap = document.querySelector(config.triggerTarget || '.wrap');
		if (!wrap) return;

		// 이미 같은 가이드의 배너가 있으면 중복 방지
		if (wrap.querySelector('[data-terra-guide-banner="' + guideId + '"]')) return;

		var banner = document.createElement('div');
		banner.className = 'terra-onboard-banner';
		banner.setAttribute('data-terra-guide-banner', guideId);
		banner.innerHTML =
			'<div class="terra-onboard-banner__content">' +
			'  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>' +
			'  <span>' + escHtml(config.triggerText || '\ub2e8\uacc4\ubcc4 \uac00\uc774\ub4dc\ub97c \ub530\ub77c\ud574\ubcf4\uc138\uc694.') + '</span>' +
			'</div>' +
			'<div class="terra-onboard-banner__actions">' +
			'  <button type="button" class="terra-onboard-banner__start">\uac00\uc774\ub4dc \uc2dc\uc791</button>' +
			'  <button type="button" class="terra-onboard-banner__dismiss">\ub2eb\uae30</button>' +
			'</div>';

		wrap.insertBefore(banner, wrap.firstChild);

		banner.querySelector('.terra-onboard-banner__start').addEventListener('click', function (e) {
			e.stopPropagation();
			banner.style.display = 'none';
			start(guideId);
		});

		banner.querySelector('.terra-onboard-banner__dismiss').addEventListener('click', function (e) {
			e.stopPropagation();
			banner.style.display = 'none';
			saveDismiss(guideId);
		});
	}

	// ═══════════════════════════════════════════════════
	// DOM 대기 (Vue SPA 대응)
	// ═══════════════════════════════════════════════════

	function waitForTarget(selector, callback, timeout) {
		timeout = timeout || 5000;

		// 즉시 체크
		var el = document.querySelector(selector);
		if (el) { callback(el); return; }

		// MutationObserver로 대기
		var timer = null;
		observer = new MutationObserver(function () {
			var found = document.querySelector(selector);
			if (found) {
				observer.disconnect();
				observer = null;
				if (timer) clearTimeout(timer);
				callback(found);
			}
		});

		observer.observe(document.body, { childList: true, subtree: true });

		// 타임아웃
		timer = setTimeout(function () {
			if (observer) { observer.disconnect(); observer = null; }
			callback(null);
		}, timeout);
	}

	// ═══════════════════════════════════════════════════
	// Dismiss 상태 관리
	// ═══════════════════════════════════════════════════

	function saveDismiss(guideId) {
		// REST API로 user_meta에 저장
		var nonce = (window.terraDashboard && window.terraDashboard.nonce) ||
		            (window.terraGuideNonce) || '';
		var restUrl = (window.terraDashboard && window.terraDashboard.restUrl) ||
		              '/wp-json/';

		fetch(restUrl + 'terra-dashboard/v1/guide-dismiss', {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': nonce
			},
			body: JSON.stringify({ guide: guideId })
		}).catch(function () {});

		// 로컬 캐시도 업데이트
		try {
			var dismissed = JSON.parse(localStorage.getItem('terra_guide_dismissed') || '{}');
			dismissed[guideId] = true;
			localStorage.setItem('terra_guide_dismissed', JSON.stringify(dismissed));
		} catch (e) {}
	}

	function isDismissed(guideId) {
		try {
			var dismissed = JSON.parse(localStorage.getItem('terra_guide_dismissed') || '{}');
			return !!dismissed[guideId];
		} catch (e) {
			return false;
		}
	}

	// ═══════════════════════════════════════════════════
	// 유틸
	// ═══════════════════════════════════════════════════

	function getUrlParam(name) {
		var params = new URLSearchParams(window.location.search);
		return params.get(name);
	}

	function escHtml(str) {
		var div = document.createElement('div');
		div.textContent = str;
		return div.innerHTML;
	}

	// ═══════════════════════════════════════════════════
	// 공개 인터페이스
	// ═══════════════════════════════════════════════════
	return {
		register: register,
		start: start,
		stop: stop,
		init: init
	};

})();
