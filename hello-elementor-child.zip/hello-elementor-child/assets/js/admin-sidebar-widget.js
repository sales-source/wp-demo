/**
 * 사이드바 홍보 위젯 — 썸네일 미디어 업로더
 */
(function ($) {
	'use strict';

	$(document).ready(function () {
		var frame;

		$('#hello-child-sw-upload').on('click', function (e) {
			e.preventDefault();

			if (frame) {
				frame.open();
				return;
			}

			frame = wp.media({
				title: '썸네일 이미지 선택',
				button: { text: '선택' },
				multiple: false,
				library: { type: 'image' }
			});

			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				var url = attachment.sizes && attachment.sizes.medium
					? attachment.sizes.medium.url
					: attachment.url;

				$('#hello-child-sw-thumb-id').val(attachment.id);
				$('#hello-child-sw-preview').show().find('img').attr('src', url);
				$('#hello-child-sw-remove').show();
			});

			frame.open();
		});

		$('#hello-child-sw-remove').on('click', function (e) {
			e.preventDefault();
			$('#hello-child-sw-thumb-id').val('');
			$('#hello-child-sw-preview').hide();
			$(this).hide();
		});
	});
})(jQuery);
