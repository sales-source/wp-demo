/**
 * 목차(TOC) 스크롤 스파이 — 현재 읽고 있는 섹션 하이라이트
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var links = document.querySelectorAll('.hc-toc-link');
		if (!links.length) return;

		var headings = [];
		links.forEach(function (link) {
			var id = link.getAttribute('href').replace('#', '');
			var el = document.getElementById(id);
			if (el) headings.push({ el: el, link: link });
		});

		if (!headings.length) return;

		function onScroll() {
			var scrollY = window.scrollY + 120;
			var current = null;

			for (var i = 0; i < headings.length; i++) {
				if (headings[i].el.offsetTop <= scrollY) {
					current = headings[i];
				}
			}

			links.forEach(function (l) { l.classList.remove('is-active'); });
			if (current) current.link.classList.add('is-active');
		}

		var ticking = false;
		window.addEventListener('scroll', function () {
			if (!ticking) {
				requestAnimationFrame(function () {
					onScroll();
					ticking = false;
				});
				ticking = true;
			}
		});

		onScroll();

		// ── 모바일 collapsible TOC ──
		var toc = document.querySelector('.hc-toc');
		var tocHeading = document.querySelector('.hc-toc-heading');
		if (toc && tocHeading) {
			tocHeading.addEventListener('click', function () {
				toc.classList.toggle('is-open');
			});

			// 목차 링크 클릭 시 접기
			var tocLinks = toc.querySelectorAll('.hc-toc-link');
			tocLinks.forEach(function (link) {
				link.addEventListener('click', function () {
					if (window.innerWidth <= 1024) {
						toc.classList.remove('is-open');
					}
				});
			});
		}
	});
})();
