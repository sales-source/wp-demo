/**
 * 싱글 프로덕트 — 갤러리 캐러셀 + 탭 + 공유 팝업
 *
 * @package HelloElementorChild
 */

(function () {
	'use strict';

	/* ── 갤러리 썸네일 → 대표 이미지 교체 ── */
	function initGallery() {
		var featured = document.getElementById('sp-featured-img');
		var thumbs = document.querySelectorAll('.sp-gallery__thumb');
		if (!featured || thumbs.length === 0) return;

		var imageMap = {};
		thumbs.forEach(function (btn) {
			var img = btn.querySelector('.sp-gallery__thumb-img');
			if (!img) return;
			imageMap[btn.getAttribute('data-img-id')] = {
				src: img.src.replace(/-\d+x\d+(\.\w+)$/, '$1'),
			};
		});

		thumbs.forEach(function (btn) {
			btn.addEventListener('click', function () {
				var data = imageMap[this.getAttribute('data-img-id')];
				thumbs.forEach(function (t) { t.classList.remove('is-active'); });
				this.classList.add('is-active');
				featured.style.opacity = '0';
				setTimeout(function () {
					if (data && data.src) {
						featured.srcset = '';
						featured.src = data.src;
					}
					featured.style.opacity = '1';
				}, 150);
			});
		});

		featured.style.transition = 'opacity 150ms ease';

		// 메인 이미지 좌우 화살표
		var prevArrow = document.querySelector('.sp-gallery__arrow--prev');
		var nextArrow = document.querySelector('.sp-gallery__arrow--next');
		if (prevArrow && nextArrow) {
			var thumbArray = Array.prototype.slice.call(thumbs);
			function getCurrentIndex() {
				for (var i = 0; i < thumbArray.length; i++) {
					if (thumbArray[i].classList.contains('is-active')) return i;
				}
				return 0;
			}
			prevArrow.addEventListener('click', function () {
				var idx = getCurrentIndex();
				var prev = idx > 0 ? idx - 1 : thumbArray.length - 1;
				thumbArray[prev].click();
			});
			nextArrow.addEventListener('click', function () {
				var idx = getCurrentIndex();
				var next = idx < thumbArray.length - 1 ? idx + 1 : 0;
				thumbArray[next].click();
			});
		}
	}

	/* ── Swiper 초기화 ── */
	function initSwiper() {
		if (!document.querySelector('.sp-gallery-swiper') || typeof Swiper === 'undefined') return;
		new Swiper('.sp-gallery-swiper', {
			slidesPerView: 'auto',
			spaceBetween: 8,
			freeMode: true,
			watchOverflow: true,
			navigation: {
				prevEl: '.sp-gallery__nav--prev',
				nextEl: '.sp-gallery__nav--next',
			},
		});
	}

	/* ── 탭 전환 + 앵커 ── */
	function initTabs() {
		var tabs = document.querySelectorAll('.sp-tabs__btn');
		var panels = document.querySelectorAll('.sp-panel');
		if (tabs.length === 0) return;

		function activateTab(tabName, scroll) {
			tabs.forEach(function (t) { t.classList.remove('is-active'); });
			panels.forEach(function (p) { p.classList.remove('is-active'); });

			tabs.forEach(function (t) {
				if (t.getAttribute('data-tab') === tabName) t.classList.add('is-active');
			});

			var panel = document.getElementById('sp-panel-' + tabName);
			if (panel) panel.classList.add('is-active');

			// URL 해시 업데이트 (히스토리에 추가하지 않음)
			history.replaceState(null, '', '#' + tabName);

			// 탭 네비게이션 위치로 스크롤
			if (scroll) {
				var tabsNav = document.getElementById('sp-tabs');
				if (tabsNav) {
					tabsNav.scrollIntoView({ behavior: 'smooth', block: 'start' });
				}
			}
		}

		tabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				activateTab(this.getAttribute('data-tab'), true);
			});
		});

		// 페이지 로드 시 해시에 따라 탭 활성화
		var hash = window.location.hash.replace('#', '');
		if (hash === 'reviews' || hash === 'detail') {
			activateTab(hash, false);
		}
	}

	/* ── 공유 팝업 ── */
	function initSharePopup() {
		var toggle = document.getElementById('sp-share-toggle');
		var popup = document.getElementById('sp-share-popup');
		var close = document.getElementById('sp-share-close');
		if (!toggle || !popup) return;

		toggle.addEventListener('click', function () {
			popup.classList.toggle('is-open');
		});

		if (close) {
			close.addEventListener('click', function () {
				popup.classList.remove('is-open');
			});
		}

		// 팝업 외부 클릭 시 닫기
		document.addEventListener('click', function (e) {
			if (!popup.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
				popup.classList.remove('is-open');
			}
		});

		// 링크 복사
		var linkBtn = document.getElementById('sp-share-link');
		if (linkBtn) {
			linkBtn.addEventListener('click', function () {
				var url = window.location.href.split('#')[0];
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(url).then(function () {
						showToast('링크가 복사되었습니다');
						popup.classList.remove('is-open');
					});
				} else {
					var ta = document.createElement('textarea');
					ta.value = url;
					ta.style.cssText = 'position:fixed;opacity:0';
					document.body.appendChild(ta);
					ta.select();
					document.execCommand('copy');
					document.body.removeChild(ta);
					showToast('링크가 복사되었습니다');
					popup.classList.remove('is-open');
				}
			});
		}

		// 카카오톡 공유
		var kakaoBtn = document.getElementById('sp-share-kakao');
		if (kakaoBtn) {
			kakaoBtn.addEventListener('click', function () {
				if (typeof Kakao !== 'undefined' && Kakao.isInitialized && Kakao.isInitialized()) {
					Kakao.Share.sendDefault({
						objectType: 'feed',
						content: {
							title: document.querySelector('.sp-sidebar__title')
								? document.querySelector('.sp-sidebar__title').textContent : document.title,
							description: document.querySelector('.sp-sidebar__excerpt')
								? document.querySelector('.sp-sidebar__excerpt').textContent : '',
							imageUrl: document.getElementById('sp-featured-img')
								? document.getElementById('sp-featured-img').src : '',
							link: {
								mobileWebUrl: window.location.href,
								webUrl: window.location.href,
							},
						},
					});
				} else {
					showToast('카카오톡 SDK가 초기화되지 않았습니다');
				}
				popup.classList.remove('is-open');
			});
		}

		// 쓰레드 공유
		var threadsBtn = document.getElementById('sp-share-threads');
		if (threadsBtn) {
			threadsBtn.addEventListener('click', function () {
				var title = document.querySelector('.sp-sidebar__title')
					? document.querySelector('.sp-sidebar__title').textContent : document.title;
				var url = window.location.href.split('#')[0];
				window.open('https://www.threads.net/intent/post?text=' + encodeURIComponent(title + ' ' + url), '_blank', 'width=550,height=420');
				popup.classList.remove('is-open');
			});
		}

		// Facebook 공유
		var fbBtn = document.getElementById('sp-share-facebook');
		if (fbBtn) {
			fbBtn.addEventListener('click', function () {
				var url = window.location.href.split('#')[0];
				window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(url), '_blank', 'width=550,height=420');
				popup.classList.remove('is-open');
			});
		}

		// 인스타그램 (링크 복사 후 안내)
		var instaBtn = document.getElementById('sp-share-instagram');
		if (instaBtn) {
			instaBtn.addEventListener('click', function () {
				var url = window.location.href.split('#')[0];
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(url).then(function () {
						showToast('링크가 복사되었습니다. 인스타그램 스토리에 붙여넣기 하세요');
					});
				}
				popup.classList.remove('is-open');
			});
		}
	}

	/* ── 토스트 ── */
	function showToast(message) {
		var existing = document.querySelector('.sp-toast');
		if (existing) existing.remove();

		var toast = document.createElement('div');
		toast.className = 'sp-toast';
		toast.textContent = message;
		document.body.appendChild(toast);

		requestAnimationFrame(function () { toast.classList.add('is-visible'); });
		setTimeout(function () {
			toast.classList.remove('is-visible');
			setTimeout(function () { toast.remove(); }, 300);
		}, 2000);
	}

	/* ── 초기화 ── */
	function init() {
		initGallery();
		initSwiper();
		initTabs();
		initSharePopup();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
