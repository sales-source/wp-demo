/**
 * 블로그 글 작성 인터랙티브 가이드 — TerraGuide 엔진에 등록
 */
TerraGuide.register({
	id: 'blog_post',
	triggerText: '처음 글을 작성하시나요? 단계별 가이드를 따라해보세요.',
	triggerTarget: '#poststuff',
	steps: [
		{
			target: '#title',
			title: '1단계: 글 제목 입력',
			desc: 'SEO에 최적화된 제목을 입력하세요. 핵심 키워드를 앞쪽에 배치하면 검색 노출에 유리합니다.',
			position: 'bottom'
		},
		{
			target: '#wp-content-editor-container, #wp-content-wrap',
			title: '2단계: 본문 작성',
			desc: 'H2/H3 태그로 구조를 잡고 본문을 작성하세요. 이미지, 리스트, 인용문을 활용하면 가독성이 높아집니다.',
			position: 'bottom'
		},
		{
			target: '#hello_child_key_answer',
			title: '3단계: 핵심 답변',
			desc: '이 글의 핵심을 1~2문장으로 요약하세요. 글 상단에 강조 박스로 자동 표시됩니다.',
			position: 'bottom',
			scrollTarget: '#hello_child_key_answer'
		},
		{
			target: '#hello_child_tldr',
			title: '4단계: 3줄 요약',
			desc: '핵심 포인트 3가지를 입력하세요. 목차 위에 요약 카드로 자동 표시됩니다.',
			position: 'bottom',
			scrollTarget: '#hello_child_tldr'
		},
		{
			target: '#hello_child_cta',
			title: '5단계: CTA (Call to Action)',
			desc: '독자에게 다음 행동을 유도하세요. 설명과 URL을 입력하면 본문 하단에 버튼으로 표시됩니다.',
			position: 'top',
			scrollTarget: '#hello_child_cta'
		},
		{
			target: '#publish',
			title: '6단계: 발행',
			desc: '모든 필드를 확인한 후 공개 버튼을 클릭하세요.',
			position: 'left',
			scrollTarget: '#submitdiv'
		}
	]
});
TerraGuide.init();
