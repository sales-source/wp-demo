<?php
/**
 * 푸터 — Elementor Theme Builder 템플릿 (확정본)
 *
 * 이 파일은 Elementor에서 디자인 확정 후 export된 데이터입니다.
 * 테마 활성화 시 이 데이터로 Elementor Library에 푸터가 자동 생성됩니다.
 *
 * Export 일시: 2026-04-09 03:39:12
 * Source: elementor_library post ID 273
 * Tool: tools/export-elementor-templates.php
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array (
  0 => array(
    'id' => 'ftr_main',
    'elType' => 'section',
    'settings' => array(
      'structure' => '20',
      'background_background' => 'classic',
      'background_color' => '#F8F9FA',
      'padding' => array(
        'unit' => 'px',
        'top' => '56',
        'right' => '40',
        'bottom' => '56',
        'left' => '40',
        'isLinked' => false,
      ),
      'padding_mobile' => array(
        'unit' => 'px',
        'top' => '60',
        'right' => '20',
        'bottom' => '60',
        'left' => '20',
        'isLinked' => false,
      ),
      'border_border' => 'solid',
      'border_width' => array(
        'unit' => 'px',
        'top' => '1',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
        'isLinked' => false,
      ),
      'border_color' => '#E5E8EB',
      'content_width' => array(
        'unit' => 'px',
        'size' => 1131,
        'sizes' => array(
        ),
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'ftr_left',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 50,
          '_inline_size' => 20.557,
          'margin_mobile' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          'padding_mobile' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
        ),
        'elements' => array(
          0 => array(
            'id' => 'ftr_logo',
            'elType' => 'widget',
            'settings' => array(
              'title_color' => '#191F28',
              'typography_typography' => 'custom',
              'typography_font_family' => 'Pretendard',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 28,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '700',
              'header_size' => 'h4',
              'link' => array(
                'url' => '/',
                'is_external' => false,
              ),
              '_margin' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '16',
                'left' => '0',
                'isLinked' => false,
              ),
              '__dynamic__' => array(
                'title' => '[elementor-tag id="" name="site-title" settings="%7B%22before%22%3A%22%22%2C%22after%22%3A%22%22%2C%22fallback%22%3A%22%22%7D"]',
                'link' => '[elementor-tag id="" name="site-url" settings="%7B%7D"]',
              ),
              'title' => '여기에 제목 텍스트 추가',
              'align_mobile' => 'center',
              'typography_font_size_mobile' => array(
                'unit' => 'px',
                'size' => 20,
                'sizes' => array(
                ),
              ),
              'typography_font_size_tablet' => array(
                'unit' => 'px',
                'size' => 25,
                'sizes' => array(
                ),
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'theme-site-title',
          ),
        ),
        'isInner' => false,
      ),
      1 => array(
        'id' => 'ftr_right',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 50,
          '_inline_size' => 79.443,
          'content_position' => 'top',
          'align' => 'right',
          'margin' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          'padding' => array(
            'unit' => 'px',
            'top' => '10',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
        ),
        'elements' => array(
          0 => array(
            'id' => 'ftr_nav_menu',
            'elType' => 'widget',
            'settings' => array(
              'menu' => '__FOOTER_MENU__',
              'align_items' => 'flex-start',
              'toggle' => 'none',
              'color_menu_item' => '#8B95A1',
              'color_menu_item_hover' => '#0064FF',
              'color_menu_item_active' => '#4E5968',
              'pointer' => 'none',
              'typography_menu_typography' => 'custom',
              'typography_menu_font_family' => 'Pretendard',
              'typography_menu_font_size' => array(
                'unit' => 'px',
                'size' => 14,
                'sizes' => array(
                ),
              ),
              'typography_menu_font_weight' => '400',
              'padding_vertical_menu_item' => array(
                'unit' => 'px',
                'size' => 6,
                'sizes' => array(
                ),
              ),
              'menu_name' => 'Menu',
              'dropdown' => 'none',
              'menu_typography_typography' => 'custom',
              'menu_typography_font_weight' => '400',
              'nav_menu_divider' => 'yes',
              'nav_menu_divider_color' => '#B1B1B1',
              'padding_horizontal_menu_item_mobile' => array(
                'unit' => 'px',
                'size' => 8,
                'sizes' => array(
                ),
              ),
              'padding_vertical_menu_item_mobile' => array(
                'unit' => 'px',
                'size' => 3,
                'sizes' => array(
                ),
              ),
              '_margin' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'nav-menu',
          ),
          1 => array(
            'id' => 'ftr_biz_info',
            'elType' => 'widget',
            'settings' => array(
              // 검수 미통과 #110: Elementor Pro 활성화 시 사업자 정보가
              // 두 개의 icon-list 위젯(ftr_biz_info + 3ea7560)으로 중복
              // 노출되어 있어 한 위젯으로 통합. 두 번째 위젯은 제거.
              'icon_list' => array(
                0 => array(
                  'text' => '회사명 : 테라클래스',
                  'selected_icon' => array(
                    'value' => '',
                    'library' => '',
                  ),
                  '_id' => 'ftr_biz_1',
                ),
                1 => array(
                  'text' => '대표자 : 홍길동',
                  'selected_icon' => array(
                    'value' => '',
                    'library' => '',
                  ),
                  '_id' => 'ftr_biz_2',
                ),
                2 => array(
                  'text' => '사업장 소재지 : 서울 용산구 한강대로 100',
                  'selected_icon' => array(
                    'value' => '',
                    'library' => '',
                  ),
                  '_id' => 'ftr_biz_3',
                ),
                3 => array(
                  'text' => '사업자등록번호 : 123-123-123',
                  'selected_icon' => array(
                    'value' => '',
                    'library' => '',
                  ),
                  '_id' => 'ftr_biz_4',
                ),
                4 => array(
                  'text' => '이메일 : support@teraclass.net',
                  'selected_icon' => array(
                    'value' => '',
                    'library' => '',
                  ),
                  '_id' => 'ftr_biz_6',
                ),
                5 => array(
                  'text' => '고객 센터 : 02-1234-1234',
                  'selected_icon' => array(
                    'value' => '',
                    'library' => '',
                  ),
                  '_id' => 'ftr_biz_5',
                ),
                6 => array(
                  'text' => '개인정보관리책임자 : 홍 길 동',
                  'selected_icon' => array(
                    'value' => '',
                    'library' => '',
                  ),
                  '_id' => 'ftr_biz_7',
                ),
              ),
              'icon_color' => 'transparent',
              'text_color' => '#8B95A1',
              'typography_typography' => 'custom',
              'typography_font_family' => 'Pretendard',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 13,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '400',
              'typography_line_height' => array(
                'unit' => 'em',
                'size' => 1.7,
                'sizes' => array(
                ),
              ),
              'space_between' => array(
                'unit' => 'px',
                'size' => 16,
                'sizes' => array(
                ),
              ),
              'view' => 'inline',
              'icon_align_mobile' => 'center',
              '_margin' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '20',
                'isLinked' => false,
              ),
              '_padding_mobile' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_margin_tablet' => array(
                'unit' => 'px',
                'top' => '-12',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'icon-list',
          ),
          // 검수 미통과 #110: 중복 사업자정보 icon-list 제거 (ftr_biz_info에 통합)
          2 => array(
            'id' => 'ftr_cr_text',
            'elType' => 'widget',
            'settings' => array(
              'editor' => '<p>© 2026 TeraClass. All rights reserved.</p>',
              'align' => 'start',
              'text_color' => '#8B95A1',
              'typography_typography' => 'custom',
              'typography_font_family' => 'Pretendard',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 13,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '400',
              'align_mobile' => 'center',
              'typography_line_height' => array(
                'unit' => 'em',
                'size' => 1.7,
                'sizes' => array(
                ),
              ),
              '_margin' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '20',
                'isLinked' => false,
              ),
              '_margin_tablet' => array(
                'unit' => 'px',
                'top' => '-10',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_element_width_tablet' => 'initial',
              '_element_custom_width_tablet' => array(
                'unit' => 'px',
                'size' => 513.641,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'text-editor',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
);
