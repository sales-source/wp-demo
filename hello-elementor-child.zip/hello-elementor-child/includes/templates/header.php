<?php
/**
 * 헤더 — Elementor Theme Builder 템플릿 (확정본)
 *
 * 이 파일은 Elementor에서 디자인 확정 후 export된 데이터입니다.
 * 테마 활성화 시 이 데이터로 Elementor Library에 헤더가 자동 생성됩니다.
 *
 * Export 일시: 2026-04-09 03:39:12
 * Source: elementor_library post ID 272
 * Tool: tools/export-elementor-templates.php
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array (
  0 => array(
    'id' => 'hdr_desktop',
    'elType' => 'section',
    'settings' => array(
      'structure' => '30',
      'background_background' => 'classic',
      'background_color' => '#FFFFFF',
      'padding' => array(
        'unit' => 'px',
        'top' => '0',
        'right' => '40',
        'bottom' => '0',
        'left' => '40',
        'isLinked' => false,
      ),
      'hide_mobile' => 'hidden-mobile',
      'border_border' => 'solid',
      'border_width' => array(
        'unit' => 'px',
        'top' => '0',
        'right' => '0',
        'bottom' => '1',
        'left' => '0',
        'isLinked' => false,
      ),
      'border_color' => '#E5E8EB',
      'custom_height' => array(
        'unit' => 'px',
        'size' => 64,
        'sizes' => array(
        ),
      ),
      'padding_tablet' => array(
        'unit' => 'px',
        'top' => '20',
        'right' => '0',
        'bottom' => '0',
        'left' => '20',
        'isLinked' => false,
      ),
      'content_width' => array(
        'unit' => 'px',
        'size' => 1131,
        'sizes' => array(
        ),
      ),
      'sticky' => 'top',
      'custom_height_tablet' => array(
        'unit' => 'px',
        'size' => 0,
        'sizes' => array(
        ),
      ),
      'margin_tablet' => array(
        'unit' => 'px',
        'top' => '0',
        'right' => 0,
        'bottom' => '0',
        'left' => 0,
        'isLinked' => false,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'hdr_d_logo_col',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 33,
          '_inline_size' => 20,
          'content_position' => 'center',
          'margin' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          'padding' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          '_inline_size_tablet' => 15,
          'padding_tablet' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
        ),
        'elements' => array(
          0 => array(
            'id' => 'hdr_d_logo',
            'elType' => 'widget',
            'settings' => array(
              'title_color' => '#191F28',
              'typography_typography' => 'custom',
              'typography_font_family' => 'Pretendard',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 20,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '700',
              'typography_letter_spacing' => array(
                'unit' => 'px',
                'size' => -0.5,
                'sizes' => array(
                ),
              ),
              'header_size' => 'h3',
              'link' => array(
                'url' => '/',
                'is_external' => false,
              ),
              '__dynamic__' => array(
                'title' => '[elementor-tag id="" name="site-title" settings="%7B%22before%22%3A%22%22%2C%22after%22%3A%22%22%2C%22fallback%22%3A%22%22%7D"]',
                'link' => '[elementor-tag id="" name="site-url" settings="%7B%7D"]',
              ),
              'title' => '여기에 제목 텍스트 추가',
            ),
            'elements' => array(
            ),
            'widgetType' => 'theme-site-title',
          ),
        ),
        'isInner' => false,
      ),
      1 => array(
        'id' => 'hdr_d_cta_col',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 33,
          '_inline_size' => 66.332,
          'content_position' => 'center',
          'align' => 'right',
          'css_classes' => 'hc-header-right',
          'margin' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          'padding' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '10',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          '_inline_size_tablet' => 60,
          'content_position_tablet' => 'middle',
          'padding_tablet' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
        ),
        'elements' => array(
          0 => array(
            'id' => 'hdr_d_nav',
            'elType' => 'widget',
            'settings' => array(
              'menu' => '__HEADER_MENU__',
              'align' => 'right',
              'color_menu_item' => '#191F28',
              'color_menu_item_hover' => '#0064FF',
              'color_menu_item_active' => '#0064FF',
              'pointer_color_menu_item' => '#0064FF',
              'pointer_color_menu_item_hover' => '#0064FF',
              'typography_menu_typography' => 'custom',
              'typography_menu_font_family' => 'Pretendard',
              'typography_menu_font_size' => array(
                'unit' => 'px',
                'size' => 15,
                'sizes' => array(
                ),
              ),
              'typography_menu_font_weight' => '500',
              'menu_typography_typography' => 'custom',
              'menu_typography_font_family' => 'Pretendard',
              'menu_typography_font_size' => array(
                'unit' => 'px',
                'size' => 16,
                'sizes' => array(
                ),
              ),
              'menu_typography_font_weight' => '500',
              'padding_horizontal_menu_item' => array(
                'unit' => 'px',
                'size' => 20,
                'sizes' => array(
                ),
              ),
              'menu_name' => 'Menu',
              'dropdown' => 'none',
              '_css_classes' => 'hc-header-nav',
              'pointer' => 'none',
              'menu_typography_line_height' => array(
                'unit' => 'px',
                'size' => 17,
                'sizes' => array(
                ),
              ),
              'menu_typography_letter_spacing' => array(
                'unit' => 'px',
                'size' => 0.7,
                'sizes' => array(
                ),
              ),
              'pointer_width' => array(
                'unit' => 'px',
                'size' => 2,
                'sizes' => array(
                ),
              ),
              'padding_horizontal_menu_item_tablet' => array(
                'unit' => 'px',
                'size' => 10,
                'sizes' => array(
                ),
              ),
              'padding_vertical_menu_item' => array(
                'unit' => 'px',
                'size' => 8,
                'sizes' => array(
                ),
              ),
              '_margin' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              'menu_typography_font_size_tablet' => array(
                'unit' => 'px',
                'size' => 14,
                'sizes' => array(
                ),
              ),
              'align_items' => 'center',
            ),
            'elements' => array(
            ),
            'widgetType' => 'nav-menu',
          ),
          // 검수 미통과 #111: 중복 '로그인' 버튼 제거
          // (우측 컬럼 9cf4907 안의 로그인/마이페이지 버튼만 사용)
        ),
        'isInner' => false,
      ),
      2 => array(
        'id' => '9cf4907',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 33,
          '_inline_size' => 13,
          'content_position' => 'center',
          'align' => 'right',
          'css_classes' => 'hc-header-right',
          'margin' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          'padding' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          '_inline_size_tablet' => 21,
          'content_position_tablet' => 'middle',
          'padding_tablet' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
        ),
        'elements' => array(
          0 => array(
            'id' => 'c303164',
            'elType' => 'widget',
            'settings' => array(
              'text' => '마이 페이지',
              'icon_align' => '',
              'link' => array(
                'url' => '/my-account/',
                'is_external' => false,
              ),
              'size' => 'xs',
              'button_text_color' => '#FFFFFF',
              'background_color' => '#0064FF',
              'border_border' => 'none',
              'border_radius' => array(
                'unit' => 'px',
                'top' => '6',
                'right' => '6',
                'bottom' => '6',
                'left' => '6',
                'isLinked' => true,
              ),
              'typography_typography' => 'custom',
              'typography_font_family' => 'Pretendard',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 14,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '400',
              'button_hover_color' => '#FFFFFF',
              'button_background_hover_color' => '#0050CC',
              '_padding' => array(
                'unit' => 'px',
                'top' => '8',
                'right' => '18',
                'bottom' => '8',
                'left' => '18',
                'isLinked' => false,
              ),
              '_css_classes' => 'hc-cta-my-account',
              'align_tablet' => 'justify',
              'align' => 'justify',
            ),
            'elements' => array(
            ),
            'widgetType' => 'button',
          ),
          1 => array(
            'id' => '95afd5f',
            'elType' => 'widget',
            'settings' => array(
              'text' => '로그인',
              'link' => array(
                'url' => '/my-account/',
                'is_external' => false,
              ),
              'size' => 'xs',
              'button_text_color' => '#191F28',
              'background_color' => 'transparent',
              'border_border' => 'solid',
              'border_width' => array(
                'unit' => 'px',
                'top' => '1',
                'right' => '1',
                'bottom' => '1',
                'left' => '1',
                'isLinked' => true,
              ),
              'border_color' => '#D1D6DB',
              'border_radius' => array(
                'unit' => 'px',
                'top' => '6',
                'right' => '6',
                'bottom' => '6',
                'left' => '6',
                'isLinked' => true,
              ),
              'typography_typography' => 'custom',
              'typography_font_family' => 'Pretendard',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 14,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '500',
              'button_hover_color' => '#0064FF',
              'button_background_hover_color' => 'transparent',
              'border_hover_color' => '#0064FF',
              '_padding' => array(
                'unit' => 'px',
                'top' => '8',
                'right' => '18',
                'bottom' => '8',
                'left' => '18',
                'isLinked' => false,
              ),
              '_css_classes' => 'hc-cta-login',
            ),
            'elements' => array(
            ),
            'widgetType' => 'button',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  1 => array(
    'id' => 'hdr_mobile',
    'elType' => 'section',
    'settings' => array(
      'structure' => '30',
      'layout' => 'full_width',
      'background_background' => 'classic',
      'background_color' => '#FFFFFF',
      'padding' => array(
        'unit' => 'px',
        'top' => '0',
        'right' => '16',
        'bottom' => '0',
        'left' => '16',
        'isLinked' => false,
      ),
      'hide_desktop' => 'hidden-desktop',
      'border_border' => 'solid',
      'border_width' => array(
        'unit' => 'px',
        'top' => '0',
        'right' => '0',
        'bottom' => '1',
        'left' => '0',
        'isLinked' => false,
      ),
      'border_color' => '#E5E8EB',
      'custom_height' => array(
        'unit' => 'px',
        'size' => 56,
        'sizes' => array(
        ),
      ),
      'height' => 'min-height',
      'margin_mobile' => array(
        'unit' => 'px',
        'top' => '0',
        'right' => 0,
        'bottom' => '0',
        'left' => 0,
        'isLinked' => false,
      ),
      'hide_tablet' => 'hidden-tablet',
    ),
    'elements' => array(
      0 => array(
        'id' => 'hdr_m_logo_col',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 33,
          '_inline_size' => 50,
          '_inline_size_mobile' => 75,
          'content_position' => 'center',
        ),
        'elements' => array(
          0 => array(
            'id' => 'hdr_m_logo',
            'elType' => 'widget',
            'settings' => array(
              'title_color' => '#191F28',
              'typography_typography' => 'custom',
              'typography_font_family' => 'Pretendard',
              'typography_font_weight' => '700',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 18,
                'sizes' => array(
                ),
              ),
              'header_size' => 'h3',
              'link' => array(
                'url' => '/',
                'is_external' => false,
              ),
              '__dynamic__' => array(
                'title' => '[elementor-tag id="" name="site-title" settings="%7B%22before%22%3A%22%22%2C%22after%22%3A%22%22%2C%22fallback%22%3A%22%22%7D"]',
                'link' => '[elementor-tag id="" name="site-url" settings="%7B%7D"]',
              ),
              'title' => '여기에 제목 텍스트 추가',
            ),
            'elements' => array(
            ),
            'widgetType' => 'theme-site-title',
          ),
        ),
        'isInner' => false,
      ),
      1 => array(
        'id' => 'hdr_m_user_col',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 33,
          '_inline_size' => 25,
          '_inline_size_mobile' => 10,
          'content_position' => 'center',
          'align' => 'center',
          'content_position_mobile' => 'center',
          'margin_mobile' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          'padding_mobile' => array(
            'unit' => 'px',
            'top' => '10',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
        ),
        'elements' => array(
          0 => array(
            'id' => 'hdr_m_user',
            'elType' => 'widget',
            'settings' => array(
              'selected_icon' => array(
                'value' => 'fas fa-user-circle',
                'library' => 'fa-solid',
              ),
              'primary_color' => '#171D25',
              'hover_color' => '#0064FF',
              'size' => array(
                'unit' => 'px',
                'size' => 22,
                'sizes' => array(
                ),
              ),
              'link' => array(
                'url' => '/my-account/',
                'is_external' => false,
              ),
              '_margin' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => true,
              ),
              'size_mobile' => array(
                'unit' => 'px',
                'size' => 26,
                'sizes' => array(
                ),
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'icon',
          ),
        ),
        'isInner' => false,
      ),
      2 => array(
        'id' => 'hdr_m_nav_col',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 33,
          '_inline_size' => 25,
          '_inline_size_mobile' => 10,
          'content_position' => 'center',
          'align' => 'right',
          'margin_mobile' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '0',
            'bottom' => '0',
            'left' => '0',
            'isLinked' => false,
          ),
          'padding_mobile' => array(
            'unit' => 'px',
            'top' => '0',
            'right' => '10',
            'bottom' => '0',
            'left' => '10',
            'isLinked' => false,
          ),
        ),
        'elements' => array(
          0 => array(
            'id' => 'hdr_m_nav',
            'elType' => 'widget',
            'settings' => array(
              'menu' => '__HEADER_MENU__',
              'layout' => 'dropdown',
              'toggle_align' => 'right',
              'color_menu_item' => '#191F28',
              'color_menu_item_hover' => '#0064FF',
              'toggle_button_color' => '#191F28',
              'background_color_dropdown_item' => '#FFFFFF',
              'color_dropdown_item' => '#4E5968',
              'color_dropdown_item_hover' => '#0064FF',
              'typography_menu_typography' => 'custom',
              'typography_menu_font_family' => 'Pretendard',
              'typography_menu_font_size' => array(
                'unit' => 'px',
                'size' => 15,
                'sizes' => array(
                ),
              ),
              'typography_menu_font_weight' => '400',
              'menu_name' => 'Menu',
            ),
            'elements' => array(
            ),
            'widgetType' => 'nav-menu',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
);
