<?php
/**
 * 온라인 강의 상세 페이지 — Elementor Theme Builder 템플릿
 *
 * 구조: Hero(다크) + 본문(product-content, Elementor 편집 가능) + sticky 사이드바 + 하단 sticky 장바구니
 * Kit 디자인 참고: 다크 Hero, 화이트 사이드바, Noto Sans
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return [
	// ─────────────────────────────────────────────
	// 섹션 0: Hero (다크 배경 — 브레드크럼 + 상품명 + 태그)
	// ─────────────────────────────────────────────
	[
		'id'       => 'sp_hero',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '20',
			'background_background'  => 'classic',
			'background_color'       => '#000000',
			'padding'                => [ 'unit' => 'px', 'top' => '60', 'right' => '0', 'bottom' => '60', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '40', 'right' => '20', 'bottom' => '40', 'left' => '20', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '30', 'right' => '15', 'bottom' => '30', 'left' => '15', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1220, 'sizes' => [] ],
		],
		'elements' => [
			// 좌측 60%: 브레드크럼 + 상품명 + 태그
			[
				'id'       => 'sp_hero_left',
				'elType'   => 'column',
				'settings' => [
					'_column_size'     => 50,
					'_inline_size'     => 60,
					'content_position' => 'center',
				],
				'elements' => [
					// 브레드크럼
					[
						'id'         => 'sp_breadcrumb',
						'elType'     => 'widget',
						'widgetType' => 'woocommerce-breadcrumb',
						'settings'   => [
							'text_color'                           => '#A8A8A8',
							'link_color'                           => '#FFFFFF',
							'text_typography_typography'            => 'custom',
							'text_typography_font_family'           => 'Noto Sans',
							'text_typography_font_size'             => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'text_typography_font_weight'           => '300',
							'text_typography_text_transform'        => 'uppercase',
							'text_typography_font_size_mobile'      => [ 'unit' => 'px', 'size' => 11, 'sizes' => [] ],
						],
						'elements' => [],
					],
					// 상품명 (동적 태그)
					[
						'id'         => 'sp_hero_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => '상품명',
							'header_size'                  => 'h1',
							'title_color'                  => '#FFFFFF',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 30, 'sizes' => [] ],
							'typography_font_weight'        => '600',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '20', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
							'__dynamic__' => [
								'title' => '[elementor-tag id="sp_title_dyn" name="woocommerce-product-title-tag" settings="%7B%7D"]',
							],
						],
						'elements' => [],
					],
					// 상품 태그 (동적 태그)
					[
						'id'         => 'sp_hero_tags',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '',
							'header_size'                => 'h6',
							'title_color'                => '#FFFFFF',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 12, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 0.5, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '15', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
							'__dynamic__' => [
								'title' => '[elementor-tag id="sp_tags_dyn" name="woocommerce-product-terms-tag" settings="%7B%22taxonomy%22%3A%22product_tag%22%2C%22separator%22%3A%22%22%2C%22before%22%3A%22%22%2C%22fallback%22%3A%22%22%7D"]',
							],
						],
						'elements' => [],
					],
				],
			],
			// 우측 40%: 비움 (Hero 밸런스)
			[
				'id'       => 'sp_hero_right',
				'elType'   => 'column',
				'settings' => [
					'_column_size' => 50,
					'_inline_size' => 40,
				],
				'elements' => [],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 1: 본문 (product-content) + sticky 사이드바
	// ─────────────────────────────────────────────
	[
		'id'       => 'sp_content',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '20',
			'background_background'  => 'classic',
			'background_color'       => '#F8F9FA',
			'padding'                => [ 'unit' => 'px', 'top' => '40', 'right' => '0', 'bottom' => '60', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '30', 'right' => '20', 'bottom' => '40', 'left' => '20', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '20', 'right' => '15', 'bottom' => '30', 'left' => '15', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1220, 'sizes' => [] ],
		],
		'elements' => [
			// 좌측 71%: 상품 콘텐츠 (Elementor로 편집한 상품 설명)
			[
				'id'       => 'sp_content_left',
				'elType'   => 'column',
				'settings' => [
					'_column_size' => 50,
					'_inline_size' => 71,
				],
				'elements' => [
					[
						'id'         => 'sp_product_content',
						'elType'     => 'widget',
						'widgetType' => 'woocommerce-product-content',
						'settings'   => [],
						'elements'   => [],
					],
				],
			],
			// 우측 29%: sticky 사이드바 (이미지, 제목, 가격, 장바구니)
			[
				'id'       => 'sp_content_right',
				'elType'   => 'column',
				'settings' => [
					'_column_size' => 50,
					'_inline_size' => 29,
				],
				'elements' => [
					// Inner section (sticky)
					[
						'id'       => 'sp_sidebar',
						'elType'   => 'section',
						'isInner'  => true,
						'settings' => [
							'background_background' => 'classic',
							'background_color'      => '#FFFFFF',
							'border_border'         => 'solid',
							'border_width'          => [ 'unit' => 'px', 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'isLinked' => true ],
							'border_color'          => '#E6E6E6',
							'border_radius'         => [ 'unit' => 'px', 'top' => '10', 'right' => '10', 'bottom' => '10', 'left' => '10', 'isLinked' => true ],
							'padding'               => [ 'unit' => 'px', 'top' => '20', 'right' => '20', 'bottom' => '20', 'left' => '20', 'isLinked' => false ],
							'sticky'                => 'top',
							'sticky_offset'         => 80,
						],
						'elements' => [
							[
								'id'       => 'sp_sidebar_col',
								'elType'   => 'column',
								'settings' => [ '_column_size' => 100, '_inline_size' => null ],
								'elements' => [
									// 상품 이미지
									[
										'id'         => 'sp_sidebar_img',
										'elType'     => 'widget',
										'widgetType' => 'woocommerce-product-images',
										'settings'   => [
											'sale_flash'      => 'none',
											'border_border'   => 'solid',
											'border_width'    => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true ],
											'border_radius'   => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
											'_margin'          => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
										],
										'elements' => [],
									],
									// 상품명 (동적)
									[
										'id'         => 'sp_sidebar_title',
										'elType'     => 'widget',
										'widgetType' => 'woocommerce-product-title',
										'settings'   => [
											'header_size'                  => 'h3',
											'title_color'                  => '#1B1B1B',
											'typography_typography'         => 'custom',
											'typography_font_family'        => 'Noto Sans',
											'typography_font_size'          => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
											'typography_font_weight'        => '600',
											'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
											'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
											'__dynamic__' => [
												'title' => '[elementor-tag id="" name="woocommerce-product-title-tag" settings="%7B%22product_id%22%3Afalse%2C%22before%22%3A%22%22%2C%22after%22%3A%22%22%2C%22fallback%22%3A%22%22%7D"]',
											],
										],
										'elements' => [],
									],
									// 판매가 라벨
									[
										'id'         => 'sp_sidebar_price_label',
										'elType'     => 'widget',
										'widgetType' => 'heading',
										'settings'   => [
											'title'                      => '클래스 판매가',
											'header_size'                => 'h6',
											'title_color'                => '#BCBCBC',
											'typography_typography'       => 'custom',
											'typography_font_family'      => 'Noto Sans',
											'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
											'typography_font_weight'      => '400',
											'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '5', 'left' => '0', 'isLinked' => false ],
										],
										'elements' => [],
									],
									// 판매가 (동적)
									[
										'id'         => 'sp_sidebar_price',
										'elType'     => 'widget',
										'widgetType' => 'heading',
										'settings'   => [
											'title'                      => '',
											'header_size'                => 'h3',
											'title_color'                => '#000000',
											'typography_typography'       => 'custom',
											'typography_font_family'      => 'Noto Sans',
											'typography_font_size'        => [ 'unit' => 'px', 'size' => 25, 'sizes' => [] ],
											'typography_font_weight'      => '700',
											'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
											'__dynamic__' => [
												'title' => '[elementor-tag id="sp_price_dyn" name="woocommerce-product-price-tag" settings="%7B%22format%22%3A%22sale%22%7D"]',
											],
										],
										'elements' => [],
									],
									// 짧은 설명
									[
										'id'         => 'sp_sidebar_shortdesc',
										'elType'     => 'widget',
										'widgetType' => 'woocommerce-product-short-description',
										'settings'   => [
											'typography_typography'       => 'custom',
											'typography_font_family'      => 'Noto Sans',
											'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
											'typography_font_weight'      => '400',
											'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
											'text_color'                 => '#666666',
											'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '20', 'left' => '0', 'isLinked' => false ],
										],
										'elements' => [],
									],
									// 장바구니 버튼
									[
										'id'         => 'sp_sidebar_addtocart',
										'elType'     => 'widget',
										'widgetType' => 'woocommerce-product-add-to-cart',
										'settings'   => [
											'alignment'                          => 'justify',
											'button_text_color'                  => '#FFFFFF',
											'button_bg_color'                    => '#1E75F1',
											'button_hover_color'                 => '#FFFFFF',
											'button_hover_bg_color'              => '#1565D8',
											'button_typography_typography'        => 'custom',
											'button_typography_font_family'       => 'Noto Sans',
											'button_typography_font_size'         => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
											'button_typography_font_weight'       => '600',
											'button_border_border'               => 'solid',
											'button_border_width'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true ],
											'button_border_radius'               => [ 'unit' => 'px', 'top' => '5', 'right' => '5', 'bottom' => '5', 'left' => '5', 'isLinked' => true ],
											'button_padding'                     => [ 'unit' => 'px', 'top' => '15', 'right' => '15', 'bottom' => '15', 'left' => '15', 'isLinked' => true ],
										],
										'elements' => [],
									],
								],
							],
						],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 2: 하단 sticky 장바구니 버튼
	// ─────────────────────────────────────────────
	[
		'id'       => 'sp_bottom_bar',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#FFFFFF',
			'sticky'                => 'bottom',
			'padding'               => [ 'unit' => 'px', 'top' => '10', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1220, 'sizes' => [] ],
			'border_border'         => 'solid',
			'border_width'          => [ 'unit' => 'px', 'top' => '1', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
			'border_color'          => '#E6E6E6',
		],
		'elements' => [
			[
				'id'       => 'sp_bottom_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					[
						'id'         => 'sp_bottom_addtocart',
						'elType'     => 'widget',
						'widgetType' => 'woocommerce-product-add-to-cart',
						'settings'   => [
							'alignment'                          => 'justify',
							'button_text_color'                  => '#FFFFFF',
							'button_bg_color'                    => '#1E75F1',
							'button_hover_color'                 => '#FFFFFF',
							'button_hover_bg_color'              => '#1565D8',
							'button_typography_typography'        => 'custom',
							'button_typography_font_family'       => 'Noto Sans',
							'button_typography_font_size'         => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'button_typography_font_weight'       => '600',
							'button_border_border'               => 'solid',
							'button_border_width'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true ],
							'button_border_radius'               => [ 'unit' => 'px', 'top' => '3', 'right' => '3', 'bottom' => '3', 'left' => '3', 'isLinked' => true ],
							'button_padding'                     => [ 'unit' => 'px', 'top' => '15', 'right' => '15', 'bottom' => '15', 'left' => '15', 'isLinked' => true ],
						],
						'elements' => [],
					],
				],
			],
		],
	],
];
