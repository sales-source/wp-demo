<?php
/**
 * Home v2 — Elementor 페이지 데이터 (확정본)
 *
 * 이 파일은 Elementor 에서 home-v2 페이지를 편집한 결과를 export 한 데이터입니다.
 * 테마 활성화 시 'home-v2' 페이지의 _elementor_data 메타에 자동 주입됩니다.
 *
 * Export 일시: 2026-04-09 12:08:26
 * Source: page post ID 290
 * Tool: tools/export-home-v2.php
 *
 * 주의: 이 파일은 export 도구가 매번 덮어쓰므로 수동 편집하지 마세요.
 *       수정하려면 Elementor 에서 home-v2 페이지를 편집한 뒤 export 도구 재실행.
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array (
  0 => array(
    'id' => 'sec_hero',
    'elType' => 'section',
    'settings' => array(
      'structure' => '21',
      'gap' => 'extended',
      'css_classes' => 'thv2-hero',
      'content_width' => array(
        'unit' => 'px',
        'size' => 1200,
      ),
      'padding' => array(
        'unit' => 'px',
        'top' => '100',
        'right' => '24',
        'bottom' => '100',
        'left' => '24',
        'isLinked' => false,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_hero_l',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 55,
          '_inline_size' => 55,
        ),
        'elements' => array(
          0 => array(
            'id' => 'b291895',
            'elType' => 'widget',
            'settings' => array(
              'title' => 'ALL-IN-ONE GROWTH PLATFORM',
              'typography_typography' => 'custom',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 12,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '500',
              'typography_letter_spacing' => array(
                'unit' => 'px',
                'size' => 1.3,
                'sizes' => array(
                ),
              ),
              '_margin' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding' => array(
                'unit' => 'px',
                'top' => '8',
                'right' => '20',
                'bottom' => '8',
                'left' => '20',
                'isLinked' => false,
              ),
              '_element_width' => 'initial',
              '_background_background' => 'classic',
              '_background_color' => '#FFFFFF',
              '_border_radius' => array(
                'unit' => 'px',
                'top' => '100',
                'right' => '100',
                'bottom' => '100',
                'left' => '100',
                'isLinked' => true,
              ),
              '_box_shadow_box_shadow_type' => 'yes',
              '_box_shadow_box_shadow' => array(
                'horizontal' => 0,
                'vertical' => 0,
                'blur' => 10,
                'spread' => 0,
                'color' => 'rgba(0, 0, 0, 0.07)',
              ),
              '__globals__' => array(
                'title_color' => 'globals/colors?id=accent',
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_hero_h1',
            'elType' => 'widget',
            'settings' => array(
              'title' => '당신의 <span class="accent">성장</span>을<br>함께 설계합니다.',
              'header_size' => 'h1',
              '_css_classes' => 'thv2-hero-h1',
              '_margin' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          2 => array(
            'id' => 'w_hero_sub',
            'elType' => 'widget',
            'settings' => array(
              'editor' => '<p>강의 · 전자책 · 실시간 Q&amp;A · 커뮤니티 · 스토어까지. 배움이 실행이 되고, 실행이 성과가 되는 올인원 성장 플랫폼입니다.</p>',
              '_css_classes' => 'thv2-hero-sub',
              '_margin' => array(
                'unit' => 'px',
                'top' => '-21',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'text-editor',
          ),
          3 => array(
            'id' => 'w_hero_btn1',
            'elType' => 'widget',
            'settings' => array(
              'text' => '무료 가이드북 받기 →',
              'link' => array(
                'url' => '/product/온라인-마케팅-무료-가이드북/',
                'is_external' => '',
                'nofollow' => '',
              ),
              'size' => 'lg',
              'background_color' => '#1D4ED8',
              'button_text_color' => '#ffffff',
              'border_radius' => array(
                'unit' => 'px',
                'top' => '12',
                'right' => '12',
                'bottom' => '12',
                'left' => '12',
                'isLinked' => true,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'button',
          ),
          4 => array(
            'id' => 'w_hero_micro',
            'elType' => 'widget',
            'settings' => array(
              'html' => '<div class="hero-micro"><div class="hero-avatars"><span>K</span><span>L</span><span>P</span><span>S</span></div><span>이미 <strong>1,200명+</strong>의 수강생이 함께하고 있습니다</span></div>',
            ),
            'elements' => array(
            ),
            'widgetType' => 'html',
          ),
        ),
        'isInner' => false,
      ),
      1 => array(
        'id' => 'col_hero_r',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 45,
          '_inline_size' => 45,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_hero_hub',
            'elType' => 'widget',
            'settings' => array(
              'html' => '<div class="hero-visual">
  <div class="hero-hub">
    <div class="hero-orbit"></div>
    <div class="hero-orbit-2"></div>
    <div class="hero-hub-center">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="35" height="35"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      <div class="hero-hub-center-label">커뮤니티 허브</div>
    </div>
    <div class="hero-person hp-1"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
    <div class="hero-person hp-2"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
    <div class="hero-person hp-3"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
    <div class="hero-person hp-4"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
    <div class="hero-person hp-5"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
    <div class="hero-person hp-6"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
    <div class="hero-feat hf-1"><div class="hero-feat-icon" style="background:rgba(29,78,216,.10);color:#1D4ED8"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg></div><div><div class="hero-feat-text">VOD 강의</div><div class="hero-feat-sub">50+ 커리큘럼</div></div></div>
    <div class="hero-feat hf-2"><div class="hero-feat-icon" style="background:rgba(16,185,129,.10);color:#10B981"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div><div><div class="hero-feat-text">실시간 Q&amp;A</div><div class="hero-feat-sub">라이브 세션</div></div></div>
    <div class="hero-feat hf-3"><div class="hero-feat-icon" style="background:rgba(245,158,11,.10);color:#F59E0B"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg></div><div><div class="hero-feat-text">스토어</div><div class="hero-feat-sub">디지털 상품 판매</div></div></div>
    <div class="hero-feat hf-4"><div class="hero-feat-icon" style="background:rgba(168,85,247,.10);color:#A855F7"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg></div><div><div class="hero-feat-text">전자책 · PDF</div><div class="hero-feat-sub">무료 가이드</div></div></div>
    <div class="hero-feat hf-5"><div class="hero-feat-icon" style="background:rgba(236,72,153,.10);color:#EC4899"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div><div><div class="hero-feat-text">마케팅 자동화</div><div class="hero-feat-sub">알림톡 · 메일</div></div></div>
    <div class="hero-feat hf-6"><div class="hero-feat-icon" style="background:rgba(6,182,212,.10);color:#06B6D4"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></div><div><div class="hero-feat-text">멤버십</div><div class="hero-feat-sub">유료 커뮤니티</div></div></div>
  </div>
</div>',
            ),
            'elements' => array(
            ),
            'widgetType' => 'html',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  1 => array(
    'id' => 'sec_stats',
    'elType' => 'section',
    'settings' => array(
      'structure' => '40',
      'gap' => 'extended',
      'css_classes' => 'thv2-stats',
      'content_width' => array(
        'unit' => 'px',
        'size' => 1200,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_stat_1',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 25,
          '_inline_size' => 25,
          '_inline_size_mobile' => 50,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_s1_n',
            'elType' => 'widget',
            'settings' => array(
              'title' => '1200<span class="small">+</span>',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-stat-num',
              'typography_typography' => 'custom',
              'typography_font_size_mobile' => array(
                'unit' => 'px',
                'size' => 29,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '700',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_s1_l',
            'elType' => 'widget',
            'settings' => array(
              'title' => '누적 수강생',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-stat-label',
              '_margin_mobile' => array(
                'unit' => 'px',
                'top' => '-9',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding_mobile' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
        ),
        'isInner' => false,
      ),
      1 => array(
        'id' => 'col_stat_2',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 25,
          '_inline_size' => 25,
          '_inline_size_mobile' => 50,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_s2_n',
            'elType' => 'widget',
            'settings' => array(
              'title' => '96<span class="small">%</span>',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-stat-num',
              'typography_typography' => 'custom',
              'typography_font_size_mobile' => array(
                'unit' => 'px',
                'size' => 29,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '700',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_s2_l',
            'elType' => 'widget',
            'settings' => array(
              'title' => '수강 만족도',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-stat-label',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
        ),
        'isInner' => false,
      ),
      2 => array(
        'id' => 'col_stat_3',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 25,
          '_inline_size' => 25,
          '_inline_size_mobile' => 50,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_s3_n',
            'elType' => 'widget',
            'settings' => array(
              'title' => '50<span class="small">+</span>',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-stat-num',
              'typography_typography' => 'custom',
              'typography_font_size_mobile' => array(
                'unit' => 'px',
                'size' => 29,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '700',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_s3_l',
            'elType' => 'widget',
            'settings' => array(
              'title' => 'VOD 강의',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-stat-label',
              '_margin_mobile' => array(
                'unit' => 'px',
                'top' => '-9',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding_mobile' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
        ),
        'isInner' => false,
      ),
      3 => array(
        'id' => 'col_stat_4',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 25,
          '_inline_size' => 25,
          '_inline_size_mobile' => 50,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_s4_n',
            'elType' => 'widget',
            'settings' => array(
              'title' => '4.9<span class="small">★</span>',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-stat-num',
              'typography_typography' => 'custom',
              'typography_font_size_mobile' => array(
                'unit' => 'px',
                'size' => 29,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '700',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_s4_l',
            'elType' => 'widget',
            'settings' => array(
              'title' => '평균 평점',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-stat-label',
              '_margin_mobile' => array(
                'unit' => 'px',
                'top' => '-9',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding_mobile' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  2 => array(
    'id' => 'sec_prob',
    'elType' => 'section',
    'settings' => array(
      'css_classes' => 'thv2-problem',
      'content_width' => array(
        'unit' => 'px',
        'size' => 1200,
      ),
      'padding_mobile' => array(
        'unit' => 'px',
        'top' => '50',
        'right' => '20',
        'bottom' => '50',
        'left' => '20',
        'isLinked' => false,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_prob_hdr',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 100,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_prob_eb',
            'elType' => 'widget',
            'settings' => array(
              'title' => 'PROBLEM · 이런 고민 있으셨나요',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-eyebrow',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_prob_h2',
            'elType' => 'widget',
            'settings' => array(
              'title' => '온라인 마케팅, <span class="underline">시작부터 막히는</span> 3가지 이유',
              'align' => 'center',
              '_css_classes' => 'thv2-h2',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          2 => array(
            'id' => 'w_prob_lead',
            'elType' => 'widget',
            'settings' => array(
              'editor' => '<p>누구나 겪는 문제입니다. 중요한 건 왜 막히는지 정확히 아는 것입니다.</p>',
              'align' => 'center',
              '_css_classes' => 'thv2-lead',
            ),
            'elements' => array(
            ),
            'widgetType' => 'text-editor',
          ),
          3 => array(
            'id' => 'sec_prob_inner',
            'elType' => 'section',
            'settings' => array(
              'structure' => '30',
              'gap' => 'extended',
              'margin' => array(
                'unit' => 'px',
                'top' => '8',
                'right' => 0,
                'bottom' => '0',
                'left' => 0,
                'isLinked' => false,
              ),
            ),
            'elements' => array(
              0 => array(
                'id' => 'col_pc1',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 33,
                  '_inline_size' => 33,
                  'css_classes' => 'thv2-prob-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '50',
                    'right' => '30',
                    'bottom' => '50',
                    'left' => '30',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_pc1_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '01',
                      'header_size' => 'div',
                      '_css_classes' => 'thv2-prob-num',
                      '__globals__' => array(
                        'title_color' => 'globals/colors?id=accent',
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  1 => array(
                    'id' => 'w_pc1_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '어디서부터 시작해야 할지 모르겠다',
                      'header_size' => 'h3',
                      '_css_classes' => 'thv2-prob-title',
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_pc1_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>블로그? 인스타? 유튜브? 퍼널? 정보는 쏟아지는데 뭐부터 손대야 할지 막막합니다. 결국 아무것도 시작 못 하고 시간만 흘러갑니다.</p>',
                      '_css_classes' => 'thv2-card-desc',
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
              1 => array(
                'id' => 'col_pc2',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 33,
                  '_inline_size' => 33,
                  'css_classes' => 'thv2-prob-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '50',
                    'right' => '30',
                    'bottom' => '50',
                    'left' => '30',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_pc2_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '02',
                      'header_size' => 'div',
                      '_css_classes' => 'thv2-prob-num',
                      '__globals__' => array(
                        'title_color' => 'globals/colors?id=accent',
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  1 => array(
                    'id' => 'w_pc2_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '배워도 실행으로 연결이 안 된다',
                      'header_size' => 'h3',
                      '_css_classes' => 'thv2-prob-title',
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_pc2_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>강의는 들었는데 막상 내 사업에 적용하려니 막힙니다. 이론과 실무 사이의 간극, 혼자 넘기엔 너무 큽니다.</p>',
                      '_css_classes' => 'thv2-card-desc',
                      'typography_typography' => 'custom',
                      'typography_font_size_mobile' => array(
                        'unit' => 'px',
                        'size' => 14,
                        'sizes' => array(
                        ),
                      ),
                      'typography_font_weight' => '400',
                      '_margin_mobile' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding_mobile' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
              2 => array(
                'id' => 'col_pc3',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 33,
                  '_inline_size' => 33,
                  'css_classes' => 'thv2-prob-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '50',
                    'right' => '30',
                    'bottom' => '50',
                    'left' => '30',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_pc3_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '03',
                      'header_size' => 'div',
                      '_css_classes' => 'thv2-prob-num',
                      '__globals__' => array(
                        'title_color' => 'globals/colors?id=accent',
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  1 => array(
                    'id' => 'w_pc3_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '여러 툴을 따로 써서 비효율적이다',
                      'header_size' => 'h3',
                      '_css_classes' => 'thv2-prob-title',
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_pc3_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>블로그, 이메일, 결제, CRM… 매달 구독료는 쌓이고, 데이터는 흩어지고, 연동은 매번 삽질. 본업에 집중할 수 없습니다.</p>',
                      '_css_classes' => 'thv2-card-desc',
                      'typography_typography' => 'custom',
                      'typography_font_size_mobile' => array(
                        'unit' => 'px',
                        'size' => 14,
                        'sizes' => array(
                        ),
                      ),
                      'typography_font_weight' => '400',
                      '_margin_mobile' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding_mobile' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
            ),
            'isInner' => true,
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  3 => array(
    'id' => 'sec_sol',
    'elType' => 'section',
    'settings' => array(
      'css_classes' => 'thv2-solution',
      'content_width' => array(
        'unit' => 'px',
        'size' => 1200,
      ),
      'padding_mobile' => array(
        'unit' => 'px',
        'top' => '50',
        'right' => '20',
        'bottom' => '50',
        'left' => '20',
        'isLinked' => false,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_sol_hdr',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 100,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_sol_eb',
            'elType' => 'widget',
            'settings' => array(
              'title' => 'SOLUTION · 테라플로우의 해답',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-eyebrow',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_sol_h2',
            'elType' => 'widget',
            'settings' => array(
              'title' => '학습부터 실행까지,<br><span class="accent">한 번에 이어지는</span> 시스템',
              'align' => 'center',
              '_css_classes' => 'thv2-h2',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          2 => array(
            'id' => 'w_sol_lead',
            'elType' => 'widget',
            'settings' => array(
              'editor' => '<p>이론 강의로 끝나지 않습니다. 배운 즉시 실행할 수 있는 로드맵 · 실습 · 올인원 플랫폼을 함께 제공합니다.</p>',
              'align' => 'center',
              '_css_classes' => 'thv2-lead',
            ),
            'elements' => array(
            ),
            'widgetType' => 'text-editor',
          ),
          3 => array(
            'id' => 'sec_sol_inner',
            'elType' => 'section',
            'settings' => array(
              'structure' => '30',
              'gap' => 'extended',
              'margin' => array(
                'unit' => 'px',
                'top' => '50',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
              0 => array(
                'id' => 'col_sc1',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 33,
                  '_inline_size' => 33,
                  'css_classes' => 'thv2-sol-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '40',
                    'right' => '30',
                    'bottom' => '20',
                    'left' => '30',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_sc1_i',
                    'elType' => 'widget',
                    'settings' => array(
                      'selected_icon' => array(
                        'value' => 'fas fa-book-open',
                        'library' => 'fa-solid',
                      ),
                      '_css_classes' => 'thv2-sol-icon',
                      'align' => 'start',
                      'view' => 'stacked',
                      'primary_color' => '#FFFFFF',
                      'size' => array(
                        'unit' => 'px',
                        'size' => 23,
                        'sizes' => array(
                        ),
                      ),
                      'icon_padding' => array(
                        'unit' => 'px',
                        'size' => 3,
                        'sizes' => array(
                        ),
                      ),
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'icon',
                  ),
                  1 => array(
                    'id' => 'w_sc1_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => 'SOLUTION 01',
                      'header_size' => 'div',
                      '_css_classes' => 'thv2-sol-num',
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_sc1_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '단계별 학습 로드맵',
                      'header_size' => 'h3',
                      '_css_classes' => 'thv2-sol-title',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-10',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  3 => array(
                    'id' => 'w_sc1_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>기초부터 고급까지 명확한 순서로 배웁니다. 무엇을 먼저, 무엇을 다음에 해야 할지 — 테라플로우가 안내합니다.</p>',
                      '_css_classes' => 'thv2-sol-desc',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-13',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
              1 => array(
                'id' => 'col_sc2',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 33,
                  '_inline_size' => 33,
                  'css_classes' => 'thv2-sol-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '40',
                    'right' => '30',
                    'bottom' => '20',
                    'left' => '30',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_sc2_i',
                    'elType' => 'widget',
                    'settings' => array(
                      'selected_icon' => array(
                        'value' => 'fas fa-bolt',
                        'library' => 'fa-solid',
                      ),
                      '_css_classes' => 'thv2-sol-icon',
                      'view' => 'stacked',
                      'align' => 'start',
                      'primary_color' => '#FFFFFF',
                      'size' => array(
                        'unit' => 'px',
                        'size' => 23,
                        'sizes' => array(
                        ),
                      ),
                      'icon_padding' => array(
                        'unit' => 'px',
                        'size' => 3,
                        'sizes' => array(
                        ),
                      ),
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'icon',
                  ),
                  1 => array(
                    'id' => 'w_sc2_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => 'SOLUTION 02',
                      'header_size' => 'div',
                      '_css_classes' => 'thv2-sol-num',
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_sc2_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '실행 중심 실습',
                      'header_size' => 'h3',
                      '_css_classes' => 'thv2-sol-title',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-10',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  3 => array(
                    'id' => 'w_sc2_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>강의를 들으면서 바로 따라 만듭니다. 이론만 듣고 끝나는 강의가 아닙니다. 실제로 돌아가는 시스템이 손에 남습니다.</p>',
                      '_css_classes' => 'thv2-sol-desc',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-13',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
              2 => array(
                'id' => 'col_sc3',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 33,
                  '_inline_size' => 33,
                  'css_classes' => 'thv2-sol-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '40',
                    'right' => '30',
                    'bottom' => '20',
                    'left' => '30',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_sc3_i',
                    'elType' => 'widget',
                    'settings' => array(
                      'selected_icon' => array(
                        'value' => 'fas fa-laptop',
                        'library' => 'fa-solid',
                      ),
                      '_css_classes' => 'thv2-sol-icon',
                      'view' => 'stacked',
                      'align' => 'start',
                      'primary_color' => '#FFFFFF',
                      'size' => array(
                        'unit' => 'px',
                        'size' => 23,
                        'sizes' => array(
                        ),
                      ),
                      'icon_padding' => array(
                        'unit' => 'px',
                        'size' => 3,
                        'sizes' => array(
                        ),
                      ),
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'icon',
                  ),
                  1 => array(
                    'id' => 'w_sc3_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => 'SOLUTION 03',
                      'header_size' => 'div',
                      '_css_classes' => 'thv2-sol-num',
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_sc3_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '올인원 플랫폼',
                      'header_size' => 'h3',
                      '_css_classes' => 'thv2-sol-title',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-10',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  3 => array(
                    'id' => 'w_sc3_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>강의 · 결제 · 자동화 · 고객관리까지 통합. 여러 도구 옮겨다니지 않고 테라플로우 한 곳에서 모두 관리합니다.</p>',
                      '_css_classes' => 'thv2-sol-desc',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-13',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
            ),
            'isInner' => true,
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  4 => array(
    'id' => 'sec_road',
    'elType' => 'section',
    'settings' => array(
      'css_classes' => 'thv2-roadmap',
      'content_width' => array(
        'unit' => 'px',
        'size' => 1200,
      ),
      'padding_mobile' => array(
        'unit' => 'px',
        'top' => '50',
        'right' => '20',
        'bottom' => '50',
        'left' => '20',
        'isLinked' => false,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_road_hdr',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 100,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_road_eb',
            'elType' => 'widget',
            'settings' => array(
              'title' => 'ROADMAP · 5단계 성장 여정',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-eyebrow',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_road_h2',
            'elType' => 'widget',
            'settings' => array(
              'title' => '무료 전자책부터 <span class="accent">1:1 컨설팅</span>까지,<br>당신의 속도에 맞춰 성장합니다',
              'align' => 'center',
              '_css_classes' => 'thv2-h2',
              'typography_typography' => 'custom',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 35,
                'sizes' => array(
                ),
              ),
              'typography_font_size_mobile' => array(
                'unit' => 'px',
                'size' => 22,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '600',
              'typography_line_height' => array(
                'unit' => 'em',
                'size' => 1.5,
                'sizes' => array(
                ),
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          2 => array(
            'id' => 'w_road_lead',
            'elType' => 'widget',
            'settings' => array(
              'editor' => '<p>어디서 시작하든 괜찮습니다. 다음 단계는 언제나 준비되어 있습니다.</p>',
              'align' => 'center',
              '_css_classes' => 'thv2-lead',
            ),
            'elements' => array(
            ),
            'widgetType' => 'text-editor',
          ),
          3 => array(
            'id' => 'sec_road_inner',
            'elType' => 'section',
            'settings' => array(
              'structure' => '50',
              'gap' => 'extended',
              'margin' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => 0,
                'bottom' => '0',
                'left' => 0,
                'isLinked' => false,
              ),
              'layout' => 'full_width',
            ),
            'elements' => array(
              0 => array(
                'id' => 'col_rc1',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 20,
                  '_inline_size' => 20,
                  'css_classes' => 'thv2-road-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '10',
                    'right' => '10',
                    'bottom' => '10',
                    'left' => '10',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '30',
                    'right' => '0',
                    'bottom' => '20',
                    'left' => '0',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_rc1_i',
                    'elType' => 'widget',
                    'settings' => array(
                      'selected_icon' => array(
                        'value' => 'fas fa-book',
                        'library' => 'fa-solid',
                      ),
                      '_css_classes' => 'thv2-road-icon',
                      'size' => array(
                        'unit' => 'px',
                        'size' => 26,
                        'sizes' => array(
                        ),
                      ),
                      '__globals__' => array(
                        'hover_primary_color' => 'globals/colors?id=hc_border',
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'icon',
                  ),
                  1 => array(
                    'id' => 'w_rc1_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => 'STEP 01',
                      'header_size' => 'div',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-num',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-8',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_rc1_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '무료 전자책',
                      'header_size' => 'h3',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-title',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-14',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  3 => array(
                    'id' => 'w_rc1_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>가볍게 시작하는 입문 가이드북</p>',
                      '_css_classes' => 'thv2-road-desc',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-12',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
              1 => array(
                'id' => 'col_rc2',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 20,
                  '_inline_size' => 20,
                  'css_classes' => 'thv2-road-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '10',
                    'right' => '10',
                    'bottom' => '10',
                    'left' => '10',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '30',
                    'right' => '0',
                    'bottom' => '20',
                    'left' => '0',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_rc2_i',
                    'elType' => 'widget',
                    'settings' => array(
                      'selected_icon' => array(
                        'value' => 'fas fa-play',
                        'library' => 'fa-solid',
                      ),
                      '_css_classes' => 'thv2-road-icon',
                      'hover_primary_color' => '#FFFFFF',
                      'size' => array(
                        'unit' => 'px',
                        'size' => 20,
                        'sizes' => array(
                        ),
                      ),
                      '__globals__' => array(
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'icon',
                  ),
                  1 => array(
                    'id' => 'w_rc2_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => 'STEP 02',
                      'header_size' => 'div',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-num',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-8',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_rc2_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => 'VOD 강의',
                      'header_size' => 'h3',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-title',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-14',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  3 => array(
                    'id' => 'w_rc2_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>내 속도로 배우는 체계적 커리큘럼</p>',
                      '_css_classes' => 'thv2-road-desc',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-12',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
              2 => array(
                'id' => 'col_rc3',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 20,
                  '_inline_size' => 20,
                  'css_classes' => 'thv2-road-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '10',
                    'right' => '10',
                    'bottom' => '10',
                    'left' => '10',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '30',
                    'right' => '0',
                    'bottom' => '20',
                    'left' => '0',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_rc3_i',
                    'elType' => 'widget',
                    'settings' => array(
                      'selected_icon' => array(
                        'value' => 'fas fa-broadcast-tower',
                        'library' => 'fa-solid',
                      ),
                      '_css_classes' => 'thv2-road-icon',
                      'hover_primary_color' => '#FFFFFF',
                      'size' => array(
                        'unit' => 'px',
                        'size' => 20,
                        'sizes' => array(
                        ),
                      ),
                      '__globals__' => array(
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'icon',
                  ),
                  1 => array(
                    'id' => 'w_rc3_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => 'STEP 03',
                      'header_size' => 'div',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-num',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-8',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_rc3_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '실시간 강의',
                      'header_size' => 'h3',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-title',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-14',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  3 => array(
                    'id' => 'w_rc3_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>강사와 즉시 Q&A 집중 몰입 세션</p>',
                      '_css_classes' => 'thv2-road-desc',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-12',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
              3 => array(
                'id' => 'col_rc4',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 20,
                  '_inline_size' => 20,
                  'css_classes' => 'thv2-road-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '10',
                    'right' => '10',
                    'bottom' => '10',
                    'left' => '10',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '30',
                    'right' => '0',
                    'bottom' => '20',
                    'left' => '0',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_rc4_i',
                    'elType' => 'widget',
                    'settings' => array(
                      'selected_icon' => array(
                        'value' => 'fas fa-users',
                        'library' => 'fa-solid',
                      ),
                      '_css_classes' => 'thv2-road-icon',
                      'hover_primary_color' => '#FFFFFF',
                      'size' => array(
                        'unit' => 'px',
                        'size' => 20,
                        'sizes' => array(
                        ),
                      ),
                      '__globals__' => array(
                        'hover_primary_color' => 'globals/colors?id=hc_border',
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'icon',
                  ),
                  1 => array(
                    'id' => 'w_rc4_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => 'STEP 04',
                      'header_size' => 'div',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-num',
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_rc4_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '커뮤니티',
                      'header_size' => 'h3',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-title',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-14',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  3 => array(
                    'id' => 'w_rc4_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>수강생과 함께 성장 · 동기부여</p>',
                      '_css_classes' => 'thv2-road-desc',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-12',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
              4 => array(
                'id' => 'col_rc5',
                'elType' => 'column',
                'settings' => array(
                  '_column_size' => 20,
                  '_inline_size' => 20,
                  'css_classes' => 'thv2-road-card',
                  'margin' => array(
                    'unit' => 'px',
                    'top' => '10',
                    'right' => '10',
                    'bottom' => '10',
                    'left' => '10',
                    'isLinked' => true,
                  ),
                  'padding' => array(
                    'unit' => 'px',
                    'top' => '30',
                    'right' => '0',
                    'bottom' => '20',
                    'left' => '0',
                    'isLinked' => false,
                  ),
                ),
                'elements' => array(
                  0 => array(
                    'id' => 'w_rc5_i',
                    'elType' => 'widget',
                    'settings' => array(
                      '_css_classes' => 'thv2-road-icon',
                      'hover_primary_color' => '#FFFFFF',
                      'size' => array(
                        'unit' => 'px',
                        'size' => 20,
                        'sizes' => array(
                        ),
                      ),
                      '__globals__' => array(
                        'hover_primary_color' => 'globals/colors?id=hc_border',
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'icon',
                  ),
                  1 => array(
                    'id' => 'w_rc5_n',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => 'STEP 05',
                      'header_size' => 'div',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-num',
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  2 => array(
                    'id' => 'w_rc5_t',
                    'elType' => 'widget',
                    'settings' => array(
                      'title' => '1:1 컨설팅',
                      'header_size' => 'h3',
                      'align' => 'center',
                      '_css_classes' => 'thv2-road-title',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-14',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'heading',
                  ),
                  3 => array(
                    'id' => 'w_rc5_d',
                    'elType' => 'widget',
                    'settings' => array(
                      'editor' => '<p>맞춤 진단으로 성과 가속화</p>',
                      '_css_classes' => 'thv2-road-desc',
                      '_margin' => array(
                        'unit' => 'px',
                        'top' => '-12',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                      '_padding' => array(
                        'unit' => 'px',
                        'top' => '0',
                        'right' => '0',
                        'bottom' => '0',
                        'left' => '0',
                        'isLinked' => false,
                      ),
                    ),
                    'elements' => array(
                    ),
                    'widgetType' => 'text-editor',
                  ),
                ),
                'isInner' => false,
              ),
            ),
            'isInner' => true,
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  5 => array(
    'id' => 'sec_courses',
    'elType' => 'section',
    'settings' => array(
      'css_classes' => 'courses',
      'content_width' => array(
        'unit' => 'px',
        'size' => 1200,
      ),
      'padding_mobile' => array(
        'unit' => 'px',
        'top' => '50',
        'right' => '20',
        'bottom' => '50',
        'left' => '20',
        'isLinked' => false,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_courses',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 100,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_courses_eb',
            'elType' => 'widget',
            'settings' => array(
              'title' => 'COURSES · 강의 라인업',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-eyebrow',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_courses_h2',
            'elType' => 'widget',
            'settings' => array(
              'title' => '지금 수준에 맞는 <span class="accent">입문 · 실전 · 심화</span>',
              'align' => 'center',
              '_css_classes' => 'thv2-h2',
              'typography_typography' => 'custom',
              'typography_font_size_mobile' => array(
                'unit' => 'px',
                'size' => 22,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '700',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          2 => array(
            'id' => 'w_courses_lead',
            'elType' => 'widget',
            'settings' => array(
              'editor' => '<p>얼리버드 50% 할인 중 — 첫 결제 후 평생 수강 가능합니다.</p>',
              'align' => 'center',
              '_css_classes' => 'thv2-lead',
            ),
            'elements' => array(
            ),
            'widgetType' => 'text-editor',
          ),
          3 => array(
            'id' => 'w_courses_grid',
            'elType' => 'widget',
            'settings' => array(
              'shortcode' => '[terra_courses_grid show_header="0"]',
              '_margin_mobile' => array(
                'unit' => 'px',
                'top' => '-50',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding_mobile' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'shortcode',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  6 => array(
    'id' => 'sec_freepdf',
    'elType' => 'section',
    'settings' => array(
      'padding' => array(
        'unit' => 'px',
        'top' => '0',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
        'isLinked' => true,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_freepdf',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 100,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_freepdf',
            'elType' => 'widget',
            'settings' => array(
              'shortcode' => '[terra_freepdf_cta eyebrow="FREE DOWNLOAD" title="마케팅, 어디서부터 시작할지<br>모르겠다면 <span>이 가이드북</span>부터" desc="온라인 마케팅 기초부터 퍼널 설계까지, 실무에 바로 쓰는 50페이지 분량의 실전 로드맵. 카카오로 1초 만에 받아보세요."]',
            ),
            'elements' => array(
            ),
            'widgetType' => 'shortcode',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  7 => array(
    'id' => 'sec_blog',
    'elType' => 'section',
    'settings' => array(
      'css_classes' => 'blog',
      'content_width' => array(
        'unit' => 'px',
        'size' => 1200,
      ),
      'padding_mobile' => array(
        'unit' => 'px',
        'top' => '50',
        'right' => '20',
        'bottom' => '50',
        'left' => '20',
        'isLinked' => false,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_blog',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 100,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_blog_eb',
            'elType' => 'widget',
            'settings' => array(
              'title' => 'BLOG · 인사이트',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-eyebrow',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_blog_h2',
            'elType' => 'widget',
            'settings' => array(
              'title' => '실무자가 쓴 <span class="accent">진짜 노하우</span>',
              'align' => 'center',
              '_css_classes' => 'thv2-h2',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          2 => array(
            'id' => 'w_blog_lead',
            'elType' => 'widget',
            'settings' => array(
              'editor' => '<p>현장에서 검증된 마케팅 전략과 실전 케이스 스터디를 매주 발행합니다.</p>',
              'align' => 'center',
              '_css_classes' => 'thv2-lead',
            ),
            'elements' => array(
            ),
            'widgetType' => 'text-editor',
          ),
          3 => array(
            'id' => 'w_blog_grid',
            'elType' => 'widget',
            'settings' => array(
              'shortcode' => '[terra_blog_grid show_header="0"]',
              '_margin_mobile' => array(
                'unit' => 'px',
                'top' => '-44',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
              '_padding_mobile' => array(
                'unit' => 'px',
                'top' => '0',
                'right' => '0',
                'bottom' => '0',
                'left' => '0',
                'isLinked' => false,
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'shortcode',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  8 => array(
    'id' => 'sec_faq',
    'elType' => 'section',
    'settings' => array(
      'css_classes' => 'thv2-faq',
      'content_width' => array(
        'unit' => 'px',
        'size' => 780,
      ),
      'padding_mobile' => array(
        'unit' => 'px',
        'top' => '50',
        'right' => '20',
        'bottom' => '50',
        'left' => '20',
        'isLinked' => false,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_faq',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 100,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_faq_eb',
            'elType' => 'widget',
            'settings' => array(
              'title' => 'FAQ · 자주 묻는 질문',
              'header_size' => 'div',
              'align' => 'center',
              '_css_classes' => 'thv2-eyebrow',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_faq_h2',
            'elType' => 'widget',
            'settings' => array(
              'title' => '궁금하신 점, <span class="accent">먼저 답해드립니다</span>',
              'align' => 'center',
              '_css_classes' => 'thv2-h2',
              'typography_typography' => 'custom',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 33,
                'sizes' => array(
                ),
              ),
              'typography_font_size_mobile' => array(
                'unit' => 'px',
                'size' => 23,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '700',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          2 => array(
            'id' => 'w_faq_toggle',
            'elType' => 'widget',
            'settings' => array(
              '_css_classes' => 'thv2-faq-toggle',
              'tabs' => array(
                0 => array(
                  '_id' => 'faq1',
                  'tab_title' => '저는 완전 초보인데, 따라할 수 있을까요?',
                  'tab_content' => '<p>네, 충분히 가능합니다. 입문 과정은 <strong>마케팅 용어부터 단계별</strong>로 설명하며, 1,200명의 수강생 중 <strong>80% 이상이 비전공자</strong>입니다. 이해가 어려운 부분은 커뮤니티와 실시간 Q&amp;A에서 언제든 질문하실 수 있습니다.</p>',
                ),
                1 => array(
                  '_id' => 'faq2',
                  'tab_title' => '강의는 어떤 형태로 진행되나요?',
                  'tab_content' => '<p>VOD 영상 강의(평생 재수강 가능) + 주 1회 실시간 Q&amp;A 세션 + 커뮤니티에서의 숙제 피드백으로 구성됩니다. 강의 자료 · 템플릿 · 체크리스트가 모두 PDF로 제공됩니다.</p>',
                ),
                2 => array(
                  '_id' => 'faq3',
                  'tab_title' => '무료로 먼저 체험해볼 수 있나요?',
                  'tab_content' => '<p>네. 가이드북 PDF와 샘플 강의 1강을 무료로 제공합니다. 카카오로 1초 만에 받아보실 수 있으며, 마음에 드시면 유료 과정을 시작하시면 됩니다.</p>',
                ),
                3 => array(
                  '_id' => 'faq4',
                  'tab_title' => '환불 정책은 어떻게 되나요?',
                  'tab_content' => '<p>결제 후 <strong>7일 이내 · 수강 시작 전</strong>이라면 100% 환불 가능합니다. 수강을 시작하신 경우에는 소비자보호법에 따른 기준이 적용되며, 자세한 내용은 이용약관을 참고해주세요.</p>',
                ),
                4 => array(
                  '_id' => 'faq5',
                  'tab_title' => '수강 기간은 얼마나 되나요?',
                  'tab_content' => '<p>유료 과정은 <strong>평생 수강</strong>이 원칙입니다. 강의가 업데이트되어도 추가 비용 없이 계속 보실 수 있으며, 커뮤니티 멤버십도 함께 유지됩니다.</p>',
                ),
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'toggle',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
  9 => array(
    'id' => 'sec_final',
    'elType' => 'section',
    'settings' => array(
      'css_classes' => 'thv2-final-cta',
      'content_width' => array(
        'unit' => 'px',
        'size' => 780,
      ),
    ),
    'elements' => array(
      0 => array(
        'id' => 'col_final',
        'elType' => 'column',
        'settings' => array(
          '_column_size' => 100,
        ),
        'elements' => array(
          0 => array(
            'id' => 'w_final_eb',
            'elType' => 'widget',
            'settings' => array(
              'title' => 'START NOW',
              'header_size' => 'div',
              'align' => 'center',
              'title_color' => 'rgba(255,255,255,0.85)',
              'typography_typography' => 'custom',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 11,
              ),
              'typography_font_weight' => '800',
              'typography_letter_spacing' => array(
                'unit' => 'px',
                'size' => 2,
              ),
              'typography_text_transform' => 'uppercase',
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          1 => array(
            'id' => 'w_final_h2',
            'elType' => 'widget',
            'settings' => array(
              'title' => '지금 시작하세요.<br>당신의 비즈니스가 완성됩니다.',
              '_css_classes' => 'thv2-final-cta-h2',
              'typography_typography' => 'custom',
              'typography_font_size_mobile' => array(
                'unit' => 'px',
                'size' => 25,
                'sizes' => array(
                ),
              ),
              'typography_font_weight' => '700',
              'title_color' => '#FFFFFF',
              'typography_font_size' => array(
                'unit' => 'px',
                'size' => 47,
                'sizes' => array(
                ),
              ),
            ),
            'elements' => array(
            ),
            'widgetType' => 'heading',
          ),
          2 => array(
            'id' => 'w_final_p',
            'elType' => 'widget',
            'settings' => array(
              'editor' => '<p>무료 가이드북으로 감을 잡고, 강의로 실력을 쌓고, 커뮤니티로 지속하세요. 테라플로우가 당신의 모든 여정을 함께합니다.</p>',
              '_css_classes' => 'thv2-final-cta-p',
            ),
            'elements' => array(
            ),
            'widgetType' => 'text-editor',
          ),
          3 => array(
            'id' => 'w_final_btn1',
            'elType' => 'widget',
            'settings' => array(
              'text' => '무료 가이드북 받기 →',
              'link' => array(
                'url' => '/product/온라인-마케팅-무료-가이드북/',
                'is_external' => '',
                'nofollow' => '',
              ),
              'size' => 'lg',
              'align' => 'center',
              'background_color' => '#FFFFFF',
              'button_text_color' => '#1D4ED8',
              'border_radius' => array(
                'unit' => 'px',
                'top' => '12',
                'right' => '12',
                'bottom' => '12',
                'left' => '12',
                'isLinked' => true,
              ),
              'align_mobile' => 'center',
              '_css_classes' => 'thv2-final-cta-btn thv2-final-cta-btn--primary',
            ),
            'elements' => array(
            ),
            'widgetType' => 'button',
          ),
        ),
        'isInner' => false,
      ),
    ),
    'isInner' => false,
  ),
);
