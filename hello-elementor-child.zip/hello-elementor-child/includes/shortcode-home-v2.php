<?php
/**
 * Home Page v2 — Dynamic shortcodes (Courses / Free Guide / Blog)
 *
 * 새 디자인의 동적 섹션을 출력하는 숏코드 3개. Hero / Stats / Problem /
 * Solution / Roadmap / FAQ / Final CTA 같은 정적 섹션은 Elementor 위젯에서
 * 직접 편집하므로 본 파일에 포함되지 않습니다.
 *
 *   [terra_courses_grid]   VOD 상품 3개 (입문/실전/심화) 자동 출력
 *   [terra_freepdf_cta]    freepdf 상품 카드 + 카카오 CTA
 *   [terra_blog_grid]      최신 블로그 글 3개
 *
 * 기존 includes/shortcode-home.php 는 롤백 가능하도록 그대로 유지됩니다.
 *
 * @package HelloElementorChild
 * @since   3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 홈 v2 동적 데이터 — 한 번만 쿼리하고 캐시.
 *
 * - VOD 강의: product_cat = 'vod', _hello_child_pg_sample 메타 보유 상품은 제외,
 *   가격 오름차순으로 3개 (자연스럽게 입문 → 실전 → 심화 순).
 * - freepdf 상품: product_cat = 'freepdf' 의 첫 상품.
 * - 블로그 글: 최신 publish 글 3개.
 */
function _terra_home_v2_data() {
	static $data = null;
	if ( $data !== null ) {
		return $data;
	}

	$exclude_sample = array(
		array(
			'key'     => '_hello_child_pg_sample',
			'compare' => 'NOT EXISTS',
		),
	);

	$data = array(
		'courses'        => get_posts( array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 3,
			'tax_query'      => array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'slug',
					'terms'    => 'vod',
				),
			),
			'meta_query'     => $exclude_sample,
			'meta_key'       => '_price',
			'orderby'        => 'meta_value_num',
			'order'          => 'ASC',
		) ),
		'freepdf_product' => null,
		'blog_posts'     => get_posts( array(
			'post_type'        => 'post',
			'post_status'      => 'publish',
			'posts_per_page'   => 3,
			'orderby'          => 'date',
			'order'            => 'DESC',
			// 검수 미통과 #127: 용어집 / FAQ 포스트는 카테고리가 비어있어
			// 기본 Uncategorized 에 속한 상태로 블로그 그리드에 노출되므로 제외.
			// 추가: 'geo' 카테고리(FAQ/용어집 등 AI 인용 최적화 콘텐츠)도 홈 블로그 그리드에서 제외.
			'category__not_in' => array_filter( array(
				(int) get_option( 'default_category' ),
				(int) ( get_term_by( 'slug', 'geo', 'category' )->term_id ?? 0 ),
			) ),
		) ),
	);

	$freepdf = get_posts( array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => 1,
		'tax_query'      => array(
			array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => 'freepdf',
			),
		),
		'meta_query'     => $exclude_sample,
	) );
	if ( ! empty( $freepdf ) ) {
		$data['freepdf_product'] = $freepdf[0];
	}

	return $data;
}

/* ─────────────────────────────────────────────────────────
 * SVG helpers — 인라인 아이콘 (HTML 디자인 원본과 동일)
 * ───────────────────────────────────────────────────────── */
function _terra_home_v2_icon_check() {
	return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
}
function _terra_home_v2_icon_calendar() {
	return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/></svg>';
}
function _terra_home_v2_icon_video() {
	return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>';
}

/* ═════════════════════════════════════════════════════════
 * [terra_home_v2_hero] — Hero (애니메이션 허브)
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_home_v2_hero', 'terra_home_v2_hero_shortcode' );
function terra_home_v2_hero_shortcode() {
	$d = _terra_home_v2_data();
	$freepdf_url = $d['freepdf_product'] ? get_permalink( $d['freepdf_product']->ID ) : home_url( '/freepdf/' );

	ob_start();
	?>
<section class="thv2-hero" id="hero">
	<div class="wrap hero-inner">
		<div class="hero-l">
			<div class="hero-tag">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
				ALL-IN-ONE GROWTH PLATFORM
			</div>
			<h1>
				당신의 <span class="accent">성장</span>을<br>
				함께 설계합니다.
			</h1>
			<p class="hero-sub">
				강의 · 전자책 · 실시간 Q&amp;A · 커뮤니티 · 스토어까지.
				배움이 실행이 되고, 실행이 성과가 되는 올인원 성장 플랫폼입니다.
			</p>
			<div class="hero-cta-row">
				<a href="<?php echo esc_url( $freepdf_url ); ?>" class="btn btn-primary btn-lg">무료 가이드북 받기 →</a>
			</div>
			<div class="hero-micro">
				<div class="hero-avatars">
					<span>K</span><span>L</span><span>P</span><span>S</span>
				</div>
				<span>이미 <strong>1,200명+</strong>의 수강생이 함께하고 있습니다</span>
			</div>
		</div>

		<div class="hero-visual">
			<div class="hero-hub">
				<div class="hero-orbit"></div>
				<div class="hero-orbit-2"></div>

				<div class="hero-hub-center">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
					<div class="hero-hub-center-label">커뮤니티 허브</div>
				</div>

				<?php for ( $p = 1; $p <= 6; $p++ ) : ?>
					<div class="hero-person hp-<?php echo (int) $p; ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
				<?php endfor; ?>

				<div class="hero-feat hf-1">
					<div class="hero-feat-icon" style="background:rgba(29,78,216,.10);color:#1D4ED8">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
					</div>
					<div><div class="hero-feat-text">VOD 강의</div><div class="hero-feat-sub">50+ 커리큘럼</div></div>
				</div>

				<div class="hero-feat hf-2">
					<div class="hero-feat-icon" style="background:rgba(16,185,129,.10);color:#10B981">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
					</div>
					<div><div class="hero-feat-text">실시간 Q&amp;A</div><div class="hero-feat-sub">라이브 세션</div></div>
				</div>

				<div class="hero-feat hf-3">
					<div class="hero-feat-icon" style="background:rgba(245,158,11,.10);color:#F59E0B">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
					</div>
					<div><div class="hero-feat-text">스토어</div><div class="hero-feat-sub">디지털 상품 판매</div></div>
				</div>

				<div class="hero-feat hf-4">
					<div class="hero-feat-icon" style="background:rgba(168,85,247,.10);color:#A855F7">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
					</div>
					<div><div class="hero-feat-text">전자책 · PDF</div><div class="hero-feat-sub">무료 가이드</div></div>
				</div>

				<div class="hero-feat hf-5">
					<div class="hero-feat-icon" style="background:rgba(236,72,153,.10);color:#EC4899">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
					</div>
					<div><div class="hero-feat-text">마케팅 자동화</div><div class="hero-feat-sub">알림톡 · 메일</div></div>
				</div>

				<div class="hero-feat hf-6">
					<div class="hero-feat-icon" style="background:rgba(6,182,212,.10);color:#06B6D4">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
					</div>
					<div><div class="hero-feat-text">멤버십</div><div class="hero-feat-sub">유료 커뮤니티</div></div>
				</div>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ═════════════════════════════════════════════════════════
 * [terra_home_v2_stats] — 4개 통계 (수강생, 만족도, 강의수, 평점)
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_home_v2_stats', 'terra_home_v2_stats_shortcode' );
function terra_home_v2_stats_shortcode() {
	ob_start();
	?>
<section class="thv2-stats">
	<div class="wrap">
		<div class="stats-grid">
			<div><div class="stat-num"><span class="num">1200</span><span class="small">+</span></div><div class="stat-label">누적 수강생</div></div>
			<div><div class="stat-num"><span class="num">96</span><span class="small">%</span></div><div class="stat-label">수강 만족도</div></div>
			<div><div class="stat-num"><span class="num">50</span><span class="small">+</span></div><div class="stat-label">VOD 강의</div></div>
			<div><div class="stat-num"><span class="num">4.9</span><span class="small">★</span></div><div class="stat-label">평균 평점</div></div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ═════════════════════════════════════════════════════════
 * [terra_home_v2_problem] — 3가지 고민
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_home_v2_problem', 'terra_home_v2_problem_shortcode' );
function terra_home_v2_problem_shortcode() {
	ob_start();
	?>
<section class="thv2-problem">
	<div class="wrap">
		<div class="section-header">
			<div class="eyebrow">PROBLEM · 이런 고민 있으셨나요</div>
			<h2 class="h-section">온라인 마케팅, <span class="underline">시작부터 막히는</span> 3가지 이유</h2>
			<p class="lead">누구나 겪는 문제입니다. 중요한 건 왜 막히는지 정확히 아는 것입니다.</p>
		</div>

		<div class="prob-grid">
			<div class="prob-card">
				<div class="prob-num">01</div>
				<div class="prob-title">어디서부터 시작해야 할지 모르겠다</div>
				<div class="prob-desc">블로그? 인스타? 유튜브? 퍼널? 정보는 쏟아지는데 뭐부터 손대야 할지 막막합니다. 결국 아무것도 시작 못 하고 시간만 흘러갑니다.</div>
			</div>
			<div class="prob-card">
				<div class="prob-num">02</div>
				<div class="prob-title">배워도 실행으로 연결이 안 된다</div>
				<div class="prob-desc">강의는 들었는데 막상 내 사업에 적용하려니 막힙니다. 이론과 실무 사이의 간극, 혼자 넘기엔 너무 큽니다.</div>
			</div>
			<div class="prob-card">
				<div class="prob-num">03</div>
				<div class="prob-title">여러 툴을 따로 써서 비효율적이다</div>
				<div class="prob-desc">블로그, 이메일, 결제, CRM… 매달 구독료는 쌓이고, 데이터는 흩어지고, 연동은 매번 삽질. 본업에 집중할 수 없습니다.</div>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ═════════════════════════════════════════════════════════
 * [terra_home_v2_solution] — 3가지 해답
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_home_v2_solution', 'terra_home_v2_solution_shortcode' );
function terra_home_v2_solution_shortcode() {
	ob_start();
	?>
<section class="thv2-solution">
	<div class="wrap">
		<div class="section-header">
			<div class="eyebrow">SOLUTION · 테라플로우의 해답</div>
			<h2 class="h-section">학습부터 실행까지,<br><span class="accent">한 번에 이어지는</span> 시스템</h2>
			<p class="lead">이론 강의로 끝나지 않습니다. 배운 즉시 실행할 수 있는 로드맵 · 실습 · 올인원 플랫폼을 함께 제공합니다.</p>
		</div>

		<div class="sol-grid">
			<div class="sol-card">
				<div class="sol-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
				</div>
				<div class="sol-num">SOLUTION 01</div>
				<div class="sol-title">단계별 학습 로드맵</div>
				<div class="sol-desc">기초부터 고급까지 명확한 순서로 배웁니다. 무엇을 먼저, 무엇을 다음에 해야 할지 — 테라플로우가 안내합니다.</div>
			</div>
			<div class="sol-card">
				<div class="sol-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
				</div>
				<div class="sol-num">SOLUTION 02</div>
				<div class="sol-title">실행 중심 실습</div>
				<div class="sol-desc">강의를 들으면서 바로 따라 만듭니다. 이론만 듣고 끝나는 강의가 아닙니다. 실제로 돌아가는 시스템이 손에 남습니다.</div>
			</div>
			<div class="sol-card">
				<div class="sol-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
				</div>
				<div class="sol-num">SOLUTION 03</div>
				<div class="sol-title">올인원 플랫폼</div>
				<div class="sol-desc">강의 · 결제 · 자동화 · 고객관리까지 통합. 여러 도구 옮겨다니지 않고 테라플로우 한 곳에서 모두 관리합니다.</div>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ═════════════════════════════════════════════════════════
 * [terra_home_v2_roadmap] — 5단계 성장 여정
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_home_v2_roadmap', 'terra_home_v2_roadmap_shortcode' );
function terra_home_v2_roadmap_shortcode() {
	ob_start();
	?>
<section class="thv2-roadmap" id="roadmap">
	<div class="wrap">
		<div class="section-header">
			<div class="eyebrow">ROADMAP · 5단계 성장 여정</div>
			<h2 class="h-section">무료 전자책부터 <span class="accent">1:1 컨설팅</span>까지,<br>당신의 속도에 맞춰 성장합니다</h2>
			<p class="lead">어디서 시작하든 괜찮습니다. 다음 단계는 언제나 준비되어 있습니다.</p>
		</div>

		<div class="road-grid">
			<div class="road-card">
				<div class="road-card-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
				</div>
				<div class="road-card-num">STEP 01</div>
				<div class="road-card-title">무료 전자책</div>
				<div class="road-card-desc">가볍게 시작하는 입문 가이드북</div>
			</div>
			<div class="road-card">
				<div class="road-card-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
				</div>
				<div class="road-card-num">STEP 02</div>
				<div class="road-card-title">VOD 강의</div>
				<div class="road-card-desc">내 속도로 배우는 체계적 커리큘럼</div>
			</div>
			<div class="road-card">
				<div class="road-card-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/><line x1="21.17" y1="8" x2="12" y2="8"/><line x1="3.95" y1="6.06" x2="8.54" y2="14"/><line x1="10.88" y1="21.94" x2="15.46" y2="14"/></svg>
				</div>
				<div class="road-card-num">STEP 03</div>
				<div class="road-card-title">실시간 강의</div>
				<div class="road-card-desc">강사와 즉시 Q&amp;A 집중 몰입 세션</div>
			</div>
			<div class="road-card">
				<div class="road-card-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
				</div>
				<div class="road-card-num">STEP 04</div>
				<div class="road-card-title">커뮤니티</div>
				<div class="road-card-desc">수강생과 함께 성장 · 동기부여</div>
			</div>
			<div class="road-card">
				<div class="road-card-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
				</div>
				<div class="road-card-num">STEP 05</div>
				<div class="road-card-title">1:1 컨설팅</div>
				<div class="road-card-desc">맞춤 진단으로 성과 가속화</div>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ═════════════════════════════════════════════════════════
 * [terra_home_v2_faq] — 5개 자주 묻는 질문 (native details)
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_home_v2_faq', 'terra_home_v2_faq_shortcode' );
function terra_home_v2_faq_shortcode() {
	ob_start();
	?>
<section class="thv2-faq" id="faq">
	<div class="wrap">
		<div class="section-header">
			<div class="eyebrow">FAQ · 자주 묻는 질문</div>
			<h2 class="h-section">궁금하신 점, <span class="accent">먼저 답해드립니다</span></h2>
		</div>

		<div class="faq-list">
			<details class="faq-item" open>
				<summary>저는 완전 초보인데, 따라할 수 있을까요?</summary>
				<div class="faq-body">네, 충분히 가능합니다. 입문 과정은 <strong>마케팅 용어부터 단계별</strong>로 설명하며, 1,200명의 수강생 중 <strong>80% 이상이 비전공자</strong>입니다. 이해가 어려운 부분은 커뮤니티와 실시간 Q&amp;A에서 언제든 질문하실 수 있습니다.</div>
			</details>
			<details class="faq-item">
				<summary>강의는 어떤 형태로 진행되나요?</summary>
				<div class="faq-body">VOD 영상 강의(평생 재수강 가능) + 주 1회 실시간 Q&amp;A 세션 + 커뮤니티에서의 숙제 피드백으로 구성됩니다. 강의 자료 · 템플릿 · 체크리스트가 모두 PDF로 제공됩니다.</div>
			</details>
			<details class="faq-item">
				<summary>무료로 먼저 체험해볼 수 있나요?</summary>
				<div class="faq-body">네. 가이드북 PDF와 샘플 강의 1강을 무료로 제공합니다. 카카오로 1초 만에 받아보실 수 있으며, 마음에 드시면 유료 과정을 시작하시면 됩니다.</div>
			</details>
			<details class="faq-item">
				<summary>환불 정책은 어떻게 되나요?</summary>
				<div class="faq-body">결제 후 <strong>7일 이내 · 수강 시작 전</strong>이라면 100% 환불 가능합니다. 수강을 시작하신 경우에는 소비자보호법에 따른 기준이 적용되며, 자세한 내용은 이용약관을 참고해주세요.</div>
			</details>
			<details class="faq-item">
				<summary>수강 기간은 얼마나 되나요?</summary>
				<div class="faq-body">유료 과정은 <strong>평생 수강</strong>이 원칙입니다. 강의가 업데이트되어도 추가 비용 없이 계속 보실 수 있으며, 커뮤니티 멤버십도 함께 유지됩니다.</div>
			</details>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ═════════════════════════════════════════════════════════
 * [terra_home_v2_final_cta] — 마지막 CTA (블루 그라디언트)
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_home_v2_final_cta', 'terra_home_v2_final_cta_shortcode' );
function terra_home_v2_final_cta_shortcode() {
	$d = _terra_home_v2_data();
	$freepdf_url = $d['freepdf_product'] ? get_permalink( $d['freepdf_product']->ID ) : home_url( '/freepdf/' );

	ob_start();
	?>
<section class="thv2-final-cta">
	<div class="wrap">
		<div class="eyebrow">START NOW</div>
		<h2>지금 시작하세요.<br>당신의 비즈니스가 완성됩니다.</h2>
		<p>무료 가이드북으로 감을 잡고, 강의로 실력을 쌓고, 커뮤니티로 지속하세요. 테라플로우가 당신의 모든 여정을 함께합니다.</p>
		<div class="final-cta-row">
			<a href="<?php echo esc_url( $freepdf_url ); ?>" class="btn btn-primary btn-lg">무료 가이드북 받기 →</a>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ═════════════════════════════════════════════════════════
 * [terra_home_v2] — 마스터: 10개 섹션 디자인 순서대로 출력
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_home_v2', 'terra_home_v2_shortcode' );
function terra_home_v2_shortcode() {
	$sections = array(
		'terra_home_v2_hero',
		'terra_home_v2_stats',
		'terra_home_v2_problem',
		'terra_home_v2_solution',
		'terra_home_v2_roadmap',
		'terra_courses_grid',
		'terra_freepdf_cta',
		'terra_blog_grid',
		'terra_home_v2_faq',
		'terra_home_v2_final_cta',
	);
	$out = '';
	foreach ( $sections as $sc ) {
		$out .= do_shortcode( '[' . $sc . ']' );
	}
	return $out;
}

/* ═════════════════════════════════════════════════════════
 * [terra_courses_grid] — VOD 강의 3개 (입문 / 실전 / 심화)
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_courses_grid', 'terra_courses_grid_shortcode' );
function terra_courses_grid_shortcode( $atts = array() ) {
	$atts = shortcode_atts( array(
		'show_header' => '1',
	), $atts, 'terra_courses_grid' );

	$d       = _terra_home_v2_data();
	$courses = $d['courses'];

	$levels = array(
		0 => 'LEVEL 01 · 입문',
		1 => 'LEVEL 02 · 실전',
		2 => 'LEVEL 03 · 심화',
	);

	$embedded = '0' === (string) $atts['show_header'];
	ob_start();
	?>
<section class="courses<?php echo $embedded ? ' is-embedded' : ''; ?>" id="courses">
	<div class="wrap">
		<?php if ( ! $embedded ) : ?>
		<div class="section-header">
			<div class="eyebrow">COURSES · 강의 라인업</div>
			<h2 class="h-section">지금 수준에 맞는 <span class="accent">입문 · 실전 · 심화</span></h2>
			<p class="lead">얼리버드 50% 할인 중 — 첫 결제 후 평생 수강 가능합니다.</p>
		</div>
		<?php endif; ?>

		<div class="course-grid">
			<?php if ( ! empty( $courses ) ) : ?>
				<?php foreach ( $courses as $i => $course ) :
					$product   = function_exists( 'wc_get_product' ) ? wc_get_product( $course->ID ) : null;
					$is_feat   = ( 1 === $i );
					$level     = $levels[ $i ] ?? '';
					$permalink = get_permalink( $course->ID );
					$thumb_id  = get_post_thumbnail_id( $course->ID );
					$thumb_url = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium_large' ) : '';

					// course-feat 리스트: 상품 short_description 의 줄 단위로 분해, 없으면 excerpt.
					$desc_raw = $product ? $product->get_short_description() : $course->post_excerpt;
					$desc_raw = wp_strip_all_tags( $desc_raw );
					$features = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $desc_raw ) ) ) );
					if ( empty( $features ) ) {
						$features = array( '강의 상세 페이지에서 커리큘럼을 확인하세요.' );
					}

					// course-meta: 주차/강수 (상품 attribute pa_weeks / pa_lessons 사용 가능 시)
					$weeks   = '';
					$lessons = '';
					if ( $product ) {
						$weeks   = $product->get_attribute( 'weeks' );
						$lessons = $product->get_attribute( 'lessons' );
					}
				?>
				<div class="course-card<?php echo $is_feat ? ' featured' : ''; ?>">
					<a href="<?php echo esc_url( $permalink ); ?>" class="course-thumb<?php echo $thumb_url ? '' : ' is-placeholder'; ?>">
						<?php if ( $thumb_url ) : ?>
							<img src="<?php echo esc_url( $thumb_url ); ?>" alt="<?php echo esc_attr( $course->post_title ); ?>" loading="lazy">
						<?php else : ?>
							<span class="course-thumb-label"><?php echo esc_html( $levels[ $i ] ?? '' ); ?></span>
						<?php endif; ?>
					</a>
					<div class="course-level"><?php echo esc_html( $level ); ?></div>
					<div class="course-title"><?php echo esc_html( $course->post_title ); ?></div>

					<?php if ( $weeks || $lessons ) : ?>
					<div class="course-meta">
						<?php if ( $weeks ) : ?>
							<span><?php echo _terra_home_v2_icon_calendar(); // phpcs:ignore ?><?php echo esc_html( $weeks ); ?></span>
						<?php endif; ?>
						<?php if ( $lessons ) : ?>
							<span><?php echo _terra_home_v2_icon_video(); // phpcs:ignore ?><?php echo esc_html( $lessons ); ?></span>
						<?php endif; ?>
					</div>
					<?php endif; ?>

					<ul class="course-feat">
						<?php foreach ( array_slice( $features, 0, 5 ) as $feat ) : ?>
							<li><?php echo esc_html( $feat ); ?></li>
						<?php endforeach; ?>
					</ul>

					<?php if ( $product ) : ?>
					<div class="course-price">
						<?php
						$regular  = (float) $product->get_regular_price();
						$sale     = (float) $product->get_sale_price();
						$has_sale = $sale > 0 && $sale < $regular;
						$display  = $has_sale ? $sale : $regular;
						$pct      = $has_sale ? (int) round( ( ( $regular - $sale ) / $regular ) * 100 ) : 0;
						?>
						<?php if ( $has_sale ) : ?>
							<div class="course-save"><?php echo esc_html( $pct ); ?>% SAVE</div>
						<?php endif; ?>
						<div class="course-price-row">
							<?php if ( $has_sale ) : ?>
								<span class="course-old">₩<?php echo esc_html( number_format( $regular ) ); ?></span>
							<?php endif; ?>
							<span class="course-new"><span class="krw">₩</span><?php echo esc_html( number_format( $display ) ); ?></span>
						</div>
					</div>
					<?php endif; ?>

					<a href="<?php echo esc_url( $permalink ); ?>" class="course-cta">자세히 보기</a>
				</div>
				<?php endforeach; ?>
			<?php else : ?>
				<div class="course-card" style="grid-column:1/-1;text-align:center;">
					<p>강의가 준비 중입니다. 곧 만나보실 수 있습니다.</p>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ═════════════════════════════════════════════════════════
 * [terra_freepdf_cta] — Free Guide PDF + 카카오 CTA
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_freepdf_cta', 'terra_freepdf_cta_shortcode' );
function terra_freepdf_cta_shortcode( $atts = array() ) {
	$atts = shortcode_atts( array(
		'eyebrow'  => 'FREE DOWNLOAD',
		'title'    => '마케팅, 어디서부터 시작할지<br>모르겠다면 <span>이 가이드북</span>부터',
		'desc'     => '온라인 마케팅 기초부터 퍼널 설계까지, 실무에 바로 쓰는 50페이지 분량의 실전 로드맵. 카카오로 1초 만에 받아보세요.',
		'cover_title' => '',
	), $atts, 'terra_freepdf_cta' );

	$d       = _terra_home_v2_data();
	$freepdf = $d['freepdf_product'];

	$freepdf_url   = $freepdf ? get_permalink( $freepdf->ID ) : home_url( '/freepdf/' );
	$freepdf_title = $atts['cover_title'] ?: ( $freepdf ? $freepdf->post_title : '온라인 마케팅 무료 가이드북' );

	ob_start();
	?>
<section class="hc-freepdf" id="freepdf">
	<div class="hc-freepdf-inner">
		<div class="hc-freepdf-grid">
			<div class="hc-freepdf-left">
				<div class="hc-freepdf-label"><?php echo esc_html( $atts['eyebrow'] ); ?></div>
				<h2><?php echo wp_kses_post( $atts['title'] ); ?></h2>
				<p><?php echo esc_html( $atts['desc'] ); ?></p>

				<ul class="hc-freepdf-features">
					<li><?php echo _terra_home_v2_icon_check(); // phpcs:ignore ?>강의 사지 않아도 핵심은 다 담았습니다</li>
					<li><?php echo _terra_home_v2_icon_check(); // phpcs:ignore ?>바로 따라할 수 있는 체크리스트 포함</li>
					<li><?php echo _terra_home_v2_icon_check(); // phpcs:ignore ?>다운로드 즉시 이메일로 발송</li>
				</ul>

				<p class="hc-freepdf-micro"><span class="dot"></span>이미 <strong>850명+</strong>이 다운로드했습니다</p>
			</div>

			<div class="hc-freepdf-right">
				<div class="hc-freepdf-cover">
					<div class="hc-freepdf-cover-tag">FREE GUIDE</div>
					<h3><?php echo esc_html( $freepdf_title ); ?></h3>
					<ul class="hc-freepdf-checklist">
						<li><?php echo _terra_home_v2_icon_check(); // phpcs:ignore ?>수익화 가능한 주제 선정법</li>
						<li><?php echo _terra_home_v2_icon_check(); // phpcs:ignore ?>무료 → 유료 전환 퍼널 구조</li>
						<li><?php echo _terra_home_v2_icon_check(); // phpcs:ignore ?>첫 100 고객 확보 전략</li>
						<li><?php echo _terra_home_v2_icon_check(); // phpcs:ignore ?>마케팅 자동화 스타터 가이드</li>
					</ul>
					<a href="<?php echo esc_url( $freepdf_url ); ?>" class="hc-freepdf-kakao hc-freepdf-detail-btn">
						자세히 보기
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ═════════════════════════════════════════════════════════
 * [terra_blog_grid] — 최신 블로그 글 3개
 * ═════════════════════════════════════════════════════════ */
add_shortcode( 'terra_blog_grid', 'terra_blog_grid_shortcode' );
function terra_blog_grid_shortcode( $atts = array() ) {
	$atts = shortcode_atts( array(
		'show_header' => '1',
	), $atts, 'terra_blog_grid' );

	$d     = _terra_home_v2_data();
	$posts = $d['blog_posts'];

	$embedded = '0' === (string) $atts['show_header'];
	ob_start();
	?>
<section class="blog<?php echo $embedded ? ' is-embedded' : ''; ?>" id="blog">
	<div class="wrap">
		<?php if ( ! $embedded ) : ?>
		<div class="section-header">
			<div class="eyebrow">BLOG · 인사이트</div>
			<h2 class="h-section">실무자가 쓴 <span class="accent">진짜 노하우</span></h2>
			<p class="lead">현장에서 검증된 마케팅 전략과 실전 케이스 스터디를 매주 발행합니다.</p>
		</div>
		<?php endif; ?>

		<div class="blog-grid">
			<?php if ( ! empty( $posts ) ) : ?>
				<?php foreach ( $posts as $bp ) :
					$cats     = get_the_category( $bp->ID );
					$cat_name = ! empty( $cats ) ? strtoupper( $cats[0]->name ) : 'BLOG';
					$thumb_id = get_post_thumbnail_id( $bp->ID );
					$thumb    = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium_large' ) : '';
					$reading  = max( 1, (int) round( str_word_count( wp_strip_all_tags( $bp->post_content ) ) / 200 ) );
					$badge    = mb_substr( $bp->post_title, 0, 4 );
				?>
				<a href="<?php echo esc_url( get_permalink( $bp->ID ) ); ?>" class="blog-card">
					<div class="blog-thumb">
						<?php if ( $thumb ) : ?>
							<img src="<?php echo esc_url( $thumb ); ?>" alt="<?php echo esc_attr( $bp->post_title ); ?>" loading="lazy">
						<?php else : ?>
							<span><?php echo esc_html( $badge ); ?></span>
						<?php endif; ?>
					</div>
					<div class="blog-body">
						<div class="blog-meta">
							<span class="tag"><?php echo esc_html( $cat_name ); ?></span>
							<span>· <?php echo esc_html( $reading ); ?>분</span>
						</div>
						<div class="blog-title"><?php echo esc_html( $bp->post_title ); ?></div>
						<div class="blog-excerpt"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $bp->post_content ), 28, '…' ) ); ?></div>
					</div>
				</a>
				<?php endforeach; ?>
			<?php else : ?>
				<div style="grid-column:1/-1;text-align:center;padding:60px 20px;">
					<p>블로그 글이 준비 중입니다.</p>
				</div>
			<?php endif; ?>
		</div>

		<div class="blog-all">
			<a href="<?php echo esc_url( home_url( '/blogs/' ) ); ?>">
				블로그 전체 보기
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
			</a>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}
