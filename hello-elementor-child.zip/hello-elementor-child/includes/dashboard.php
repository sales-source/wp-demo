<?php
/**
 * Terra 커스텀 대시보드
 *
 * wp-admin에 Terra 대시보드 메뉴를 등록하고, Vanilla JS SPA를 렌더링한다.
 * 개발 완료 후 TERRA_DASHBOARD_REDIRECT 상수를 true로 변경하면
 * 기본 알림판(index.php) 접속 시 자동 리다이렉트된다.
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 리다이렉트 스위치 — 개발 중에는 false, 완성 후 true로 변경
 */
if ( ! defined( 'TERRA_DASHBOARD_REDIRECT' ) ) {
	define( 'TERRA_DASHBOARD_REDIRECT', true );
}

/**
 * 대시보드 메뉴 등록
 */
add_action( 'admin_menu', 'terra_dashboard_register_menu' );
function terra_dashboard_register_menu() {
	// 커스텀 대시보드를 최상단에 배치
	add_menu_page(
		'대시보드',
		'대시보드',
		'manage_options',
		'terra-dashboard',
		'terra_dashboard_render',
		'dashicons-dashboard',
		1
	);

}

// 기본 WP 알림판 메뉴 숨김 (admin_menu 후순위에서 제거)
add_action( 'admin_menu', 'terra_dashboard_hide_wp_dashboard', 999 );
function terra_dashboard_hide_wp_dashboard() {
	remove_menu_page( 'index.php' );
}

/**
 * 기본 알림판 → Terra 대시보드 리다이렉트 (스위치 ON일 때만)
 */
if ( TERRA_DASHBOARD_REDIRECT ) {
	add_action( 'load-index.php', 'terra_dashboard_redirect' );
}
function terra_dashboard_redirect() {
	if ( current_user_can( 'manage_options' ) ) {
		wp_redirect( admin_url( 'admin.php?page=terra-dashboard' ) );
		exit;
	}
}

/**
 * 대시보드 페이지 렌더링
 */
function terra_dashboard_render() {
	echo '<div class="wrap" style="margin:0;padding:0;max-width:100%;">';

	// WP/플러그인 알림 유지
	echo '<div id="terra-dashboard-notices" style="padding:0 20px;">';
	do_action( 'admin_notices' );
	echo '</div>';

	// Vanilla JS 마운트 포인트
	echo '<div id="terra-dashboard-app"></div>';
	echo '</div>';
}

/**
 * 에셋 로드 — terra-dashboard 페이지에서만
 */
add_action( 'admin_enqueue_scripts', 'terra_dashboard_enqueue_assets' );
function terra_dashboard_enqueue_assets( $hook ) {
	if ( 'toplevel_page_terra-dashboard' !== $hook ) {
		return;
	}

	// WP 기본 대시보드 스타일/스크립트 제거
	wp_dequeue_style( 'dashboard' );
	wp_dequeue_script( 'dashboard' );

	// wp-admin 기본 여백 제거
	wp_add_inline_style( 'wp-admin', '
		#wpcontent { padding-left: 0 !important; }
		#wpbody-content { padding-bottom: 0 !important; }
		#wpfooter { display: none !important; }
	' );

	// 대시보드 CSS
	wp_enqueue_style(
		'terra-dashboard',
		HELLO_CHILD_URI . '/assets/css/terra-dashboard.css',
		[],
		HELLO_CHILD_VERSION . '.' . filemtime( HELLO_CHILD_DIR . '/assets/css/terra-dashboard.css' )
	);

	// 대시보드 JS
	wp_enqueue_script(
		'terra-dashboard',
		HELLO_CHILD_URI . '/assets/js/terra-dashboard.js',
		[],
		HELLO_CHILD_VERSION . '.' . filemtime( HELLO_CHILD_DIR . '/assets/js/terra-dashboard.js' ),
		true
	);

	// 설정 데이터 주입
	wp_localize_script( 'terra-dashboard', 'terraDashboard', terra_dashboard_get_config() );
}

/**
 * JS에 주입할 설정 데이터
 */
function terra_dashboard_get_config() {
	$user = wp_get_current_user();

	return [
		// REST API
		'restUrl' => esc_url_raw( rest_url() ),
		'nonce'   => wp_create_nonce( 'wp_rest' ),

		// 사이트 정보
		'siteUrl'   => home_url(),
		'adminUrl'  => admin_url(),
		'userId'    => $user->ID,
		'userName'  => $user->display_name,
		'siteTitle' => get_bloginfo( 'name' ),

		// 플러그인 활성 상태
		'plugins' => [
			'tosspay'     => class_exists( 'WC_Gateway_TossPay' ),
			'alimtalk'    => class_exists( 'Terra_Alimtalk' ),
			'kakao'       => class_exists( 'Terra_Kakao' ),
			'lms'         => class_exists( 'Terra_LMS' ),
			'woocommerce' => class_exists( 'WooCommerce' ),
			'terra_guide' => class_exists( 'Terra_Guide' ),
		],

		// 바로가기 URL
		'links' => [
			'general_settings'  => admin_url( 'options-general.php' ),
			'site_identity'     => admin_url( 'customize.php?autofocus[section]=title_tagline' ),
			'tosspay_settings'  => admin_url( 'admin.php?page=wc-settings&tab=checkout&section=tosspay' ),
			'woo_settings'      => admin_url( 'admin.php?page=wc-settings' ),
			'products'          => admin_url( 'edit.php?post_type=product' ),
			'new_product'       => admin_url( 'post-new.php?post_type=product' ),
			'kakao_settings'    => admin_url( 'admin.php?page=terra-kakao' ),
			'alimtalk_settings' => admin_url( 'admin.php?page=terra-alimtalk' ),
			'smtp_settings'     => admin_url( 'admin.php?page=terra-smtp' ),
			'lms_admin'         => admin_url( 'admin.php?page=terra-lms-admin' ),
			'elementor'         => admin_url( 'edit.php?post_type=elementor_library' ),
			'pages'             => admin_url( 'edit.php?post_type=page' ),
			'new_post'          => admin_url( 'post-new.php' ),
			'posts'             => admin_url( 'edit.php' ),
			'reading_settings'  => admin_url( 'options-reading.php' ),
			'permalink'         => admin_url( 'options-permalink.php' ),
			'menus'             => admin_url( 'nav-menus.php' ),
		],

		// 온보딩 자동 감지 결과
		'onboarding' => terra_dashboard_detect_onboarding(),

		// 사이트 기본 정보 (서버에서 미리 로드)
		'siteSettings' => [
			'blogname'        => get_option( 'blogname', '' ),
			'blogdescription' => get_option( 'blogdescription', '' ),
			'primary_color'   => get_option( 'terra_site_primary_color', '#1D4ED8' ),
		],

		// 사업자 정보 (서버에서 미리 로드)
		'business' => terra_dashboard_get_business_info(),

		// 사이트 진단 (서버 사이드 — terra-guide 없어도 동작)
		'diagnosis' => terra_dashboard_run_diagnosis(),

		// PG 심사 모드 상태
		'pgReviewMode' => terra_dashboard_is_pg_review_mode(),
	];
}

/**
 * 사업자 정보 조회
 */
function terra_dashboard_get_business_info() {
	$fields = [ 'name', 'ceo', 'number', 'phone', 'address', 'email', 'privacy_officer' ];
	$info   = [];
	foreach ( $fields as $f ) {
		$info[ $f ] = get_option( "terra_business_{$f}", '' );
	}
	return $info;
}

/**
 * 사이트 진단 (terra-guide 플러그인 있으면 활용, 없으면 자체 진단)
 */
function terra_dashboard_run_diagnosis() {
	$checks = [];

	// 카카오 로그인
	$kakao_key    = get_option( 'terra_kakao_rest_api_key', '' );
	$kakao_secret = get_option( 'terra_kakao_client_secret', '' );
	$checks[] = [
		'id'     => 'kakao',
		'label'  => '카카오 로그인',
		'status' => ( $kakao_key && $kakao_secret ) ? 'ok' : 'warn',
		'msg'    => ( $kakao_key && $kakao_secret ) ? 'REST API 키·시크릿 설정됨' : 'REST API 키 또는 시크릿이 비어 있습니다',
		'link'   => admin_url( 'admin.php?page=terra-kakao&terra-guide=kakao_settings#/kakao/settings' ),
	];

	// 토스페이
	$toss_secret = get_option( 'terra_tosspay_secret_key', '' );
	$checks[] = [
		'id'     => 'tosspay',
		'label'  => '토스페이 결제',
		'status' => $toss_secret ? 'ok' : 'warn',
		'msg'    => $toss_secret ? '시크릿 키 설정됨' : '시크릿 키가 비어 있습니다',
		'link'   => admin_url( 'admin.php?page=wc-settings&tab=checkout&section=tosspay&terra-guide=tosspay_settings' ),
	];

	// 알림톡
	$alimtalk_key = get_option( 'terra_alimtalk_senderkey', '' );
	$checks[] = [
		'id'     => 'alimtalk',
		'label'  => '알림톡',
		'status' => $alimtalk_key ? 'ok' : 'warn',
		'msg'    => $alimtalk_key ? '센더키 설정됨' : '센더키가 비어 있습니다',
		'link'   => admin_url( 'admin.php?page=terra-kakao&terra-guide=alimtalk_settings#/alimtalk/settings' ),
	];

	// SMTP
	$smtp_raw  = get_option( 'terra_smtp_settings', [] );
	$smtp      = is_string( $smtp_raw ) ? ( json_decode( $smtp_raw, true ) ?: [] ) : $smtp_raw;
	$smtp_host = ! empty( $smtp['host'] ) ? $smtp['host'] : '';
	$checks[] = [
		'id'     => 'smtp',
		'label'  => 'SMTP 이메일',
		'status' => $smtp_host ? 'ok' : 'warn',
		'msg'    => $smtp_host ? '호스트: ' . esc_html( $smtp_host ) : 'SMTP 호스트 미설정',
		'link'   => admin_url( 'admin.php?page=terra-smtp' ),
	];

	// 테라 플러그인 활성화 여부
	$active_plugins = (array) get_option( 'active_plugins', [] );
	$terra_active   = false;
	$terra_version  = '?';
	foreach ( $active_plugins as $p ) {
		if ( strpos( $p, 'terra-plugins.php' ) !== false ) {
			$terra_active  = true;
			$terra_version = get_option( 'terra_plugins_version', '?' );
			break;
		}
	}
	$checks[] = [
		'id'     => 'terra_plugins',
		'label'  => '테라 플러그인',
		'status' => $terra_active ? 'ok' : 'error',
		'msg'    => $terra_active ? '활성화됨 (v' . esc_html( $terra_version ) . ')' : '비활성화 상태',
		'link'   => admin_url( 'plugins.php' ),
	];

	return $checks;
}

/**
 * 온보딩 각 Step 완료 여부 자동 감지
 */
function terra_dashboard_detect_onboarding() {
	$result = [];

	// 스텝 레벨 (하위 호환)
	$tosspay_settings = get_option( 'woocommerce_tosspay_settings', [] );
	$result['payment']    = ! empty( $tosspay_settings['client_key'] ?? '' );
	$result['kakao']      = ! empty( get_option( 'terra_kakao_rest_api_key', '' ) );
	$result['smart_noti'] = ! empty( get_option( 'terra_alimtalk_senderkey', '' ) );

	// 태스크 레벨 자동 감지 (16개)
	$tasks = [];

	// ── 결제 연동 (6) ──
	$tasks['pg_apply']       = ! empty( $tosspay_settings['client_key'] ?? '' );
	// product_create / pg_page 는 수동 체크 — 자동 생성된 샘플 상품으로 선체크되는 것 방지
	$tasks['product_create'] = false;
	$tasks['pg_page']        = false;
	$tasks['test_payment']   = false; // 수동 체크
	$tasks['safe_plan']      = false; // 수동 체크
	$toss_mode               = $tosspay_settings['mode'] ?? 'test';
	$tasks['card_review']    = ( 'live' === $toss_mode );

	// ── 카카오 로그인 (4) ──
	$kakao_key    = get_option( 'terra_kakao_rest_api_key', '' );
	$kakao_secret = get_option( 'terra_kakao_client_secret', '' );
	$tasks['kakao_login']    = ! empty( $kakao_key );
	$tasks['login_page']     = false; // 수동 체크
	$tasks['biz_channel']    = ! empty( $kakao_secret );
	$tasks['auto_friend']    = false; // 수동 체크

	// ── 스마트 알림 (6) ──
	$sender_key = get_option( 'terra_alimtalk_senderkey', '' );
	$tasks['kakao_ch']       = ! empty( $sender_key );
	$tasks['alimtalk_tpl']   = false; // 수동 체크
	$tasks['alimtalk_test']  = false; // 수동 체크
	$tasks['brand_msg']      = false; // 수동 체크
	$tasks['sms_test']       = false; // 수동 체크
	$tasks['email_test']     = false; // 수동 체크

	$result['tasks'] = $tasks;
	return $result;
}

/**
 * REST API — 온보딩 + 사업자 정보
 */
add_action( 'rest_api_init', 'terra_dashboard_register_rest' );
function terra_dashboard_register_rest() {
	$admin_perm = function () { return current_user_can( 'manage_options' ); };

	// 온보딩 진행률
	register_rest_route( 'terra-dashboard/v1', '/onboarding', [
		[ 'methods' => 'GET',  'callback' => 'terra_dashboard_rest_get_onboarding',    'permission_callback' => $admin_perm ],
		[ 'methods' => 'POST', 'callback' => 'terra_dashboard_rest_update_onboarding', 'permission_callback' => $admin_perm ],
	] );

	// 사업자 정보
	register_rest_route( 'terra-dashboard/v1', '/business', [
		[ 'methods' => 'GET',  'callback' => 'terra_dashboard_rest_get_business',    'permission_callback' => $admin_perm ],
		[ 'methods' => 'POST', 'callback' => 'terra_dashboard_rest_update_business', 'permission_callback' => $admin_perm ],
	] );

	// 사이트 기본 설정 (제목, 태그라인)
	register_rest_route( 'terra-dashboard/v1', '/site-settings', [
		[ 'methods' => 'POST', 'callback' => 'terra_dashboard_rest_update_site_settings', 'permission_callback' => $admin_perm ],
	] );

	// PG 심사 모드 토글
	register_rest_route( 'terra-dashboard/v1', '/pg-review-mode', [
		[ 'methods' => 'POST', 'callback' => 'terra_dashboard_rest_toggle_pg_review', 'permission_callback' => $admin_perm ],
	] );
}

/**
 * 사이트 기본 설정 REST 핸들러
 */
function terra_dashboard_rest_update_site_settings( $request ) {
	$data    = $request->get_json_params();
	$allowed = [ 'blogname', 'blogdescription' ];
	$updated = [];

	foreach ( $allowed as $key ) {
		if ( isset( $data[ $key ] ) ) {
			update_option( $key, sanitize_text_field( $data[ $key ] ) );
			$updated[ $key ] = get_option( $key );
		}
	}

	// 강조색 (Primary) — 저장 + Elementor 글로벌 색상 + CSS 캐시 무효화
	if ( isset( $data['primary_color'] ) ) {
		$hex = sanitize_hex_color( $data['primary_color'] );
		if ( $hex ) {
			update_option( 'terra_site_primary_color', $hex );
			terra_dashboard_sync_primary_to_elementor( $hex );
			$updated['primary_color'] = $hex;
		}
	}

	return rest_ensure_response( [ 'success' => true, 'settings' => $updated ] );
}

/**
 * 대시보드 강조색을 Elementor Kit Primary 로 동기화 + CSS 캐시 초기화
 *
 * 단순 Elementor 편집만으로는 프론트 CSS 캐시가 남아 Primary 변경이 즉시 반영되지 않는 이슈가 있어,
 * 대시보드 저장 시점에 반드시 캐시를 날린다.
 */
function terra_dashboard_sync_primary_to_elementor( $hex ) {
	$kit_id = get_option( 'elementor_active_kit' );
	if ( ! $kit_id ) {
		return;
	}

	$settings = get_post_meta( $kit_id, '_elementor_page_settings', true );
	if ( ! is_array( $settings ) || empty( $settings['system_colors'] ) ) {
		return;
	}

	foreach ( $settings['system_colors'] as &$c ) {
		if ( ( $c['_id'] ?? '' ) === 'primary' ) {
			$c['color'] = $hex;
			break;
		}
	}
	unset( $c );

	update_post_meta( $kit_id, '_elementor_page_settings', $settings );
	delete_post_meta( $kit_id, '_elementor_css' );

	if ( class_exists( '\Elementor\Plugin' ) ) {
		\Elementor\Plugin::$instance->files_manager->clear_cache();
	}
}

/**
 * 강조색을 home-v2 CSS 변수로 프론트에 주입
 *
 * home-v2.css 의 --flow-1 / --flow-grad 가 하드코딩 #1D4ED8 이라 Elementor Primary 변경만으로는
 * 강조 요소(버튼 배경, eyebrow 등) 가 변하지 않는다. 옵션이 있으면 wp_head 에서 :root 를 덮어쓴다.
 */
add_action( 'wp_head', 'terra_dashboard_inject_primary_css', 99 );
function terra_dashboard_inject_primary_css() {
	$hex = get_option( 'terra_site_primary_color', '' );
	if ( ! $hex ) {
		return;
	}
	$hex = sanitize_hex_color( $hex );
	if ( ! $hex ) {
		return;
	}
	printf(
		'<style id="terra-primary-override">:root{--flow-1:%1$s;--flow-2:%1$s;--flow-grad:linear-gradient(135deg,%1$s 0%%,%1$s 100%%);--flow-grad-h:linear-gradient(90deg,%1$s 0%%,%1$s 100%%);}</style>',
		esc_attr( $hex )
	);
}

/**
 * 사업자 정보 REST 핸들러
 */
function terra_dashboard_rest_get_business() {
	return rest_ensure_response( terra_dashboard_get_business_info() );
}

function terra_dashboard_rest_update_business( $request ) {
	$data   = $request->get_json_params();
	$fields = [ 'name', 'ceo', 'number', 'phone', 'address', 'email', 'privacy_officer' ];

	foreach ( $fields as $f ) {
		if ( isset( $data[ $f ] ) ) {
			update_option( "terra_business_{$f}", sanitize_text_field( $data[ $f ] ) );
		}
	}

	// Elementor 푸터 템플릿에 사업자 정보 동기화
	terra_dashboard_sync_elementor_footer();

	return rest_ensure_response( [ 'success' => true, 'business' => terra_dashboard_get_business_info() ] );
}

/**
 * Elementor 푸터 템플릿의 사업자 정보를 WP options 값으로 동기화
 */
function terra_dashboard_sync_elementor_footer() {
	$footer_post = get_posts( [
		'post_type'      => 'elementor_library',
		'post_status'    => 'publish',
		'title'          => '푸터',
		'posts_per_page' => 1,
	] );

	if ( empty( $footer_post ) ) {
		return;
	}

	$post_id = $footer_post[0]->ID;
	$data    = json_decode( get_post_meta( $post_id, '_elementor_data', true ), true );

	if ( ! is_array( $data ) ) {
		return;
	}

	$biz = terra_dashboard_get_business_info();

	// 사업자 정보 항목 전체 재구성
	$biz_items = [
		'회사명 : ' . ( $biz['name'] ?: '테라클래스' ),
		'대표자 : ' . ( $biz['ceo'] ?: '홍길동' ),
		'사업장 소재지 : ' . ( $biz['address'] ?: '서울 용산구 한강대로 100' ),
		'사업자등록번호 : ' . ( $biz['number'] ?: '123-123-123' ),
		'이메일 : ' . ( $biz['email'] ?: 'support@teraclass.net' ),
		'고객 센터 : ' . ( $biz['phone'] ?: '02-1234-1234' ),
		'개인정보관리책임자 : ' . ( $biz['privacy_officer'] ?: '홍길동' ),
	];

	$updated = false;
	terra_dashboard_walk_rebuild_biz_list( $data, $biz_items, $updated );

	update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
	delete_post_meta( $post_id, '_elementor_css' );

	// Elementor CSS 캐시 초기화
	if ( class_exists( '\Elementor\Plugin' ) ) {
		\Elementor\Plugin::$instance->files_manager->clear_cache();
	}
}

/**
 * Elementor data에서 사업자 정보 icon-list를 찾아 항목 전체를 재구성
 *
 * '회사명' 또는 '대표자' 텍스트가 포함된 첫 번째 icon-list를 대상으로 한다.
 */
function terra_dashboard_walk_rebuild_biz_list( &$elements, $biz_items, &$updated ) {
	if ( $updated ) {
		return;
	}
	foreach ( $elements as &$el ) {
		if ( $updated ) {
			return;
		}
		if ( isset( $el['widgetType'] ) && $el['widgetType'] === 'icon-list' && isset( $el['settings']['icon_list'] ) ) {
			// 사업자 정보 icon-list인지 확인 (첫 항목이 '회사명'을 포함)
			$first_text = $el['settings']['icon_list'][0]['text'] ?? '';
			if ( mb_strpos( $first_text, '회사명' ) === false ) {
				continue;
			}

			// 기존 항목의 아이콘 설정을 보존하면서 텍스트와 개수를 재구성
			$template_item = $el['settings']['icon_list'][0];
			$new_list = [];
			foreach ( $biz_items as $i => $text ) {
				$item = $template_item;
				$item['text'] = $text;
				$item['_id']  = 'ftr_biz_sync_' . $i;
				$new_list[]   = $item;
			}
			$el['settings']['icon_list'] = $new_list;
			$updated = true;
			return;
		}
		if ( ! empty( $el['elements'] ) ) {
			terra_dashboard_walk_rebuild_biz_list( $el['elements'], $biz_items, $updated );
		}
	}
}

/**
 * 가이드 엔진 — 모든 admin 페이지에서 로드
 */
add_action( 'admin_enqueue_scripts', 'terra_guide_engine_enqueue' );
function terra_guide_engine_enqueue() {
	// 가이드 엔진 CSS
	wp_enqueue_style(
		'terra-guide-engine',
		HELLO_CHILD_URI . '/assets/css/terra-guide-engine.css',
		[],
		HELLO_CHILD_VERSION
	);

	// 가이드 엔진 JS
	wp_enqueue_script(
		'terra-guide-engine',
		HELLO_CHILD_URI . '/assets/js/terra-guide-engine.js',
		[],
		HELLO_CHILD_VERSION,
		true
	);

	// nonce 주입 (문자열로 명시적 전달)
	wp_add_inline_script(
		'terra-guide-engine',
		'var terraGuideNonce = ' . wp_json_encode( wp_create_nonce( 'wp_rest' ) ) . ';',
		'before'
	);

	// 상품 등록 페이지 가이드
	$screen = get_current_screen();
	if ( $screen && 'product' === $screen->post_type && in_array( $screen->base, array( 'post', 'post-new' ), true ) ) {
		wp_enqueue_script(
			'terra-guide-new-product',
			HELLO_CHILD_URI . '/assets/js/guide-new-product.js',
			array( 'terra-guide-engine' ),
			HELLO_CHILD_VERSION,
			true
		);
	}

}

/**
 * REST API — 가이드 dismiss 상태 저장
 */
add_action( 'rest_api_init', 'terra_guide_register_dismiss_rest' );
function terra_guide_register_dismiss_rest() {
	register_rest_route( 'terra-dashboard/v1', '/guide-dismiss', [
		'methods'             => 'POST',
		'callback'            => 'terra_guide_rest_dismiss',
		'permission_callback' => function () {
			return current_user_can( 'manage_options' );
		},
	] );
}

function terra_guide_rest_dismiss( $request ) {
	$data  = $request->get_json_params();
	$guide = sanitize_key( $data['guide'] ?? '' );

	if ( empty( $guide ) ) {
		return new WP_Error( 'missing_guide', '가이드 ID가 필요합니다.', [ 'status' => 400 ] );
	}

	$user_id   = get_current_user_id();
	$dismissed = get_user_meta( $user_id, 'terra_guide_dismissed', true );
	if ( ! is_array( $dismissed ) ) {
		$dismissed = [];
	}

	$dismissed[ $guide ] = true;
	update_user_meta( $user_id, 'terra_guide_dismissed', $dismissed );

	return rest_ensure_response( [ 'success' => true, 'guide' => $guide ] );
}

function terra_dashboard_rest_get_onboarding() {
	$progress = get_option( 'terra_onboarding_progress', [] );
	$detected = terra_dashboard_detect_onboarding();

	return rest_ensure_response( [
		'manual'   => $progress,
		'detected' => $detected,
	] );
}

function terra_dashboard_rest_update_onboarding( $request ) {
	$data     = $request->get_json_params();
	$progress = get_option( 'terra_onboarding_progress', [] );

	$allowed = [
		'payment', 'kakao', 'smart_noti', 'dismissed',
	];

	foreach ( $data as $key => $value ) {
		if ( in_array( $key, $allowed, true ) ) {
			$progress[ $key ] = (bool) $value;
		}
	}

	update_option( 'terra_onboarding_progress', $progress );

	// card_review 완료 시 PG 심사 모드 자동 해제
	if ( ! empty( $data['payment'] ) && terra_dashboard_is_pg_review_mode() ) {
		terra_dashboard_set_pg_review_mode( false );
	}

	return rest_ensure_response( [ 'success' => true, 'progress' => $progress ] );
}

/**
 * PG 심사 모드 — 메인 페이지를 pg-shop으로 전환/원복
 */
function terra_dashboard_is_pg_review_mode() {
	return (bool) get_option( 'terra_pg_review_mode', false );
}

function terra_dashboard_set_pg_review_mode( $enabled ) {
	if ( $enabled ) {
		// 현재 메인 페이지 ID 백업
		$current_front = get_option( 'page_on_front', 0 );
		if ( $current_front ) {
			update_option( 'terra_pg_review_original_front', $current_front, false );
		}
		// pg-shop 페이지를 메인으로
		$pg_shop = get_page_by_path( 'pg-shop' );
		if ( $pg_shop ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $pg_shop->ID );
		}
		update_option( 'terra_pg_review_mode', true, false );
	} else {
		// 원래 메인 페이지 복원
		$original = get_option( 'terra_pg_review_original_front', 0 );
		if ( $original ) {
			update_option( 'page_on_front', $original );
		}
		delete_option( 'terra_pg_review_mode' );
		delete_option( 'terra_pg_review_original_front' );
	}
}

function terra_dashboard_rest_toggle_pg_review( $request ) {
	$data    = $request->get_json_params();
	$enabled = ! empty( $data['enabled'] );

	terra_dashboard_set_pg_review_mode( $enabled );

	return rest_ensure_response( [
		'success' => true,
		'enabled' => terra_dashboard_is_pg_review_mode(),
	] );
}
