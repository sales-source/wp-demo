<?php
/**
 * 블로그 글 커스텀 메타박스
 *
 * - 핵심 답변 (Key Answer)
 * - 3줄 요약 (TL;DR)
 * - CTA 목록 (Call to Action)
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =============================================================================
   메타박스 등록
   ============================================================================= */

add_action( 'add_meta_boxes', 'hello_child_register_post_meta_boxes' );
function hello_child_register_post_meta_boxes() {
	// GEO 카테고리 글인지 확인 — GEO 글에는 3줄 요약만 표시
	$is_geo = false;
	$post_id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
	if ( $post_id ) {
		$is_geo = has_category( 'geo', $post_id );
	}

	if ( ! $is_geo ) {
		add_meta_box(
			'hello_child_key_answer',
			'핵심 답변',
			'hello_child_render_key_answer_box',
			'post',
			'normal',
			'high'
		);
	}

	add_meta_box(
		'hello_child_tldr',
		$is_geo ? '요약 (AI 인용 최적화)' : '3줄 요약',
		'hello_child_render_tldr_box',
		'post',
		'normal',
		'high'
	);

	if ( ! $is_geo ) {
		add_meta_box(
			'hello_child_glossary',
			'꼭 알아야 할 용어',
			'hello_child_render_glossary_box',
			'post',
			'normal',
			'default'
		);

		add_meta_box(
			'hello_child_cta',
			'CTA (Call to Action)',
			'hello_child_render_cta_box',
			'post',
			'normal',
			'default'
		);

		add_meta_box(
			'hello_child_sidebar_widget',
			'사이드바 홍보 위젯',
			'hello_child_render_sidebar_widget_box',
			'post',
			'side',
			'default'
		);
	}
}

/* =============================================================================
   관리자 스타일 로드
   ============================================================================= */

add_action( 'admin_enqueue_scripts', 'hello_child_admin_meta_box_styles' );
function hello_child_admin_meta_box_styles( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}

	global $post_type;

	// 공통 CSS (post + product 모두 사용)
	if ( in_array( $post_type, array( 'post', 'product' ), true ) ) {
		wp_enqueue_style(
			'hello-child-admin-meta-boxes',
			HELLO_CHILD_URI . '/assets/css/admin-meta-boxes.css',
			array(),
			HELLO_CHILD_VERSION
		);
	}

	// 블로그 글 전용
	if ( 'post' === $post_type ) {
		wp_enqueue_script(
			'hello-child-admin-cta',
			HELLO_CHILD_URI . '/assets/js/admin-cta.js',
			array(),
			HELLO_CHILD_VERSION,
			true
		);

		// 인터랙티브 온보딩 가이드 — 별도 JS 파일로 등록 (terra-guide-engine 의존)
		wp_enqueue_script(
			'terra-guide-blog-post',
			HELLO_CHILD_URI . '/assets/js/guide-blog-post.js',
			array( 'terra-guide-engine' ),
			HELLO_CHILD_VERSION,
			true
		);

	wp_enqueue_script(
		'hello-child-admin-glossary',
		HELLO_CHILD_URI . '/assets/js/admin-glossary.js',
		array(),
		HELLO_CHILD_VERSION,
		true
	);

	// 인터랙티브 온보딩 가이드
	wp_enqueue_style(
		'hello-child-admin-onboarding',
		HELLO_CHILD_URI . '/assets/css/admin-onboarding.css',
		array(),
		HELLO_CHILD_VERSION
	);
	wp_enqueue_script(
		'hello-child-admin-onboarding',
		HELLO_CHILD_URI . '/assets/js/admin-onboarding.js',
		array(),
		HELLO_CHILD_VERSION,
		true
	);

		// 미디어 업로더 (사이드바 위젯 썸네일용)
		wp_enqueue_media();
		wp_enqueue_script(
			'hello-child-admin-sidebar-widget',
			HELLO_CHILD_URI . '/assets/js/admin-sidebar-widget.js',
			array( 'jquery' ),
			HELLO_CHILD_VERSION,
			true
		);
	}

	// 상품 편집 전용
	if ( 'product' === $post_type ) {
		wp_enqueue_media();
		wp_enqueue_script(
			'hello-child-admin-product-meta',
			HELLO_CHILD_URI . '/assets/js/admin-product-meta.js',
			array(),
			HELLO_CHILD_VERSION,
			true
		);
	}
}

/* =============================================================================
   핵심 답변 렌더링
   ============================================================================= */

function hello_child_render_key_answer_box( $post ) {
	wp_nonce_field( 'hello_child_save_meta', 'hello_child_meta_nonce' );
	$value = get_post_meta( $post->ID, '_hello_child_key_answer', true );
	?>
	<p class="hello-child-meta-desc">이 글의 핵심을 1~2문장으로 요약하세요. 글 상단에 강조 박스로 자동 표시됩니다.</p>
	<textarea name="hello_child_key_answer" rows="3" class="hello-child-meta-textarea"><?php echo esc_textarea( $value ); ?></textarea>
	<?php
}

/* =============================================================================
   3줄 요약 렌더링
   ============================================================================= */

function hello_child_render_tldr_box( $post ) {
	$lines = get_post_meta( $post->ID, '_hello_child_tldr', true );
	$lines = is_array( $lines ) ? $lines : array( '', '', '' );
	?>
	<p class="hello-child-meta-desc">핵심 포인트 3가지를 입력하세요. 목차 위에 요약 카드로 자동 표시됩니다.</p>
	<?php for ( $i = 0; $i < 3; $i++ ) : ?>
		<div class="hello-child-tldr-row">
			<span class="hello-child-tldr-num"><?php echo $i + 1; ?></span>
			<input type="text" name="hello_child_tldr[]" value="<?php echo esc_attr( $lines[ $i ] ?? '' ); ?>" class="hello-child-meta-input" placeholder="핵심 포인트 <?php echo $i + 1; ?>">
		</div>
	<?php endfor; ?>
	<?php
}

/* =============================================================================
   용어 정리 렌더링
   ============================================================================= */

function hello_child_render_glossary_box( $post ) {
	$terms = get_post_meta( $post->ID, '_hello_child_glossary', true );
	$terms = is_array( $terms ) ? $terms : array( array( 'term' => '', 'definition' => '', 'easy' => '' ) );
	?>
	<p class="hello-child-meta-desc">글에 사용된 전문 용어를 쉽게 설명해주세요. 본문 하단에 용어 정리 박스로 자동 표시됩니다.</p>
	<div id="hello-child-glossary-list">
		<?php foreach ( $terms as $i => $item ) : ?>
			<div class="hello-child-glossary-row" data-index="<?php echo $i; ?>">
				<div class="hello-child-glossary-header">
					<span class="hello-child-glossary-num"><?php echo $i + 1; ?></span>
					<input type="text" name="hello_child_glossary[<?php echo $i; ?>][term]" value="<?php echo esc_attr( $item['term'] ?? '' ); ?>" class="hello-child-meta-input hello-child-glossary-term" placeholder="용어 (예: 차일드 테마)">
					<button type="button" class="hello-child-glossary-remove" title="삭제">&times;</button>
				</div>
				<textarea name="hello_child_glossary[<?php echo $i; ?>][definition]" rows="2" class="hello-child-meta-textarea hello-child-glossary-def" placeholder="정의 (예: 부모 테마를 상속받아 커스터마이징할 수 있는 하위 테마)"><?php echo esc_textarea( $item['definition'] ?? '' ); ?></textarea>
				<input type="text" name="hello_child_glossary[<?php echo $i; ?>][easy]" value="<?php echo esc_attr( $item['easy'] ?? '' ); ?>" class="hello-child-meta-input hello-child-glossary-easy" placeholder="쉽게 말하면 (예: 원본은 그대로 두고 복사본에서 수정하는 것)">
			</div>
		<?php endforeach; ?>
	</div>
	<button type="button" id="hello-child-glossary-add" class="button">+ 용어 추가</button>
	<?php
}

/* =============================================================================
   CTA 렌더링
   ============================================================================= */

function hello_child_render_cta_box( $post ) {
	$ctas = get_post_meta( $post->ID, '_hello_child_cta', true );
	$ctas = is_array( $ctas ) ? $ctas : array( array( 'text' => '', 'url' => '' ) );
	?>
	<p class="hello-child-meta-desc">CTA 설명과 URL을 입력하세요. 프론트에서는 설명 옆에 "바로가기" 버튼으로 표시됩니다.</p>
	<div id="hello-child-cta-list">
		<?php foreach ( $ctas as $i => $cta ) : ?>
			<div class="hello-child-cta-row" data-index="<?php echo $i; ?>">
				<input type="text" name="hello_child_cta[<?php echo $i; ?>][text]" value="<?php echo esc_attr( $cta['text'] ?? '' ); ?>" class="hello-child-meta-input hello-child-cta-text" placeholder="CTA 설명 (예: 무료 상담 신청하기)">
				<input type="url" name="hello_child_cta[<?php echo $i; ?>][url]" value="<?php echo esc_url( $cta['url'] ?? '' ); ?>" class="hello-child-meta-input hello-child-cta-url" placeholder="URL (예: https://example.com)">
				<button type="button" class="hello-child-cta-remove" title="삭제">&times;</button>
			</div>
		<?php endforeach; ?>
	</div>
	<button type="button" id="hello-child-cta-add" class="button">+ CTA 추가</button>
	<?php
}

/* =============================================================================
   사이드바 홍보 위젯 렌더링
   ============================================================================= */

function hello_child_render_sidebar_widget_box( $post ) {
	// 글로벌 설정 가져오기
	$global  = get_option( 'hello_child_global_sidebar_widget', array() );
	$is_global = ! empty( $global['enabled'] );

	// 개별 글 설정
	$widget = get_post_meta( $post->ID, '_hello_child_sidebar_widget', true );
	$widget = is_array( $widget ) ? $widget : array();

	// 글로벌이 활성화되어 있고 개별 설정이 없으면 글로벌 값 표시
	$use_global = $is_global && empty( $widget['title'] );
	$display = $use_global ? $global : $widget;

	$thumb_id  = $display['thumb_id'] ?? '';
	$thumb_url = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium' ) : '';
	$title     = $display['title'] ?? '';
	$url       = $display['url'] ?? '';
	?>
	<div class="hello-child-sidebar-widget-fields">
		<p class="hello-child-meta-desc">우측 사이드바에 표시될 홍보 위젯입니다.</p>

		<div class="hello-child-sw-thumb-wrap">
			<div id="hello-child-sw-preview" style="<?php echo $thumb_url ? '' : 'display:none;'; ?>">
				<img src="<?php echo esc_url( $thumb_url ); ?>" style="max-width:100%;border-radius:4px;">
			</div>
			<input type="hidden" name="hello_child_sw_thumb_id" id="hello-child-sw-thumb-id" value="<?php echo esc_attr( $thumb_id ); ?>">
			<p>
				<button type="button" id="hello-child-sw-upload" class="button">썸네일 선택</button>
				<button type="button" id="hello-child-sw-remove" class="button" style="<?php echo $thumb_url ? '' : 'display:none;'; ?>">제거</button>
			</p>
		</div>

		<p>
			<label><strong>제목</strong></label><br>
			<input type="text" name="hello_child_sw_title" value="<?php echo esc_attr( $title ); ?>" class="hello-child-meta-input" placeholder="예: 무료 전자책 다운로드">
		</p>

		<p>
			<label><strong>링크 URL</strong></label><br>
			<input type="url" name="hello_child_sw_url" value="<?php echo esc_url( $url ); ?>" class="hello-child-meta-input" placeholder="https://example.com">
		</p>

		<hr style="margin:12px 0;">

		<p>
			<label>
				<input type="checkbox" name="hello_child_sw_global" value="1" <?php checked( $is_global ); ?>>
				<strong>모든 글에 적용</strong>
			</label>
		</p>
		<p class="hello-child-meta-desc" style="margin-top:0;">
			체크하면 이 위젯 설정이 모든 블로그 글에 동일하게 표시됩니다.
		</p>
	</div>
	<?php
}

/**
 * 사이드바 위젯에 사용할 데이터를 가져오는 헬퍼 함수
 * (개별 글 설정 우선, 없으면 글로벌 설정 사용)
 */
function hello_child_get_sidebar_widget( $post_id ) {
	// 개별 글 설정 확인
	$widget = get_post_meta( $post_id, '_hello_child_sidebar_widget', true );
	if ( is_array( $widget ) && ! empty( $widget['title'] ) ) {
		return $widget;
	}

	// 글로벌 설정 확인
	$global = get_option( 'hello_child_global_sidebar_widget', array() );
	if ( ! empty( $global['enabled'] ) && ! empty( $global['title'] ) ) {
		return $global;
	}

	return array();
}

/* =============================================================================
   메타 저장
   ============================================================================= */

add_action( 'save_post_post', 'hello_child_save_post_meta' );
function hello_child_save_post_meta( $post_id ) {
	if ( ! isset( $_POST['hello_child_meta_nonce'] ) ||
		! wp_verify_nonce( $_POST['hello_child_meta_nonce'], 'hello_child_save_meta' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	// 핵심 답변
	if ( isset( $_POST['hello_child_key_answer'] ) ) {
		update_post_meta( $post_id, '_hello_child_key_answer',
			sanitize_textarea_field( $_POST['hello_child_key_answer'] ) );
	}

	// 3줄 요약
	if ( isset( $_POST['hello_child_tldr'] ) && is_array( $_POST['hello_child_tldr'] ) ) {
		$tldr = array_map( 'sanitize_text_field', $_POST['hello_child_tldr'] );
		update_post_meta( $post_id, '_hello_child_tldr', array_slice( $tldr, 0, 3 ) );
	}

	// 용어 정리
	if ( isset( $_POST['hello_child_glossary'] ) && is_array( $_POST['hello_child_glossary'] ) ) {
		$glossary = array();
		foreach ( $_POST['hello_child_glossary'] as $item ) {
			$term       = sanitize_text_field( $item['term'] ?? '' );
			$definition = sanitize_textarea_field( $item['definition'] ?? '' );
			$easy       = sanitize_text_field( $item['easy'] ?? '' );
			if ( $term || $definition ) {
				$glossary[] = array( 'term' => $term, 'definition' => $definition, 'easy' => $easy );
			}
		}
		update_post_meta( $post_id, '_hello_child_glossary', $glossary );
	}

	// CTA
	if ( isset( $_POST['hello_child_cta'] ) && is_array( $_POST['hello_child_cta'] ) ) {
		$ctas = array();
		foreach ( $_POST['hello_child_cta'] as $cta ) {
			$text = sanitize_text_field( $cta['text'] ?? '' );
			$url  = esc_url_raw( $cta['url'] ?? '' );
			if ( $text || $url ) {
				$ctas[] = array( 'text' => $text, 'url' => $url );
			}
		}
		update_post_meta( $post_id, '_hello_child_cta', $ctas );
	}

	// 사이드바 홍보 위젯
	$sw_data = array(
		'thumb_id' => absint( $_POST['hello_child_sw_thumb_id'] ?? 0 ),
		'title'    => sanitize_text_field( $_POST['hello_child_sw_title'] ?? '' ),
		'url'      => esc_url_raw( $_POST['hello_child_sw_url'] ?? '' ),
	);

	// 개별 글 메타로 저장
	if ( $sw_data['title'] ) {
		update_post_meta( $post_id, '_hello_child_sidebar_widget', $sw_data );
	} else {
		delete_post_meta( $post_id, '_hello_child_sidebar_widget' );
	}

	// "모든 글에 적용" 체크 시 글로벌 옵션으로도 저장
	if ( ! empty( $_POST['hello_child_sw_global'] ) ) {
		$sw_data['enabled'] = true;
		update_option( 'hello_child_global_sidebar_widget', $sw_data, false );
	} else {
		$global = get_option( 'hello_child_global_sidebar_widget', array() );
		if ( ! empty( $global['enabled'] ) ) {
			$global['enabled'] = false;
			update_option( 'hello_child_global_sidebar_widget', $global, false );
		}
	}
}

/* =============================================================================
   상품(Product) 메타박스 등록
   ============================================================================= */

add_action( 'add_meta_boxes', 'hello_child_register_product_meta_boxes' );
function hello_child_register_product_meta_boxes() {
	// freepdf 카테고리 상품은 배송/서비스/환불 메타박스 불필요
	$post_id    = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
	$is_freepdf = $post_id && has_term( 'freepdf', 'product_cat', $post_id );

	if ( ! $is_freepdf ) {
		add_meta_box(
			'hello_child_shipping_info',
			'배송 / 서비스 정보',
			'hello_child_render_shipping_box',
			'product',
			'normal',
			'high'
		);
	} else {
		// freepdf 전용: 배송/서비스/환불 필요 없음 안내
		add_meta_box(
			'hello_child_shipping_info',
			'배송 / 서비스 정보',
			function() { echo '<p style="color:#888;">무료 PDF 상품은 배송/서비스/환불 규정이 표시되지 않습니다.</p>'; },
			'product',
			'normal',
			'high'
		);
	}

	add_meta_box(
		'hello_child_product_why',
		$is_freepdf ? '왜 이 콘텐츠인가요?' : '왜 이 강의인가요?',
		'hello_child_render_why_box',
		'product',
		'normal',
		'high'
	);

	add_meta_box(
		'hello_child_product_benefits',
		$is_freepdf ? 'WHAT YOU GET (포함 내용)' : 'WHAT YOU GET (제공 혜택)',
		'hello_child_render_benefits_box',
		'product',
		'normal',
		'high'
	);

	add_meta_box(
		'hello_child_product_target',
		$is_freepdf ? '이런 분들을 위한 콘텐츠입니다' : '누구를 위한 강의인가',
		'hello_child_render_target_box',
		'product',
		'normal',
		'default'
	);

	add_meta_box(
		'hello_child_product_curriculum',
		$is_freepdf ? '목차' : '커리큘럼',
		'hello_child_render_curriculum_box',
		'product',
		'normal',
		'default'
	);

	add_meta_box(
		'hello_child_product_instructor',
		$is_freepdf ? '저자 소개' : '강사 소개',
		'hello_child_render_instructor_box',
		'product',
		'normal',
		'default'
	);

	add_meta_box(
		'hello_child_product_faq',
		'FAQ (자주 묻는 질문)',
		'hello_child_render_faq_box',
		'product',
		'normal',
		'default'
	);
}

/* =============================================================================
   배송 / 서비스 정보 메타박스 (virtual 토글)
   ============================================================================= */

function hello_child_render_shipping_box( $post ) {
	wp_nonce_field( 'hello_child_save_product_meta', 'hello_child_product_meta_nonce' );

	$shipping_cost    = get_post_meta( $post->ID, '_sp_shipping_cost', true );
	$shipping_period  = get_post_meta( $post->ID, '_sp_shipping_period', true );
	$refund_policy    = get_post_meta( $post->ID, '_sp_refund_policy', true );
	$service_period   = get_post_meta( $post->ID, '_sp_service_period', true );
	?>
	<p class="hello-child-meta-desc">비워두면 기본값이 자동 표시됩니다. 가상 상품 체크 시 배송 필드가 숨겨지고 서비스 필드가 표시됩니다.</p>

	<!-- 실물 상품 필드 -->
	<div id="sp-shipping-physical-fields">
		<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:8px 0 16px;">
			<div>
				<label for="sp_shipping_cost" style="display:block;font-weight:600;margin-bottom:4px;">배송비</label>
				<input type="text" id="sp_shipping_cost" name="sp_shipping_cost" value="<?php echo esc_attr( $shipping_cost ); ?>" style="width:100%;" placeholder="무료배송">
			</div>
			<div>
				<label for="sp_shipping_period" style="display:block;font-weight:600;margin-bottom:4px;">배송 기간</label>
				<input type="text" id="sp_shipping_period" name="sp_shipping_period" value="<?php echo esc_attr( $shipping_period ); ?>" style="width:100%;" placeholder="결제 후 2~5일 이내 출고">
			</div>
		</div>
	</div>

	<!-- 가상 상품 필드 -->
	<div id="sp-shipping-virtual-fields" style="display:none;">
		<div style="margin:8px 0 16px;">
			<label for="sp_service_period" style="display:block;font-weight:600;margin-bottom:4px;">수강 기간</label>
			<input type="text" id="sp_service_period" name="sp_service_period" value="<?php echo esc_attr( $service_period ); ?>" style="width:100%;" placeholder="결제 즉시 이용 가능 / 영구 수강">
		</div>
	</div>

	<!-- 공통: 환불 규정 -->
	<div>
		<label for="sp_refund_policy" style="display:block;font-weight:600;margin-bottom:4px;">환불 규정</label>
		<textarea id="sp_refund_policy" name="sp_refund_policy" rows="5" class="large-text" placeholder="수령 후 7일 이내 교환/반품 가능&#10;제품 하자 시 배송비 판매자 부담&#10;단순 변심 시 왕복 배송비 구매자 부담&#10;사용 흔적이 있는 경우 반품 불가"><?php echo esc_textarea( $refund_policy ); ?></textarea>
		<p class="description">한 줄에 하나씩 입력하세요. 각 줄이 개별 항목으로 표시됩니다.</p>
	</div>
	<?php
}

/* =============================================================================
   왜 이 강의인가요? (제목 + 본문)
   ============================================================================= */

function hello_child_render_why_box( $post ) {
	$why = get_post_meta( $post->ID, '_sp_why', true );
	$why = is_array( $why ) ? $why : array( 'title' => '', 'body' => '' );
	?>
	<p class="hello-child-meta-desc">제목은 굵게, 본문은 연한 색으로 표시됩니다. 벤치마크: "결과물이 나오는 순서로 가르칩니다."</p>
	<div style="margin:8px 0;">
		<label style="display:block;font-weight:600;margin-bottom:4px;">제목 (한 줄)</label>
		<input type="text" name="sp_why[title]" value="<?php echo esc_attr( $why['title'] ); ?>" class="hello-child-meta-input" placeholder="예: 결과물이 나오는 순서로 가르칩니다.">
	</div>
	<div style="margin:8px 0;">
		<label style="display:block;font-weight:600;margin-bottom:4px;">본문</label>
		<textarea name="sp_why[body]" rows="4" class="hello-child-meta-textarea" placeholder="왜 이 강의가 다른지 설명하세요."><?php echo esc_textarea( $why['body'] ?? '' ); ?></textarea>
	</div>
	<?php
}

/* =============================================================================
   WHAT YOU GET — 제공 혜택 (아이콘 + 제목 + 설명 리피터)
   ============================================================================= */

function hello_child_render_benefits_box( $post ) {
	$benefits = get_post_meta( $post->ID, '_sp_benefits', true );
	$benefits = is_array( $benefits ) ? $benefits : array( array( 'icon' => 'play-circle', 'title' => '', 'desc' => '' ) );

	$icon_options = array(
		'play-circle'  => 'VOD / 영상',
		'check-square' => '체크리스트',
		'award'        => '수료증 / 인증',
		'gift'         => '선물 / 보너스',
		'message-circle' => 'Q&A / 커뮤니티',
		'users'        => '커뮤니티 / 그룹',
		'file-text'    => '템플릿 / 문서',
		'book-open'    => '워크북 / 교재',
		'zap'          => '자동화 / 효율',
		'trending-up'  => '성장 / 스케일',
		'video'        => '라이브 / 화상',
		'headphones'   => '1:1 상담',
	);
	?>
	<p class="hello-child-meta-desc">아이콘 + 제목 + 설명. 프론트에서 2x3 그리드로 표시됩니다.</p>
	<div id="sp-benefits-list">
		<?php foreach ( $benefits as $i => $item ) : ?>
			<div class="sp-benefit-row" data-index="<?php echo $i; ?>">
				<select name="sp_benefits[<?php echo $i; ?>][icon]" style="width:140px;">
					<?php foreach ( $icon_options as $val => $label ) : ?>
						<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $item['icon'] ?? '', $val ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<input type="text" name="sp_benefits[<?php echo $i; ?>][title]" value="<?php echo esc_attr( $item['title'] ?? '' ); ?>" class="hello-child-meta-input" placeholder="제목 (예: VOD 강의 32강)" style="flex:1;">
				<input type="text" name="sp_benefits[<?php echo $i; ?>][desc]" value="<?php echo esc_attr( $item['desc'] ?? '' ); ?>" class="hello-child-meta-input" placeholder="설명" style="flex:2;">
				<button type="button" class="hello-child-cta-remove sp-benefit-remove" title="삭제">&times;</button>
			</div>
		<?php endforeach; ?>
	</div>
	<button type="button" class="button" id="sp-benefit-add" style="margin-top:4px;">+ 혜택 추가</button>
	<?php
}

/* =============================================================================
   누구를 위한 강의인가 (4칼럼: 이미지 + 텍스트)
   ============================================================================= */

function hello_child_render_target_box( $post ) {
	$targets = get_post_meta( $post->ID, '_sp_targets', true );
	$targets = is_array( $targets ) ? $targets : array();

	// 기본 4개 슬롯 보장
	while ( count( $targets ) < 4 ) {
		$targets[] = array( 'img_id' => '', 'text' => '' );
	}
	?>
	<p class="hello-child-meta-desc">대상 고객 4명을 이미지와 텍스트로 입력하세요. 프론트에서 4칼럼 그리드로 표시됩니다.</p>
	<div class="sp-target-grid">
		<?php foreach ( $targets as $i => $item ) :
			$img_url = ! empty( $item['img_id'] ) ? wp_get_attachment_image_url( $item['img_id'], 'medium' ) : '';
		?>
			<div class="sp-target-card">
				<div class="sp-target-card__preview" id="sp-target-preview-<?php echo $i; ?>" style="<?php echo $img_url ? '' : 'display:none;'; ?>">
					<img src="<?php echo esc_url( $img_url ); ?>" style="max-width:100%;border-radius:8px;">
				</div>
				<input type="hidden" name="sp_targets[<?php echo $i; ?>][img_id]" id="sp-target-img-<?php echo $i; ?>" value="<?php echo esc_attr( $item['img_id'] ); ?>">
				<p style="margin:8px 0 4px;">
					<button type="button" class="button sp-target-upload" data-index="<?php echo $i; ?>">이미지 선택</button>
					<button type="button" class="button sp-target-remove" data-index="<?php echo $i; ?>" style="<?php echo $img_url ? '' : 'display:none;'; ?>">제거</button>
				</p>
				<input type="text" name="sp_targets[<?php echo $i; ?>][text]" value="<?php echo esc_attr( $item['text'] ?? '' ); ?>" class="hello-child-meta-input" placeholder="예: AI 영상 제작이 처음인 분" style="margin-top:4px;">
			</div>
		<?php endforeach; ?>
	</div>
	<?php
}

/* =============================================================================
   커리큘럼 (섹션 + 항목 리피터, 자동 번호)
   ============================================================================= */

function hello_child_render_curriculum_box( $post ) {
	$sections = get_post_meta( $post->ID, '_sp_curriculum', true );
	$sections = is_array( $sections ) ? $sections : array( array( 'title' => '', 'items' => array( array( 'title' => '', 'desc' => '' ) ) ) );
	?>
	<p class="hello-child-meta-desc">섹션 제목과 각 강의를 입력하세요. 강의 번호는 전체에서 자동으로 매겨집니다.</p>
	<div id="sp-curriculum-list">
		<?php foreach ( $sections as $si => $section ) : ?>
			<div class="sp-curriculum-section" data-section="<?php echo $si; ?>">
				<div class="sp-curriculum-section__header">
					<strong>섹션 <?php echo $si + 1; ?></strong>
					<button type="button" class="button sp-curriculum-remove-section" title="섹션 삭제">&times;</button>
				</div>
				<input type="text" name="sp_curriculum[<?php echo $si; ?>][title]" value="<?php echo esc_attr( $section['title'] ?? '' ); ?>" class="hello-child-meta-input" placeholder="섹션 제목 (예: AI 영상 제작의 전체 구조 이해)" style="margin-bottom:8px;">
				<div class="sp-curriculum-items" data-section="<?php echo $si; ?>">
					<?php
					$items = isset( $section['items'] ) && is_array( $section['items'] ) ? $section['items'] : array( array( 'title' => '', 'desc' => '' ) );
					foreach ( $items as $ii => $item ) : ?>
						<div class="sp-curriculum-item">
							<span class="sp-curriculum-item__num"></span>
							<input type="text" name="sp_curriculum[<?php echo $si; ?>][items][<?php echo $ii; ?>][title]" value="<?php echo esc_attr( $item['title'] ?? '' ); ?>" class="hello-child-meta-input" placeholder="강의 제목" style="flex:1;">
							<input type="text" name="sp_curriculum[<?php echo $si; ?>][items][<?php echo $ii; ?>][desc]" value="<?php echo esc_attr( $item['desc'] ?? '' ); ?>" class="hello-child-meta-input" placeholder="설명 (선택)" style="flex:1;">
							<button type="button" class="hello-child-cta-remove sp-curriculum-remove-item" title="삭제">&times;</button>
						</div>
					<?php endforeach; ?>
				</div>
				<button type="button" class="button sp-curriculum-add-item" data-section="<?php echo $si; ?>">+ 강의 추가</button>
			</div>
		<?php endforeach; ?>
	</div>
	<button type="button" class="button button-primary" id="sp-curriculum-add-section" style="margin-top:8px;">+ 섹션 추가</button>
	<?php
}

/* =============================================================================
   강사 소개 (사진 + 이름 + 직함 + 소개 + 태그)
   ============================================================================= */

function hello_child_render_instructor_box( $post ) {
	$instructor = get_post_meta( $post->ID, '_sp_instructor', true );
	$instructor = is_array( $instructor ) ? $instructor : array();

	$photo_id  = $instructor['photo_id'] ?? '';
	$photo_url = $photo_id ? wp_get_attachment_image_url( $photo_id, 'medium' ) : '';
	$name      = $instructor['name'] ?? '';
	$title     = $instructor['title'] ?? '';
	$bio       = $instructor['bio'] ?? '';
	$tags      = $instructor['tags'] ?? '';
	?>
	<p class="hello-child-meta-desc">강사 프로필을 입력하세요. 프론트에서 강사 소개 섹션으로 표시됩니다.</p>

	<div style="display:grid;grid-template-columns:200px 1fr;gap:20px;margin:8px 0;">
		<div>
			<div id="sp-instructor-preview" style="<?php echo $photo_url ? '' : 'display:none;'; ?>">
				<img src="<?php echo esc_url( $photo_url ); ?>" style="max-width:100%;border-radius:8px;">
			</div>
			<input type="hidden" name="sp_instructor[photo_id]" id="sp-instructor-photo-id" value="<?php echo esc_attr( $photo_id ); ?>">
			<p style="margin:8px 0 0;">
				<button type="button" class="button" id="sp-instructor-upload">사진 선택</button>
				<button type="button" class="button" id="sp-instructor-remove" style="<?php echo $photo_url ? '' : 'display:none;'; ?>">제거</button>
			</p>
		</div>
		<div>
			<p style="margin:0 0 8px;">
				<label style="display:block;font-weight:600;margin-bottom:4px;">이름</label>
				<input type="text" name="sp_instructor[name]" value="<?php echo esc_attr( $name ); ?>" class="hello-child-meta-input" placeholder="예: 김미현">
			</p>
			<p style="margin:0 0 8px;">
				<label style="display:block;font-weight:600;margin-bottom:4px;">직함</label>
				<input type="text" name="sp_instructor[title]" value="<?php echo esc_attr( $title ); ?>" class="hello-child-meta-input" placeholder="예: 대표 강사 · AI 영상 제작 전문가">
			</p>
			<p style="margin:0 0 8px;">
				<label style="display:block;font-weight:600;margin-bottom:4px;">소개글</label>
				<textarea name="sp_instructor[bio]" rows="4" class="hello-child-meta-textarea" placeholder="강사 소개를 입력하세요."><?php echo esc_textarea( $bio ); ?></textarea>
			</p>
			<p style="margin:0;">
				<label style="display:block;font-weight:600;margin-bottom:4px;">태그 (쉼표 구분)</label>
				<input type="text" name="sp_instructor[tags]" value="<?php echo esc_attr( $tags ); ?>" class="hello-child-meta-input" placeholder="AI 영상 제작, 유튜브 채널 전략, 수강생 000명+">
			</p>
		</div>
	</div>
	<?php
}

/* =============================================================================
   FAQ (질문 + 답변 리피터)
   ============================================================================= */

function hello_child_render_faq_box( $post ) {
	$faqs = get_post_meta( $post->ID, '_sp_faq', true );
	$faqs = is_array( $faqs ) ? $faqs : array( array( 'q' => '', 'a' => '' ) );
	?>
	<p class="hello-child-meta-desc">자주 묻는 질문과 답변을 입력하세요. 프론트에서 아코디언으로 표시됩니다.</p>
	<div id="sp-faq-list">
		<?php foreach ( $faqs as $i => $faq ) : ?>
			<div class="sp-faq-row" data-index="<?php echo $i; ?>">
				<input type="text" name="sp_faq[<?php echo $i; ?>][q]" value="<?php echo esc_attr( $faq['q'] ?? '' ); ?>" class="hello-child-meta-input" placeholder="질문" style="margin-bottom:4px;">
				<textarea name="sp_faq[<?php echo $i; ?>][a]" rows="2" class="hello-child-meta-textarea" placeholder="답변"><?php echo esc_textarea( $faq['a'] ?? '' ); ?></textarea>
				<button type="button" class="hello-child-cta-remove sp-faq-remove" title="삭제" style="position:absolute;top:8px;right:8px;">&times;</button>
			</div>
		<?php endforeach; ?>
	</div>
	<button type="button" class="button" id="sp-faq-add" style="margin-top:4px;">+ FAQ 추가</button>
	<?php
}

/* =============================================================================
   상품 메타 저장
   ============================================================================= */

add_action( 'save_post_product', 'hello_child_save_product_meta' );
function hello_child_save_product_meta( $post_id ) {
	if ( ! isset( $_POST['hello_child_product_meta_nonce'] ) ||
		! wp_verify_nonce( $_POST['hello_child_product_meta_nonce'], 'hello_child_save_product_meta' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	// 배송 필드 (실물)
	$text_fields = array( 'sp_shipping_cost', 'sp_shipping_period', 'sp_service_period' );
	foreach ( $text_fields as $field ) {
		if ( isset( $_POST[ $field ] ) ) {
			$value = sanitize_text_field( $_POST[ $field ] );
			if ( $value ) {
				update_post_meta( $post_id, '_' . $field, $value );
			} else {
				delete_post_meta( $post_id, '_' . $field );
			}
		}
	}

	// 환불 규정
	if ( isset( $_POST['sp_refund_policy'] ) ) {
		$value = sanitize_textarea_field( $_POST['sp_refund_policy'] );
		if ( $value ) {
			update_post_meta( $post_id, '_sp_refund_policy', $value );
		} else {
			delete_post_meta( $post_id, '_sp_refund_policy' );
		}
	}

	// 왜 이 강의인가요?
	if ( isset( $_POST['sp_why'] ) && is_array( $_POST['sp_why'] ) ) {
		$why = array(
			'title' => sanitize_text_field( $_POST['sp_why']['title'] ?? '' ),
			'body'  => sanitize_textarea_field( $_POST['sp_why']['body'] ?? '' ),
		);
		update_post_meta( $post_id, '_sp_why', $why );
	}

	// WHAT YOU GET
	if ( isset( $_POST['sp_benefits'] ) && is_array( $_POST['sp_benefits'] ) ) {
		$benefits = array();
		foreach ( $_POST['sp_benefits'] as $item ) {
			$t = sanitize_text_field( $item['title'] ?? '' );
			$d = sanitize_text_field( $item['desc'] ?? '' );
			$ic = sanitize_text_field( $item['icon'] ?? 'play-circle' );
			if ( $t ) {
				$benefits[] = array( 'icon' => $ic, 'title' => $t, 'desc' => $d );
			}
		}
		update_post_meta( $post_id, '_sp_benefits', $benefits );
	}

	// 누구를 위한 강의인가
	if ( isset( $_POST['sp_targets'] ) && is_array( $_POST['sp_targets'] ) ) {
		$targets = array();
		foreach ( $_POST['sp_targets'] as $item ) {
			$targets[] = array(
				'img_id' => absint( $item['img_id'] ?? 0 ),
				'text'   => sanitize_text_field( $item['text'] ?? '' ),
			);
		}
		update_post_meta( $post_id, '_sp_targets', $targets );
	}

	// 커리큘럼
	if ( isset( $_POST['sp_curriculum'] ) && is_array( $_POST['sp_curriculum'] ) ) {
		$sections = array();
		foreach ( $_POST['sp_curriculum'] as $section ) {
			$items = array();
			if ( isset( $section['items'] ) && is_array( $section['items'] ) ) {
				foreach ( $section['items'] as $item ) {
					$t = sanitize_text_field( $item['title'] ?? '' );
					$d = sanitize_text_field( $item['desc'] ?? '' );
					if ( $t || $d ) {
						$items[] = array( 'title' => $t, 'desc' => $d );
					}
				}
			}
			$sections[] = array(
				'title' => sanitize_text_field( $section['title'] ?? '' ),
				'items' => $items,
			);
		}
		update_post_meta( $post_id, '_sp_curriculum', $sections );
	}

	// 강사 소개
	if ( isset( $_POST['sp_instructor'] ) && is_array( $_POST['sp_instructor'] ) ) {
		$inst = $_POST['sp_instructor'];
		$data = array(
			'photo_id' => absint( $inst['photo_id'] ?? 0 ),
			'name'     => sanitize_text_field( $inst['name'] ?? '' ),
			'title'    => sanitize_text_field( $inst['title'] ?? '' ),
			'bio'      => sanitize_textarea_field( $inst['bio'] ?? '' ),
			'tags'     => sanitize_text_field( $inst['tags'] ?? '' ),
		);
		update_post_meta( $post_id, '_sp_instructor', $data );
	}

	// FAQ
	if ( isset( $_POST['sp_faq'] ) && is_array( $_POST['sp_faq'] ) ) {
		$faqs = array();
		foreach ( $_POST['sp_faq'] as $faq ) {
			$q = sanitize_text_field( $faq['q'] ?? '' );
			$a = sanitize_textarea_field( $faq['a'] ?? '' );
			if ( $q || $a ) {
				$faqs[] = array( 'q' => $q, 'a' => $a );
			}
		}
		update_post_meta( $post_id, '_sp_faq', $faqs );
	}
}

/* =============================================================================
   샘플 블로그 글 자동 생성 — auto-content.php로 이전됨
   ============================================================================= */
