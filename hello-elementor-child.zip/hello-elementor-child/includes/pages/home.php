<?php
/**
 * Home 페이지 — Elementor 데이터
 *
 * 테마 활성화 시 자동 생성되는 메인 페이지.
 * 지식 창업자 누구에게나 직관적으로 이해되는 데모 콘텐츠.
 *
 * 구조:
 *   Hero → Social Proof → 인기 강의 → 무료 리소스 → 다가오는 일정
 *   → 커뮤니티 → 블로그 → FAQ → Final CTA
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ─────────────────────────────────────────────
// 헬퍼 함수
// ─────────────────────────────────────────────

if ( ! function_exists( '_hec_id' ) ) {
	function _hec_id() {
		return substr( md5( uniqid( mt_rand(), true ) ), 0, 8 );
	}
}

if ( ! function_exists( '_hec_heading' ) ) {
	function _hec_heading( $text, $settings = [] ) {
		return [
			'id'         => _hec_id(),
			'elType'     => 'widget',
			'widgetType' => 'heading',
			'settings'   => array_merge( [
				'title' => $text,
				'align' => 'center',
			], $settings ),
			'elements'   => [],
			'isInner'    => false,
		];
	}
}

if ( ! function_exists( '_hec_button' ) ) {
	function _hec_button( $text, $link = '#', $settings = [] ) {
		return [
			'id'         => _hec_id(),
			'elType'     => 'widget',
			'widgetType' => 'button',
			'settings'   => array_merge( [
				'text'          => $text,
				'align'         => 'center',
				'link'          => [ 'url' => $link, 'is_external' => false, 'nofollow' => false ],
				'button_type'   => 'default',
				'size'          => 'lg',
				'border_radius' => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
			], $settings ),
			'elements'   => [],
			'isInner'    => false,
		];
	}
}

if ( ! function_exists( '_hec_icon_box' ) ) {
	function _hec_icon_box( $title, $description = '', $icon = 'fas fa-check-circle', $settings = [] ) {
		return [
			'id'         => _hec_id(),
			'elType'     => 'widget',
			'widgetType' => 'icon-box',
			'settings'   => array_merge( [
				'title_text'       => $title,
				'description_text' => $description,
				'selected_icon'    => [ 'value' => $icon, 'library' => 'fa-solid' ],
				'position'         => 'top',
				'title_size'       => 'h4',
			], $settings ),
			'elements'   => [],
			'isInner'    => false,
		];
	}
}

if ( ! function_exists( '_hec_text_editor' ) ) {
	function _hec_text_editor( $html, $settings = [] ) {
		return [
			'id'         => _hec_id(),
			'elType'     => 'widget',
			'widgetType' => 'text-editor',
			'settings'   => array_merge( [
				'editor' => $html,
			], $settings ),
			'elements'   => [],
			'isInner'    => false,
		];
	}
}

if ( ! function_exists( '_hec_accordion' ) ) {
	function _hec_accordion( $items, $settings = [] ) {
		$tabs = [];
		foreach ( $items as $item ) {
			$tabs[] = [
				'tab_title'   => $item['q'],
				'tab_content' => $item['a'],
			];
		}
		return [
			'id'         => _hec_id(),
			'elType'     => 'widget',
			'widgetType' => 'accordion',
			'settings'   => array_merge( [
				'tabs' => $tabs,
			], $settings ),
			'elements'   => [],
			'isInner'    => false,
		];
	}
}

if ( ! function_exists( '_hec_spacer' ) ) {
	function _hec_spacer( $size = 30 ) {
		return [
			'id'         => _hec_id(),
			'elType'     => 'widget',
			'widgetType' => 'spacer',
			'settings'   => [
				'space' => [ 'unit' => 'px', 'size' => $size, 'sizes' => [] ],
			],
			'elements'   => [],
			'isInner'    => false,
		];
	}
}

if ( ! function_exists( '_hec_divider' ) ) {
	function _hec_divider( $settings = [] ) {
		return [
			'id'         => _hec_id(),
			'elType'     => 'widget',
			'widgetType' => 'divider',
			'settings'   => array_merge( [
				'color' => '#E5E8EB',
				'gap'   => [ 'unit' => 'px', 'size' => 30, 'sizes' => [] ],
			], $settings ),
			'elements'   => [],
			'isInner'    => false,
		];
	}
}

if ( ! function_exists( '_hec_section' ) ) {
	function _hec_section( $columns, $settings = [] ) {
		return [
			'id'       => _hec_id(),
			'elType'   => 'section',
			'settings' => array_merge( [
				'gap' => 'default',
			], $settings ),
			'elements' => $columns,
			'isInner'  => false,
		];
	}
}

if ( ! function_exists( '_hec_inner_section' ) ) {
	function _hec_inner_section( $columns, $settings = [] ) {
		return [
			'id'       => _hec_id(),
			'elType'   => 'section',
			'settings' => array_merge( [
				'gap' => 'default',
			], $settings ),
			'elements' => $columns,
			'isInner'  => true,
		];
	}
}

if ( ! function_exists( '_hec_column' ) ) {
	function _hec_column( $widgets, $size = 100, $settings = [] ) {
		return [
			'id'       => _hec_id(),
			'elType'   => 'column',
			'settings' => array_merge( [
				'_column_size' => $size,
				'_inline_size' => null,
			], $settings ),
			'elements' => $widgets,
			'isInner'  => false,
		];
	}
}

// ─────────────────────────────────────────────
// 디자인 토큰
// ─────────────────────────────────────────────

$primary       = '#0064FF';
$primary_hover = '#0050CC';
$primary_light = '#E8F0FE';
$dark          = '#191F28';
$text_primary  = '#191F28';
$text_secondary = '#4E5968';
$text_tertiary = '#8B95A1';
$bg_white      = '#FFFFFF';
$bg_light      = '#F8F9FA';
$bg_dark       = '#191F28';
$border        = '#E5E8EB';
$accent_orange = '#FF6B3C';
$success       = '#00C471';

// 공통 타이포 설정
$typo_base = [
	'typography_typography' => 'custom',
	'typography_font_family' => 'Pretendard',
];

// ─────────────────────────────────────────────
// 페이지 데이터 반환
// ─────────────────────────────────────────────

return [

	// ═══════════════════════════════════════════
	// SECTION 1: HERO
	// 다크 배경, 중앙 정렬, CTA 2개
	// ═══════════════════════════════════════════
	_hec_section(
		[
			_hec_column( [
				// 뱃지
				_hec_heading(
					'온라인 강의 + 커뮤니티 + 세일즈 퍼널, 올인원',
					array_merge( $typo_base, [
						'title_color'           => $primary,
						'typography_font_size'   => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
						'typography_font_weight' => '600',
						'typography_letter_spacing' => [ 'unit' => 'px', 'size' => 1, 'sizes' => [] ],
						'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 12, 'sizes' => [] ],
					] )
				),
				_hec_spacer( 16 ),
				// 메인 헤드라인
				_hec_heading(
					'당신의 지식을 <br><b style="color:' . $primary . ';">수익이 되는 사이트</b>로 만드세요',
					array_merge( $typo_base, [
						'title_color'           => '#FFFFFF',
						'typography_font_size'   => [ 'unit' => 'px', 'size' => 48, 'sizes' => [] ],
						'typography_font_weight' => '700',
						'typography_line_height' => [ 'unit' => 'em', 'size' => 1.3, 'sizes' => [] ],
						'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
					] )
				),
				_hec_spacer( 16 ),
				// 서브카피
				_hec_heading(
					'강의 제작, 수강생 관리, 라이브 일정, 커뮤니티 운영까지<br>코딩 없이 나만의 독립 플랫폼에서 시작하세요.',
					array_merge( $typo_base, [
						'title_color'           => '#B0B8C1',
						'typography_font_size'   => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
						'typography_font_weight' => '300',
						'typography_line_height' => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
					] )
				),
				_hec_spacer( 32 ),
				// CTA 버튼 2개
				_hec_inner_section( [
					_hec_column( [
						_hec_button( '무료 자료 받기', '/free-ebook/', [
							'background_color'      => $primary,
							'button_text_color'     => '#FFFFFF',
							'border_radius'         => [ 'unit' => 'px', 'top' => '30', 'right' => '30', 'bottom' => '30', 'left' => '30', 'isLinked' => true ],
							'typography_typography'  => 'custom',
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 17, 'sizes' => [] ],
							'typography_font_weight' => '600',
						] ),
					], 50 ),
					_hec_column( [
						_hec_button( '강의 둘러보기', '/courses/', [
							'background_color'       => 'transparent',
							'button_text_color'      => '#FFFFFF',
							'button_border_color'    => 'rgba(255,255,255,0.3)',
							'border_border'          => 'solid',
							'border_width'           => [ 'unit' => 'px', 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'isLinked' => true ],
							'border_radius'          => [ 'unit' => 'px', 'top' => '30', 'right' => '30', 'bottom' => '30', 'left' => '30', 'isLinked' => true ],
							'typography_typography'   => 'custom',
							'typography_font_size'    => [ 'unit' => 'px', 'size' => 17, 'sizes' => [] ],
							'typography_font_weight'  => '600',
						] ),
					], 50 ),
				] ),
				_hec_spacer( 20 ),
				// 마이크로카피
				_hec_heading(
					'회원가입만으로 무료 강의와 커뮤니티를 이용할 수 있습니다',
					array_merge( $typo_base, [
						'title_color'           => '#6B7684',
						'typography_font_size'   => [ 'unit' => 'px', 'size' => 13, 'sizes' => [] ],
						'typography_font_weight' => '400',
					] )
				),
			] ),
		],
		[
			'padding'               => [ 'unit' => 'px', 'top' => '140', 'right' => '0', 'bottom' => '140', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '80', 'right' => '20', 'bottom' => '80', 'left' => '20', 'isLinked' => false ],
			'background_background' => 'gradient',
			'background_color'      => $bg_dark,
			'background_color_b'    => '#0A1628',
			'background_gradient_type'     => 'linear',
			'background_gradient_angle'    => [ 'unit' => 'deg', 'size' => 160, 'sizes' => [] ],
			'content_width'         => [ 'unit' => 'px', 'size' => 800, 'sizes' => [] ],
		]
	),

	// ═══════════════════════════════════════════
	// SECTION 2: SOCIAL PROOF — 숫자 통계
	// ═══════════════════════════════════════════
	_hec_section(
		[
			_hec_column( [
				_hec_inner_section( [
					_hec_column( [
						_hec_heading( '1,200+', array_merge( $typo_base, [
							'title_color'           => $primary,
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 40, 'sizes' => [] ],
							'typography_font_weight' => '800',
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
						] ) ),
						_hec_heading( '누적 수강생', array_merge( $typo_base, [
							'title_color'           => $text_secondary,
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight' => '500',
						] ) ),
					], 25 ),
					_hec_column( [
						_hec_heading( '96%', array_merge( $typo_base, [
							'title_color'           => $primary,
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 40, 'sizes' => [] ],
							'typography_font_weight' => '800',
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
						] ) ),
						_hec_heading( '수강 만족도', array_merge( $typo_base, [
							'title_color'           => $text_secondary,
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight' => '500',
						] ) ),
					], 25 ),
					_hec_column( [
						_hec_heading( '50+', array_merge( $typo_base, [
							'title_color'           => $primary,
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 40, 'sizes' => [] ],
							'typography_font_weight' => '800',
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
						] ) ),
						_hec_heading( '라이브 세션', array_merge( $typo_base, [
							'title_color'           => $text_secondary,
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight' => '500',
						] ) ),
					], 25 ),
					_hec_column( [
						_hec_heading( '4.9', array_merge( $typo_base, [
							'title_color'           => $primary,
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 40, 'sizes' => [] ],
							'typography_font_weight' => '800',
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
						] ) ),
						_hec_heading( '평균 평점', array_merge( $typo_base, [
							'title_color'           => $text_secondary,
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight' => '500',
						] ) ),
					], 25 ),
				] ),
			] ),
		],
		[
			'padding'               => [ 'unit' => 'px', 'top' => '60', 'right' => '0', 'bottom' => '60', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '40', 'right' => '20', 'bottom' => '40', 'left' => '20', 'isLinked' => false ],
			'background_background' => 'classic',
			'background_color'      => $bg_white,
			'border_border'         => 'solid',
			'border_width'          => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '1', 'left' => '0', 'isLinked' => false ],
			'border_color'          => $border,
			'content_width'         => [ 'unit' => 'px', 'size' => 1100, 'sizes' => [] ],
		]
	),

	// ═══════════════════════════════════════════
	// SECTION 3: 인기 강의 3선
	// ═══════════════════════════════════════════
	_hec_section(
		[
			_hec_column( [
				// 섹션 라벨
				_hec_heading( 'COURSES', array_merge( $typo_base, [
					'title_color'              => $primary,
					'typography_font_size'      => [ 'unit' => 'px', 'size' => 13, 'sizes' => [] ],
					'typography_font_weight'    => '700',
					'typography_letter_spacing' => [ 'unit' => 'px', 'size' => 3, 'sizes' => [] ],
				] ) ),
				_hec_spacer( 8 ),
				_hec_heading( '체계적으로 배우고, 바로 실행하세요', array_merge( $typo_base, [
					'title_color'           => $text_primary,
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 32, 'sizes' => [] ],
					'typography_font_weight' => '700',
					'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
				] ) ),
				_hec_spacer( 8 ),
				_hec_heading( '실전 중심의 커리큘럼으로 지식을 수익으로 전환하는 방법을 알려드립니다.', array_merge( $typo_base, [
					'title_color'           => $text_tertiary,
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
					'typography_font_weight' => '400',
				] ) ),
				_hec_spacer( 40 ),

				// 강의 카드 3개
				_hec_inner_section( [
					// 강의 1
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#F8F9FA; border-radius:12px; padding:32px; border:1px solid #E5E8EB; height:100%;">'
							. '<div style="display:inline-block; background:#E8F0FE; color:#0064FF; font-size:12px; font-weight:600; padding:4px 12px; border-radius:20px; margin-bottom:16px;">입문</div>'
							. '<h3 style="font-size:20px; font-weight:700; color:#191F28; margin:0 0 8px 0; line-height:1.4;">지식 창업 시작 가이드</h3>'
							. '<p style="font-size:14px; color:#8B95A1; line-height:1.6; margin:0 0 20px 0;">나만의 전문 지식을 온라인 강의로 만들고, 첫 수강생을 모집하는 전 과정을 단계별로 안내합니다.</p>'
							. '<div style="display:flex; gap:16px; font-size:13px; color:#4E5968;">'
							. '<span>12개 레슨</span>'
							. '<span>총 3시간</span>'
							. '<span>무료</span>'
							. '</div>'
							. '</div>'
						),
					], 33 ),
					// 강의 2
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#F8F9FA; border-radius:12px; padding:32px; border:1px solid #E5E8EB; height:100%;">'
							. '<div style="display:inline-block; background:#FFF4E8; color:#FF9500; font-size:12px; font-weight:600; padding:4px 12px; border-radius:20px; margin-bottom:16px;">실전</div>'
							. '<h3 style="font-size:20px; font-weight:700; color:#191F28; margin:0 0 8px 0; line-height:1.4;">세일즈 퍼널 마스터 클래스</h3>'
							. '<p style="font-size:14px; color:#8B95A1; line-height:1.6; margin:0 0 20px 0;">무료 PDF 제공부터 저가 상품, 본 강의까지 — 자동으로 매출이 쌓이는 퍼널 구조를 직접 구축합니다.</p>'
							. '<div style="display:flex; gap:16px; font-size:13px; color:#4E5968;">'
							. '<span>24개 레슨</span>'
							. '<span>총 8시간</span>'
							. '<span>&#8361;149,000</span>'
							. '</div>'
							. '</div>'
						),
					], 33 ),
					// 강의 3
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#F8F9FA; border-radius:12px; padding:32px; border:1px solid #E5E8EB; height:100%;">'
							. '<div style="display:inline-block; background:#E8FBF0; color:#00C471; font-size:12px; font-weight:600; padding:4px 12px; border-radius:20px; margin-bottom:16px;">심화</div>'
							. '<h3 style="font-size:20px; font-weight:700; color:#191F28; margin:0 0 8px 0; line-height:1.4;">커뮤니티 운영 전략</h3>'
							. '<p style="font-size:14px; color:#8B95A1; line-height:1.6; margin:0 0 20px 0;">수강생이 서로 돕고 성장하는 커뮤니티를 만들어 재구매율과 고객 생애가치를 높이는 전략입니다.</p>'
							. '<div style="display:flex; gap:16px; font-size:13px; color:#4E5968;">'
							. '<span>18개 레슨</span>'
							. '<span>총 6시간</span>'
							. '<span>&#8361;99,000</span>'
							. '</div>'
							. '</div>'
						),
					], 33 ),
				] ),
				_hec_spacer( 32 ),
				_hec_button( '전체 강의 보기', '/courses/', array_merge( $typo_base, [
					'background_color'      => 'transparent',
					'button_text_color'     => $primary,
					'button_border_color'   => $primary,
					'border_border'         => 'solid',
					'border_width'          => [ 'unit' => 'px', 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'isLinked' => true ],
					'border_radius'         => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
					'typography_font_weight' => '600',
				] ) ),
			] ),
		],
		[
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '60', 'right' => '20', 'bottom' => '60', 'left' => '20', 'isLinked' => false ],
			'background_background' => 'classic',
			'background_color'      => $bg_white,
			'content_width'         => [ 'unit' => 'px', 'size' => 1100, 'sizes' => [] ],
		]
	),

	// ═══════════════════════════════════════════
	// SECTION 4: 무료 리소스 (리드마그넷)
	// ═══════════════════════════════════════════
	_hec_section(
		[
			_hec_column( [
				_hec_inner_section( [
					// 좌측: 텍스트
					_hec_column( [
						_hec_heading( 'FREE RESOURCE', array_merge( $typo_base, [
							'title_color'              => $success,
							'align'                    => 'left',
							'typography_font_size'      => [ 'unit' => 'px', 'size' => 13, 'sizes' => [] ],
							'typography_font_weight'    => '700',
							'typography_letter_spacing' => [ 'unit' => 'px', 'size' => 3, 'sizes' => [] ],
						] ) ),
						_hec_spacer( 8 ),
						_hec_heading(
							'지식 창업 시작을 위한<br><b style="color:' . $primary . ';">무료 가이드북</b>을 받아보세요',
							array_merge( $typo_base, [
								'title_color'           => $text_primary,
								'align'                 => 'left',
								'typography_font_size'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
								'typography_font_weight' => '700',
								'typography_line_height' => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
								'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							] )
						),
						_hec_spacer( 12 ),
						_hec_heading(
							'온라인 강의 기획부터 첫 매출까지, 실전 로드맵을 PDF로 정리했습니다. 카카오 로그인 한 번으로 바로 다운로드하세요.',
							array_merge( $typo_base, [
								'title_color'           => $text_secondary,
								'align'                 => 'left',
								'typography_font_size'   => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
								'typography_font_weight' => '400',
								'typography_line_height' => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							] )
						),
						_hec_spacer( 24 ),
						_hec_button( '무료 PDF 다운로드', '/free-ebook/', [
							'align'                 => 'left',
							'background_color'      => $success,
							'button_text_color'     => '#FFFFFF',
							'border_radius'         => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
							'typography_typography'  => 'custom',
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'typography_font_weight' => '600',
						] ),
					], 60, [
						'content_position' => 'center',
						'padding' => [ 'unit' => 'px', 'top' => '0', 'right' => '40', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
						'padding_mobile' => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '30', 'left' => '0', 'isLinked' => false ],
					] ),
					// 우측: 체크리스트
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#FFFFFF; border-radius:12px; padding:32px; border:1px solid #E5E8EB;">'
							. '<p style="font-size:15px; font-weight:600; color:#191F28; margin:0 0 20px 0;">가이드북에 담긴 내용</p>'
							. '<div style="display:flex; flex-direction:column; gap:12px;">'
							. '<div style="display:flex; align-items:flex-start; gap:10px;"><span style="color:#00C471; font-size:16px; flex-shrink:0;">&#10003;</span><span style="font-size:14px; color:#4E5968; line-height:1.5;">수익화 가능한 지식 주제 선정법</span></div>'
							. '<div style="display:flex; align-items:flex-start; gap:10px;"><span style="color:#00C471; font-size:16px; flex-shrink:0;">&#10003;</span><span style="font-size:14px; color:#4E5968; line-height:1.5;">온라인 강의 커리큘럼 설계 템플릿</span></div>'
							. '<div style="display:flex; align-items:flex-start; gap:10px;"><span style="color:#00C471; font-size:16px; flex-shrink:0;">&#10003;</span><span style="font-size:14px; color:#4E5968; line-height:1.5;">무료 콘텐츠 → 유료 전환 퍼널 구조</span></div>'
							. '<div style="display:flex; align-items:flex-start; gap:10px;"><span style="color:#00C471; font-size:16px; flex-shrink:0;">&#10003;</span><span style="font-size:14px; color:#4E5968; line-height:1.5;">첫 수강생 100명 모집 실전 전략</span></div>'
							. '<div style="display:flex; align-items:flex-start; gap:10px;"><span style="color:#00C471; font-size:16px; flex-shrink:0;">&#10003;</span><span style="font-size:14px; color:#4E5968; line-height:1.5;">수강생 커뮤니티 활성화 가이드</span></div>'
							. '</div>'
							. '<p style="font-size:12px; color:#8B95A1; margin:20px 0 0 0;">이미 850명이 다운로드했습니다</p>'
							. '</div>'
						),
					], 40 ),
				] ),
			] ),
		],
		[
			'padding'               => [ 'unit' => 'px', 'top' => '80', 'right' => '0', 'bottom' => '80', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'background_background' => 'classic',
			'background_color'      => $bg_light,
			'content_width'         => [ 'unit' => 'px', 'size' => 1100, 'sizes' => [] ],
		]
	),

	// ═══════════════════════════════════════════
	// SECTION 5: 다가오는 일정
	// ═══════════════════════════════════════════
	_hec_section(
		[
			_hec_column( [
				_hec_heading( 'UPCOMING', array_merge( $typo_base, [
					'title_color'              => $accent_orange,
					'typography_font_size'      => [ 'unit' => 'px', 'size' => 13, 'sizes' => [] ],
					'typography_font_weight'    => '700',
					'typography_letter_spacing' => [ 'unit' => 'px', 'size' => 3, 'sizes' => [] ],
				] ) ),
				_hec_spacer( 8 ),
				_hec_heading( '다가오는 라이브 일정', array_merge( $typo_base, [
					'title_color'           => $text_primary,
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 32, 'sizes' => [] ],
					'typography_font_weight' => '700',
					'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
				] ) ),
				_hec_spacer( 8 ),
				_hec_heading( '실시간으로 질문하고, 함께 성장하는 라이브 세션에 참여하세요.', array_merge( $typo_base, [
					'title_color'           => $text_tertiary,
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
					'typography_font_weight' => '400',
				] ) ),
				_hec_spacer( 40 ),

				// 일정 카드 3개
				_hec_inner_section( [
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#FFFFFF; border-radius:12px; padding:24px; border:1px solid #E5E8EB;">'
							. '<div style="display:flex; align-items:center; gap:12px; margin-bottom:16px;">'
							. '<div style="background:#FFF4E8; color:#FF9500; font-size:12px; font-weight:600; padding:4px 10px; border-radius:20px;">무료</div>'
							. '<span style="font-size:13px; color:#8B95A1;">LIVE</span>'
							. '</div>'
							. '<h4 style="font-size:17px; font-weight:700; color:#191F28; margin:0 0 8px 0;">신규 회원 환영 라이브</h4>'
							. '<p style="font-size:13px; color:#8B95A1; margin:0 0 16px 0;">매주 수요일 오후 8시 / Zoom</p>'
							. '<p style="font-size:14px; color:#4E5968; line-height:1.6; margin:0;">사이트 활용법과 추천 학습 로드맵을 함께 안내해드리는 소규모 라이브 세션입니다.</p>'
							. '</div>'
						),
					], 33 ),
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#FFFFFF; border-radius:12px; padding:24px; border:1px solid #E5E8EB;">'
							. '<div style="display:flex; align-items:center; gap:12px; margin-bottom:16px;">'
							. '<div style="background:#E8F0FE; color:#0064FF; font-size:12px; font-weight:600; padding:4px 10px; border-radius:20px;">수강생 전용</div>'
							. '<span style="font-size:13px; color:#8B95A1;">LIVE</span>'
							. '</div>'
							. '<h4 style="font-size:17px; font-weight:700; color:#191F28; margin:0 0 8px 0;">월간 Q&A 오피스 아워</h4>'
							. '<p style="font-size:13px; color:#8B95A1; margin:0 0 16px 0;">매월 첫째 토요일 오전 11시 / Zoom</p>'
							. '<p style="font-size:14px; color:#4E5968; line-height:1.6; margin:0;">수강 중 궁금한 점을 직접 질문하고, 다른 수강생의 사례도 함께 배울 수 있습니다.</p>'
							. '</div>'
						),
					], 33 ),
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#FFFFFF; border-radius:12px; padding:24px; border:1px solid #E5E8EB;">'
							. '<div style="display:flex; align-items:center; gap:12px; margin-bottom:16px;">'
							. '<div style="background:#E8FBF0; color:#00C471; font-size:12px; font-weight:600; padding:4px 10px; border-radius:20px;">특별</div>'
							. '<span style="font-size:13px; color:#8B95A1;">워크숍</span>'
							. '</div>'
							. '<h4 style="font-size:17px; font-weight:700; color:#191F28; margin:0 0 8px 0;">퍼널 구축 실습 워크숍</h4>'
							. '<p style="font-size:13px; color:#8B95A1; margin:0 0 16px 0;">4/19 (토) 오후 2시~5시 / Gather</p>'
							. '<p style="font-size:14px; color:#4E5968; line-height:1.6; margin:0;">3시간 동안 나만의 세일즈 퍼널을 직접 만들어보는 실습형 워크숍입니다.</p>'
							. '</div>'
						),
					], 33 ),
				] ),
				_hec_spacer( 32 ),
				_hec_button( '전체 일정 보기', '/calendar/', array_merge( $typo_base, [
					'background_color'      => 'transparent',
					'button_text_color'     => $accent_orange,
					'button_border_color'   => $accent_orange,
					'border_border'         => 'solid',
					'border_width'          => [ 'unit' => 'px', 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'isLinked' => true ],
					'border_radius'         => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
					'typography_font_weight' => '600',
				] ) ),
			] ),
		],
		[
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '60', 'right' => '20', 'bottom' => '60', 'left' => '20', 'isLinked' => false ],
			'background_background' => 'classic',
			'background_color'      => $bg_white,
			'content_width'         => [ 'unit' => 'px', 'size' => 1100, 'sizes' => [] ],
		]
	),

	// ═══════════════════════════════════════════
	// SECTION 6: 커뮤니티 하이라이트
	// ═══════════════════════════════════════════
	_hec_section(
		[
			_hec_column( [
				_hec_heading( 'COMMUNITY', array_merge( $typo_base, [
					'title_color'              => $primary,
					'typography_font_size'      => [ 'unit' => 'px', 'size' => 13, 'sizes' => [] ],
					'typography_font_weight'    => '700',
					'typography_letter_spacing' => [ 'unit' => 'px', 'size' => 3, 'sizes' => [] ],
				] ) ),
				_hec_spacer( 8 ),
				_hec_heading( '함께 성장하는 커뮤니티', array_merge( $typo_base, [
					'title_color'           => $text_primary,
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 32, 'sizes' => [] ],
					'typography_font_weight' => '700',
					'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
				] ) ),
				_hec_spacer( 8 ),
				_hec_heading( '질문을 올리고, 경험을 나누고, 서로의 성장을 응원하세요.', array_merge( $typo_base, [
					'title_color'           => $text_tertiary,
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
					'typography_font_weight' => '400',
				] ) ),
				_hec_spacer( 40 ),

				// 커뮤니티 게시글 3개
				_hec_inner_section( [
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#FFFFFF; border-radius:12px; padding:24px; border:1px solid #E5E8EB;">'
							. '<div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">'
							. '<div style="width:32px; height:32px; background:#E8F0FE; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:14px; font-weight:600; color:#0064FF;">J</div>'
							. '<div><span style="font-size:14px; font-weight:600; color:#191F28;">김지영</span><span style="font-size:12px; color:#8B95A1; margin-left:8px;">2일 전</span></div>'
							. '</div>'
							. '<p style="font-size:14px; color:#191F28; line-height:1.6; margin:0 0 12px 0;">첫 온라인 강의를 드디어 오픈했습니다! 커리큘럼 설계부터 촬영, 편집까지 이 커뮤니티에서 배운 덕분이에요. 특히 퍼널 구축 워크숍이 결정적이었습니다.</p>'
							. '<div style="display:flex; gap:16px; font-size:13px; color:#8B95A1;">'
							. '<span>&#9825; 24</span>'
							. '<span>&#9993; 8</span>'
							. '</div>'
							. '</div>'
						),
					], 33 ),
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#FFFFFF; border-radius:12px; padding:24px; border:1px solid #E5E8EB;">'
							. '<div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">'
							. '<div style="width:32px; height:32px; background:#FFF4E8; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:14px; font-weight:600; color:#FF9500;">P</div>'
							. '<div><span style="font-size:14px; font-weight:600; color:#191F28;">박준혁</span><span style="font-size:12px; color:#8B95A1; margin-left:8px;">3일 전</span></div>'
							. '</div>'
							. '<p style="font-size:14px; color:#191F28; line-height:1.6; margin:0 0 12px 0;">무료 PDF로 이메일 구독자 300명을 모았는데, 이 중 15%가 유료 강의를 구매했습니다. 리드마그넷 전략이 정말 효과적이네요.</p>'
							. '<div style="display:flex; gap:16px; font-size:13px; color:#8B95A1;">'
							. '<span>&#9825; 31</span>'
							. '<span>&#9993; 12</span>'
							. '</div>'
							. '</div>'
						),
					], 33 ),
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#FFFFFF; border-radius:12px; padding:24px; border:1px solid #E5E8EB;">'
							. '<div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">'
							. '<div style="width:32px; height:32px; background:#E8FBF0; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:14px; font-weight:600; color:#00C471;">L</div>'
							. '<div><span style="font-size:14px; font-weight:600; color:#191F28;">이수민</span><span style="font-size:12px; color:#8B95A1; margin-left:8px;">5일 전</span></div>'
							. '</div>'
							. '<p style="font-size:14px; color:#191F28; line-height:1.6; margin:0 0 12px 0;">라이브 Q&A에서 받은 피드백으로 강의 구성을 수정했더니 수강 완료율이 40%에서 78%로 올랐어요. 커뮤니티의 힘이란...</p>'
							. '<div style="display:flex; gap:16px; font-size:13px; color:#8B95A1;">'
							. '<span>&#9825; 18</span>'
							. '<span>&#9993; 6</span>'
							. '</div>'
							. '</div>'
						),
					], 33 ),
				] ),
				_hec_spacer( 32 ),
				_hec_button( '커뮤니티 참여하기', '/community/', array_merge( $typo_base, [
					'background_color'      => 'transparent',
					'button_text_color'     => $primary,
					'button_border_color'   => $primary,
					'border_border'         => 'solid',
					'border_width'          => [ 'unit' => 'px', 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'isLinked' => true ],
					'border_radius'         => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
					'typography_font_weight' => '600',
				] ) ),
			] ),
		],
		[
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '60', 'right' => '20', 'bottom' => '60', 'left' => '20', 'isLinked' => false ],
			'background_background' => 'classic',
			'background_color'      => $bg_light,
			'content_width'         => [ 'unit' => 'px', 'size' => 1100, 'sizes' => [] ],
		]
	),

	// ═══════════════════════════════════════════
	// SECTION 7: 블로그 최신글
	// ═══════════════════════════════════════════
	_hec_section(
		[
			_hec_column( [
				_hec_heading( 'BLOG', array_merge( $typo_base, [
					'title_color'              => $primary,
					'typography_font_size'      => [ 'unit' => 'px', 'size' => 13, 'sizes' => [] ],
					'typography_font_weight'    => '700',
					'typography_letter_spacing' => [ 'unit' => 'px', 'size' => 3, 'sizes' => [] ],
				] ) ),
				_hec_spacer( 8 ),
				_hec_heading( '지식 창업에 필요한 인사이트', array_merge( $typo_base, [
					'title_color'           => $text_primary,
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 32, 'sizes' => [] ],
					'typography_font_weight' => '700',
					'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
				] ) ),
				_hec_spacer( 8 ),
				_hec_heading( '온라인 비즈니스, 마케팅, 콘텐츠 전략에 관한 실전 노하우를 공유합니다.', array_merge( $typo_base, [
					'title_color'           => $text_tertiary,
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
					'typography_font_weight' => '400',
				] ) ),
				_hec_spacer( 40 ),

				// 블로그 카드 3개
				_hec_inner_section( [
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#F8F9FA; border-radius:12px; padding:28px; border:1px solid #E5E8EB; height:100%;">'
							. '<div style="font-size:12px; color:#0064FF; font-weight:600; margin-bottom:12px;">온라인 비즈니스</div>'
							. '<h4 style="font-size:18px; font-weight:700; color:#191F28; margin:0 0 10px 0; line-height:1.5;">지식 창업, 첫 3개월 안에 반드시 해야 할 5가지</h4>'
							. '<p style="font-size:14px; color:#8B95A1; line-height:1.6; margin:0;">시작이 반이라고 하지만, 방향이 맞아야 합니다. 첫 3개월 동안의 핵심 액션 아이템을 정리했습니다.</p>'
							. '</div>'
						),
					], 33 ),
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#F8F9FA; border-radius:12px; padding:28px; border:1px solid #E5E8EB; height:100%;">'
							. '<div style="font-size:12px; color:#0064FF; font-weight:600; margin-bottom:12px;">마케팅 전략</div>'
							. '<h4 style="font-size:18px; font-weight:700; color:#191F28; margin:0 0 10px 0; line-height:1.5;">무료 PDF 하나로 이메일 리스트 1,000명 만드는 법</h4>'
							. '<p style="font-size:14px; color:#8B95A1; line-height:1.6; margin:0;">리드마그넷의 기획부터 제작, 배포, 후속 이메일 시퀀스까지 전 과정을 상세히 풀어봅니다.</p>'
							. '</div>'
						),
					], 33 ),
					_hec_column( [
						_hec_text_editor(
							'<div style="background:#F8F9FA; border-radius:12px; padding:28px; border:1px solid #E5E8EB; height:100%;">'
							. '<div style="font-size:12px; color:#0064FF; font-weight:600; margin-bottom:12px;">콘텐츠 전략</div>'
							. '<h4 style="font-size:18px; font-weight:700; color:#191F28; margin:0 0 10px 0; line-height:1.5;">블로그 글 하나가 매달 수강생을 데려오는 구조 만들기</h4>'
							. '<p style="font-size:14px; color:#8B95A1; line-height:1.6; margin:0;">SEO 최적화된 블로그 글이 어떻게 자동 유입 → 구독 → 구매로 이어지는지 실제 사례로 보여드립니다.</p>'
							. '</div>'
						),
					], 33 ),
				] ),
				_hec_spacer( 32 ),
				_hec_button( '블로그 전체 보기', '/blogs/', array_merge( $typo_base, [
					'background_color'      => 'transparent',
					'button_text_color'     => $primary,
					'button_border_color'   => $primary,
					'border_border'         => 'solid',
					'border_width'          => [ 'unit' => 'px', 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'isLinked' => true ],
					'border_radius'         => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
					'typography_font_weight' => '600',
				] ) ),
			] ),
		],
		[
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '60', 'right' => '20', 'bottom' => '60', 'left' => '20', 'isLinked' => false ],
			'background_background' => 'classic',
			'background_color'      => $bg_white,
			'content_width'         => [ 'unit' => 'px', 'size' => 1100, 'sizes' => [] ],
		]
	),

	// ═══════════════════════════════════════════
	// SECTION 8: FAQ
	// ═══════════════════════════════════════════
	_hec_section(
		[
			_hec_column( [
				_hec_heading( 'FAQ', array_merge( $typo_base, [
					'title_color'              => $primary,
					'typography_font_size'      => [ 'unit' => 'px', 'size' => 13, 'sizes' => [] ],
					'typography_font_weight'    => '700',
					'typography_letter_spacing' => [ 'unit' => 'px', 'size' => 3, 'sizes' => [] ],
				] ) ),
				_hec_spacer( 8 ),
				_hec_heading( '자주 묻는 질문', array_merge( $typo_base, [
					'title_color'           => $text_primary,
					'typography_font_size'   => [ 'unit' => 'px', 'size' => 32, 'sizes' => [] ],
					'typography_font_weight' => '700',
				] ) ),
				_hec_spacer( 32 ),
				_hec_accordion( [
					[
						'q' => '완전 초보자도 따라할 수 있나요?',
						'a' => '네, 물론입니다. 모든 강의는 기초부터 단계별로 구성되어 있으며, 막히는 부분은 커뮤니티와 라이브 Q&A에서 바로 해결할 수 있습니다.',
					],
					[
						'q' => '강의는 어떤 형태로 진행되나요?',
						'a' => '녹화 영상 강의 + 실습 자료 + 라이브 세션으로 구성됩니다. 녹화 강의는 수강 기간 내 무제한 반복 시청이 가능하고, 라이브 세션은 캘린더에서 일정을 확인하실 수 있습니다.',
					],
					[
						'q' => '무료로 체험해볼 수 있나요?',
						'a' => '네, 무료 가이드북 다운로드와 입문 강의를 통해 먼저 체험해보실 수 있습니다. 또한 매주 진행되는 무료 라이브 세션에도 참여하실 수 있습니다.',
					],
					[
						'q' => '환불 정책은 어떻게 되나요?',
						'a' => '유료 강의는 구매 후 7일 이내, 수강률 30% 미만일 경우 전액 환불이 가능합니다.',
					],
					[
						'q' => '수강 기간 제한이 있나요?',
						'a' => '강의에 따라 다르지만, 대부분의 강의는 수강 시작일로부터 1년간 무제한 시청이 가능합니다. 일부 무료 강의는 기간 제한 없이 이용 가능합니다.',
					],
				] ),
			] ),
		],
		[
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '60', 'right' => '20', 'bottom' => '60', 'left' => '20', 'isLinked' => false ],
			'background_background' => 'classic',
			'background_color'      => $bg_light,
			'content_width'         => [ 'unit' => 'px', 'size' => 800, 'sizes' => [] ],
		]
	),

	// ═══════════════════════════════════════════
	// SECTION 9: FINAL CTA
	// ═══════════════════════════════════════════
	_hec_section(
		[
			_hec_column( [
				_hec_heading(
					'지금 시작하세요',
					array_merge( $typo_base, [
						'title_color'           => '#FFFFFF',
						'typography_font_size'   => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
						'typography_font_weight' => '700',
						'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
					] )
				),
				_hec_spacer( 12 ),
				_hec_heading(
					'무료 가이드북부터 시작해서, 강의와 커뮤니티를 통해<br>당신의 지식을 수익으로 전환하는 여정을 함께합니다.',
					array_merge( $typo_base, [
						'title_color'           => '#B0B8C1',
						'typography_font_size'   => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
						'typography_font_weight' => '400',
						'typography_line_height' => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
						'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
					] )
				),
				_hec_spacer( 32 ),
				_hec_inner_section( [
					_hec_column( [
						_hec_button( '무료 자료 받기', '/free-ebook/', [
							'background_color'      => $primary,
							'button_text_color'     => '#FFFFFF',
							'border_radius'         => [ 'unit' => 'px', 'top' => '30', 'right' => '30', 'bottom' => '30', 'left' => '30', 'isLinked' => true ],
							'typography_typography'  => 'custom',
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 17, 'sizes' => [] ],
							'typography_font_weight' => '600',
						] ),
					], 50 ),
					_hec_column( [
						_hec_button( '회원가입하고 시작하기', '/login/', [
							'background_color'       => 'transparent',
							'button_text_color'      => '#FFFFFF',
							'button_border_color'    => 'rgba(255,255,255,0.3)',
							'border_border'          => 'solid',
							'border_width'           => [ 'unit' => 'px', 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'isLinked' => true ],
							'border_radius'          => [ 'unit' => 'px', 'top' => '30', 'right' => '30', 'bottom' => '30', 'left' => '30', 'isLinked' => true ],
							'typography_typography'   => 'custom',
							'typography_font_size'    => [ 'unit' => 'px', 'size' => 17, 'sizes' => [] ],
							'typography_font_weight'  => '600',
						] ),
					], 50 ),
				] ),
			] ),
		],
		[
			'padding'               => [ 'unit' => 'px', 'top' => '120', 'right' => '0', 'bottom' => '120', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '80', 'right' => '20', 'bottom' => '80', 'left' => '20', 'isLinked' => false ],
			'background_background' => 'gradient',
			'background_color'      => $bg_dark,
			'background_color_b'    => '#0A1628',
			'background_gradient_type'     => 'linear',
			'background_gradient_angle'    => [ 'unit' => 'deg', 'size' => 160, 'sizes' => [] ],
			'content_width'         => [ 'unit' => 'px', 'size' => 800, 'sizes' => [] ],
		]
	),

];
