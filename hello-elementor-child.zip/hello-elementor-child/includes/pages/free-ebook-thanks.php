<?php
/**
 * 전자책 신청 완료 페이지 — Elementor 데이터
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return [
	// ─────────────────────────────────────────────
	// 섹션 1: 감사 메시지 + 다운로드 (다크 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'thanks_hero',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#000000',
			'padding'               => [ 'unit' => 'px', 'top' => '150', 'right' => '0', 'bottom' => '80', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '100', 'right' => '30', 'bottom' => '60', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '80', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 700, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'thanks_hero_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// 체크 아이콘 (Elementor Icon 위젯)
					[
						'id'         => 'thanks_icon',
						'elType'     => 'widget',
						'widgetType' => 'icon',
						'settings'   => [
							'selected_icon'   => [ 'value' => 'fas fa-check-circle', 'library' => 'fa-solid' ],
							'align'           => 'center',
							'primary_color'   => '#1E75F1',
							'size'            => [ 'unit' => 'px', 'size' => 60, 'sizes' => [] ],
							'_margin'          => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '25', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 감사 타이틀
					[
						'id'         => 'thanks_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => '전자책 신청이 완료되었습니다!',
							'header_size'                  => 'h1',
							'align'                        => 'center',
							'title_color'                  => '#FFFFFF',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 안내 문구
					[
						'id'         => 'thanks_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '전자책을 이메일로도 발송해드립니다.',
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#A4A4A4',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 17, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '35', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 다운로드 버튼
					[
						'id'         => 'thanks_download_btn',
						'elType'     => 'widget',
						'widgetType' => 'button',
						'settings'   => [
							'text'                          => '바로 다운로드',
							'align'                         => 'center',
							'link'                          => [ 'url' => '#', 'is_external' => false, 'nofollow' => false ],
							'size'                          => 'lg',
							'button_text_color'             => '#FFFFFF',
							'background_color'              => '#1E75F1',
							'border_radius'                 => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
							'typography_typography'          => 'custom',
							'typography_font_family'         => 'Noto Sans',
							'typography_font_size'           => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'         => '600',
							'button_hover_color'            => '#FFFFFF',
							'button_background_hover_color' => '#1565D8',
							'text_padding'                  => [ 'unit' => 'px', 'top' => '15', 'right' => '50', 'bottom' => '15', 'left' => '50', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 2: 특별 혜택 (다크 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'thanks_offer',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#000000',
			'padding'               => [ 'unit' => 'px', 'top' => '60', 'right' => '0', 'bottom' => '120', 'left' => '0', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '40', 'right' => '20', 'bottom' => '80', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 600, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'thanks_offer_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 100,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#111111',
					'border_radius'           => [ 'unit' => 'px', 'top' => '20', 'right' => '20', 'bottom' => '20', 'left' => '20', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '40', 'right' => '40', 'bottom' => '40', 'left' => '40', 'isLinked' => true ],
					'padding_mobile'          => [ 'unit' => 'px', 'top' => '30', 'right' => '25', 'bottom' => '30', 'left' => '25', 'isLinked' => false ],
				],
				'elements' => [
					// 특별 혜택 타이틀
					[
						'id'         => 'thanks_offer_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '전자책 신청자 특별 혜택',
							'header_size'                => 'h3',
							'align'                      => 'center',
							'title_color'                => '#FFFFFF',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
							'typography_font_weight'      => '700',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '25', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 과정명
					[
						'id'         => 'thanks_course_name',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '입문 과정 VOD 클래스',
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#CCCCCC',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 원가
					[
						'id'         => 'thanks_original_price',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '<del>199,000 원</del>',
							'header_size'                => 'h5',
							'align'                      => 'center',
							'title_color'                => '#666666',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '5', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 할인가
					[
						'id'         => 'thanks_sale_price',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '99,000 원',
							'header_size'                => 'h3',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 30, 'sizes' => [] ],
							'typography_font_weight'      => '700',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 설명
					[
						'id'         => 'thanks_offer_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '입문 VOD 과정을 함께 공부하시면 훨씬 빠른 습득이 가능합니다.',
							'header_size'                => 'p',
							'align'                      => 'center',
							'title_color'                => '#888888',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '25', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 구매 버튼
					[
						'id'         => 'thanks_buy_btn',
						'elType'     => 'widget',
						'widgetType' => 'button',
						'settings'   => [
							'text'                          => '바로 구매',
							'align'                         => 'center',
							'link'                          => [ 'url' => '#', 'is_external' => false, 'nofollow' => false ],
							'size'                          => 'lg',
							'button_text_color'             => '#FFFFFF',
							'background_color'              => '#1E75F1',
							'border_radius'                 => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
							'typography_typography'          => 'custom',
							'typography_font_family'         => 'Noto Sans',
							'typography_font_size'           => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'         => '600',
							'button_hover_color'            => '#FFFFFF',
							'button_background_hover_color' => '#1565D8',
							'text_padding'                  => [ 'unit' => 'px', 'top' => '15', 'right' => '50', 'bottom' => '15', 'left' => '50', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 3: 재신청 안내 (다크 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'thanks_retry',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#000000',
			'padding'               => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '120', 'left' => '0', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 700, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'thanks_retry_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					[
						'id'         => 'thanks_retry_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '전자책 발송이 완료 되었습니다.',
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#FFFFFF',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'thanks_retry_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '전자책을 받지 못한 경우, 재신청 하시기 바랍니다.',
							'header_size'                => 'p',
							'align'                      => 'center',
							'title_color'                => '#888888',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '30', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 재신청 폼 숏코드
					[
						'id'         => 'thanks_retry_form',
						'elType'     => 'widget',
						'widgetType' => 'shortcode',
						'settings'   => [
							'shortcode' => '<!-- 여기에 폼 숏코드를 넣으세요. 예: [fluentform id="1"] 또는 [wpforms id="1"] -->',
						],
						'elements' => [],
					],
				],
			],
		],
	],
];
