<?php
/**
 * 무료 전자책 랜딩페이지 — Elementor 데이터
 *
 * Kit 디자인 참고: 다크 테마, #1E75F1 블루 액센트, Noto Sans
 * Section/Column 구조 (Elementor Classic)
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return [
	// ─────────────────────────────────────────────
	// 섹션 1: 히어로 (다크 배경, 2컬럼)
	// ─────────────────────────────────────────────
	[
		'id'       => 'ebook_hero',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '20',
			'background_background'  => 'classic',
			'background_color'       => '#000000',
			'padding'                => [ 'unit' => 'px', 'top' => '120', 'right' => '0', 'bottom' => '120', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '80', 'right' => '30', 'bottom' => '80', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '60', 'left' => '20', 'isLinked' => false ],
			'margin'                 => [ 'unit' => 'px', 'top' => '0', 'right' => 0, 'bottom' => '0', 'left' => 0, 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			// 좌측: 텍스트 영역
			[
				'id'       => 'ebook_hero_left',
				'elType'   => 'column',
				'settings' => [
					'_column_size'     => 50,
					'_inline_size'     => null,
					'content_position' => 'center',
					'padding'          => [ 'unit' => 'px', 'top' => '0', 'right' => '30', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
					'padding_mobile'   => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '30', 'left' => '0', 'isLinked' => false ],
				],
				'elements' => [
					// 라벨
					[
						'id'         => 'ebook_hero_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '무료 전자책',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'typography_line_height'      => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '20', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 메인 헤드라인
					[
						'id'         => 'ebook_hero_headline',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "지식을 수익으로 바꾸는<br>\n첫 번째 공식,<br>\n무료로 드립니다.",
							'header_size'                  => 'h1',
							'align'                        => 'left',
							'title_color'                  => '#FFFFFF',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 42, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.5, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 32, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '20', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 서브 헤드라인
					[
						'id'         => 'ebook_hero_sub',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "온라인 비즈니스를 시작하고 싶지만 뭐부터 해야 할지 모르겠다면,<br>\n이 전자책 하나로 전체 그림을 잡으세요.",
							'header_size'                  => 'h3',
							'align'                        => 'left',
							'title_color'                  => '#A4A4A4',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_weight'        => '400',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
			// 우측: 전자책 카드
			[
				'id'       => 'ebook_hero_right',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 50,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#111111',
					'border_radius'           => [ 'unit' => 'px', 'top' => '20', 'right' => '20', 'bottom' => '20', 'left' => '20', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '40', 'right' => '40', 'bottom' => '40', 'left' => '40', 'isLinked' => true ],
					'padding_mobile'          => [ 'unit' => 'px', 'top' => '30', 'right' => '25', 'bottom' => '30', 'left' => '25', 'isLinked' => false ],
					'content_position'        => 'center',
				],
				'elements' => [
					// FREE GUIDE 라벨
					[
						'id'         => 'ebook_card_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'FREE GUIDE',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.5, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 전자책 제목
					[
						'id'         => 'ebook_card_title1',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '디지털 비즈니스',
							'header_size'                => 'h2',
							'title_color'                => '#FFFFFF',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_weight'      => '700',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.3, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '5', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_card_title2',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '시작 가이드북',
							'header_size'                => 'h2',
							'title_color'                => '#FFFFFF',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_weight'      => '700',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.3, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 전자책 설명
					[
						'id'         => 'ebook_card_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '온라인 수익화의 전체 구조를 한눈에 파악하는 가이드',
							'header_size'                => 'h5',
							'title_color'                => '#969696',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '25', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 포함 내용 아이콘 리스트
					[
						'id'         => 'ebook_card_list',
						'elType'     => 'widget',
						'widgetType' => 'icon-list',
						'settings'   => [
							'icon_list' => [
								[
									'text'             => '온라인 비즈니스 5단계 로드맵',
									'selected_icon'    => [ 'value' => 'fas fa-check', 'library' => 'fa-solid' ],
									'_id'              => 'list_item_1',
								],
								[
									'text'             => '지식 상품 기획부터 판매까지 전체 흐름',
									'selected_icon'    => [ 'value' => 'fas fa-check', 'library' => 'fa-solid' ],
									'_id'              => 'list_item_2',
								],
								[
									'text'             => '실제 사례로 보는 수익화 구조',
									'selected_icon'    => [ 'value' => 'fas fa-check', 'library' => 'fa-solid' ],
									'_id'              => 'list_item_3',
								],
								[
									'text'             => '무료 특강 및 클래스 안내',
									'selected_icon'    => [ 'value' => 'fas fa-check', 'library' => 'fa-solid' ],
									'_id'              => 'list_item_4',
								],
							],
							'icon_color'               => '#1E75F1',
							'icon_size'                => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'text_color'               => '#CCCCCC',
							'text_indent'              => [ 'unit' => 'px', 'size' => 10, 'sizes' => [] ],
							'icon_typography_typography' => 'custom',
							'space_between'            => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'typography_typography'     => 'custom',
							'typography_font_family'    => 'Noto Sans',
							'typography_font_size'      => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'typography_font_weight'    => '400',
							'_margin'                   => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '30', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 폼 숏코드 자리
					[
						'id'         => 'ebook_hero_form',
						'elType'     => 'widget',
						'widgetType' => 'shortcode',
						'settings'   => [
							'shortcode' => '<!-- 여기에 폼 숏코드를 넣으세요. 예: [fluentform id="1"] 또는 [wpforms id="1"] -->',
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 2: Problem (화이트 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'ebook_problem',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#FFFFFF',
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '70', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 800, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'ebook_problem_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// Problem 라벨
					[
						'id'         => 'ebook_problem_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'Problem',
							'header_size'                => 'h6',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 문제 헤드라인
					[
						'id'         => 'ebook_problem_headline',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "온라인 비즈니스를 시작하려다,<br>\n오히려 더 막막해진 적 있나요?",
							'header_size'                  => 'h2',
							'align'                        => 'center',
							'title_color'                  => '#000000',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 38, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 서브 텍스트
					[
						'id'         => 'ebook_problem_sub',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '혹시 지금 이런 상태이신가요?',
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#646464',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '40', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 고민 리스트 1
					[
						'id'         => 'ebook_problem_list1',
						'elType'     => 'widget',
						'widgetType' => 'icon-list',
						'settings'   => [
							'icon_list' => [
								[
									'text'          => '무엇을 팔아야 할지, 어디서부터 시작해야 할지 모르겠습니다.',
									'selected_icon' => [ 'value' => 'fas fa-times-circle', 'library' => 'fa-solid' ],
									'_id'           => 'prob_1',
								],
								[
									'text'          => '강의를 들어도 실제로 수익을 만든 적이 없습니다.',
									'selected_icon' => [ 'value' => 'fas fa-times-circle', 'library' => 'fa-solid' ],
									'_id'           => 'prob_2',
								],
								[
									'text'          => '혼자서 하다 보니 방향이 맞는지 확신이 없습니다.',
									'selected_icon' => [ 'value' => 'fas fa-times-circle', 'library' => 'fa-solid' ],
									'_id'           => 'prob_3',
								],
								[
									'text'          => '시간은 쓰는데 성과는 나오지 않는 상태입니다.',
									'selected_icon' => [ 'value' => 'fas fa-times-circle', 'library' => 'fa-solid' ],
									'_id'           => 'prob_4',
								],
							],
							'icon_color'               => '#E04040',
							'icon_size'                => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'text_color'               => '#333333',
							'space_between'            => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_typography'     => 'custom',
							'typography_font_family'    => 'Noto Sans',
							'typography_font_size'      => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'    => '400',
							'typography_line_height'    => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
							'text_indent'              => [ 'unit' => 'px', 'size' => 12, 'sizes' => [] ],
							'_margin'                   => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '50', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 전환 메시지 1
					[
						'id'         => 'ebook_problem_msg1',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => '이건 능력의 문제가 아닙니다.',
							'header_size'                  => 'h3',
							'align'                        => 'center',
							'title_color'                  => '#1B1B1B',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 30, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '5', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 전환 메시지 2 (블루)
					[
						'id'         => 'ebook_problem_msg2',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => '전체 그림을 먼저 보지 못한 것뿐입니다.',
							'header_size'                  => 'h3',
							'align'                        => 'center',
							'title_color'                  => '#1E75F1',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 30, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 3: How It Works (다크 배경, 아이콘 박스)
	// ─────────────────────────────────────────────
	[
		'id'       => 'ebook_howitworks',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#0B0E11',
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '70', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'ebook_hiw_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// 섹션 라벨
					[
						'id'         => 'ebook_hiw_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'WHAT YOU\'LL LEARN',
							'header_size'                => 'h6',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 섹션 타이틀
					[
						'id'         => 'ebook_hiw_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "이 전자책에서<br>\n이 흐름을 정리해드립니다.",
							'header_size'                  => 'h2',
							'align'                        => 'center',
							'title_color'                  => '#FFFFFF',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 서브 설명
					[
						'id'         => 'ebook_hiw_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '전자책 한 권으로 전체 흐름을 잡고, 지금 바로 써먹을 수 있는 상태가 됩니다.',
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#646464',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 17, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '60', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// 아이콘 박스 4개 (4컬럼)
	[
		'id'       => 'ebook_steps',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '40',
			'background_background'  => 'classic',
			'background_color'       => '#0B0E11',
			'padding'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '0', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '0', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			// Step 1
			[
				'id'       => 'ebook_step1_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 25,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#161A1E',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '30', 'right' => '25', 'bottom' => '30', 'left' => '25', 'isLinked' => false ],
				],
				'elements' => [
					[
						'id'         => 'ebook_step1_num',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'       => '01',
							'header_size' => 'h6',
							'title_color' => '#1E75F1',
							'typography_typography'  => 'custom',
							'typography_font_family' => 'Noto Sans',
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight' => '700',
							'_margin'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '12', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_step1_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '전체 구조 이해',
							'header_size'                => 'h4',
							'title_color'                => '#FFFFFF',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_step1_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '온라인 비즈니스의 5단계 로드맵을 한눈에 파악합니다.',
							'header_size'                => 'p',
							'title_color'                => '#888888',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
			// Step 2
			[
				'id'       => 'ebook_step2_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 25,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#161A1E',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '30', 'right' => '25', 'bottom' => '30', 'left' => '25', 'isLinked' => false ],
				],
				'elements' => [
					[
						'id'         => 'ebook_step2_num',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'       => '02',
							'header_size' => 'h6',
							'title_color' => '#1E75F1',
							'typography_typography'  => 'custom',
							'typography_font_family' => 'Noto Sans',
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight' => '700',
							'_margin'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '12', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_step2_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '지식 상품 기획',
							'header_size'                => 'h4',
							'title_color'                => '#FFFFFF',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_step2_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '나만의 경험과 지식을 상품으로 만드는 구체적 방법을 배웁니다.',
							'header_size'                => 'p',
							'title_color'                => '#888888',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
			// Step 3
			[
				'id'       => 'ebook_step3_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 25,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#161A1E',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '30', 'right' => '25', 'bottom' => '30', 'left' => '25', 'isLinked' => false ],
				],
				'elements' => [
					[
						'id'         => 'ebook_step3_num',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'       => '03',
							'header_size' => 'h6',
							'title_color' => '#1E75F1',
							'typography_typography'  => 'custom',
							'typography_font_family' => 'Noto Sans',
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight' => '700',
							'_margin'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '12', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_step3_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '자동화 플랫폼',
							'header_size'                => 'h4',
							'title_color'                => '#FFFFFF',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_step3_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '워드프레스 + 자동화 시스템으로 수익 구조를 만듭니다.',
							'header_size'                => 'p',
							'title_color'                => '#888888',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
			// Step 4
			[
				'id'       => 'ebook_step4_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 25,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#161A1E',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '30', 'right' => '25', 'bottom' => '30', 'left' => '25', 'isLinked' => false ],
				],
				'elements' => [
					[
						'id'         => 'ebook_step4_num',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'       => '04',
							'header_size' => 'h6',
							'title_color' => '#1E75F1',
							'typography_typography'  => 'custom',
							'typography_font_family' => 'Noto Sans',
							'typography_font_size'   => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight' => '700',
							'_margin'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '12', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_step4_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '실전 수익화',
							'header_size'                => 'h4',
							'title_color'                => '#FFFFFF',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_step4_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '실제 사례를 통해 수익 구조가 어떻게 작동하는지 확인합니다.',
							'header_size'                => 'p',
							'title_color'                => '#888888',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 4: Before vs After (라이트 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'ebook_comparison',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#F8F9FA',
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '70', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'ebook_comp_header_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// REAL RESULTS 라벨
					[
						'id'         => 'ebook_comp_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'REAL RESULTS',
							'header_size'                => 'h6',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 타이틀
					[
						'id'         => 'ebook_comp_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "이걸 읽고 나면<br>\n이런 상태가 됩니다.",
							'header_size'                  => 'h2',
							'align'                        => 'center',
							'title_color'                  => '#000000',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '50', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// Before / vs / After 3컬럼
	[
		'id'       => 'ebook_bva',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '30',
			'background_background'  => 'classic',
			'background_color'       => '#F8F9FA',
			'padding'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '0', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '0', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 900, 'sizes' => [] ],
		],
		'elements' => [
			// BEFORE
			[
				'id'       => 'ebook_before_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 33,
					'_inline_size'            => 42,
					'background_background'   => 'classic',
					'background_color'        => '#FFFFFF',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '30', 'right' => '25', 'bottom' => '30', 'left' => '25', 'isLinked' => false ],
					'border_border'           => 'solid',
					'border_width'            => [ 'unit' => 'px', 'top' => '1', 'right' => '1', 'bottom' => '1', 'left' => '1', 'isLinked' => true ],
					'border_color'            => '#E5E5E5',
				],
				'elements' => [
					[
						'id'         => 'ebook_before_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'BEFORE',
							'header_size'                => 'h6',
							'title_color'                => '#AAAAAA',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.5, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '20', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_before_list',
						'elType'     => 'widget',
						'widgetType' => 'icon-list',
						'settings'   => [
							'icon_list' => [
								[
									'text'          => '온라인 수익화를 계속 미룬다',
									'selected_icon' => [ 'value' => 'fas fa-minus', 'library' => 'fa-solid' ],
									'_id'           => 'bf_1',
								],
								[
									'text'          => '뭘 팔아야 할지 결정을 못 한다',
									'selected_icon' => [ 'value' => 'fas fa-minus', 'library' => 'fa-solid' ],
									'_id'           => 'bf_2',
								],
								[
									'text'          => '강의만 모으고 실행이 없다',
									'selected_icon' => [ 'value' => 'fas fa-minus', 'library' => 'fa-solid' ],
									'_id'           => 'bf_3',
								],
								[
									'text'          => '방향 없이 시간만 쓴다',
									'selected_icon' => [ 'value' => 'fas fa-minus', 'library' => 'fa-solid' ],
									'_id'           => 'bf_4',
								],
							],
							'icon_color'               => '#CCCCCC',
							'icon_size'                => [ 'unit' => 'px', 'size' => 12, 'sizes' => [] ],
							'text_color'               => '#666666',
							'space_between'            => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'text_indent'              => [ 'unit' => 'px', 'size' => 10, 'sizes' => [] ],
							'typography_typography'     => 'custom',
							'typography_font_family'    => 'Noto Sans',
							'typography_font_size'      => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'typography_font_weight'    => '400',
						],
						'elements' => [],
					],
				],
			],
			// VS
			[
				'id'       => 'ebook_vs_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'     => 33,
					'_inline_size'     => 16,
					'content_position' => 'center',
				],
				'elements' => [
					[
						'id'         => 'ebook_vs_text',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'vs',
							'header_size'                => 'h3',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 30, 'sizes' => [] ],
							'typography_font_weight'      => '700',
						],
						'elements' => [],
					],
				],
			],
			// AFTER
			[
				'id'       => 'ebook_after_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 33,
					'_inline_size'            => 42,
					'background_background'   => 'classic',
					'background_color'        => '#FFFFFF',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '30', 'right' => '25', 'bottom' => '30', 'left' => '25', 'isLinked' => false ],
					'border_border'           => 'solid',
					'border_width'            => [ 'unit' => 'px', 'top' => '2', 'right' => '2', 'bottom' => '2', 'left' => '2', 'isLinked' => true ],
					'border_color'            => '#1E75F1',
				],
				'elements' => [
					[
						'id'         => 'ebook_after_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'AFTER',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.5, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '20', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'ebook_after_list',
						'elType'     => 'widget',
						'widgetType' => 'icon-list',
						'settings'   => [
							'icon_list' => [
								[
									'text'          => '전체 수익 구조가 머릿속에 정리된다',
									'selected_icon' => [ 'value' => 'fas fa-check', 'library' => 'fa-solid' ],
									'_id'           => 'af_1',
								],
								[
									'text'          => '무엇부터 해야 할지 명확해진다',
									'selected_icon' => [ 'value' => 'fas fa-check', 'library' => 'fa-solid' ],
									'_id'           => 'af_2',
								],
								[
									'text'          => '바로 실행할 수 있는 상태가 된다',
									'selected_icon' => [ 'value' => 'fas fa-check', 'library' => 'fa-solid' ],
									'_id'           => 'af_3',
								],
								[
									'text'          => '불필요한 시행착오를 줄인다',
									'selected_icon' => [ 'value' => 'fas fa-check', 'library' => 'fa-solid' ],
									'_id'           => 'af_4',
								],
							],
							'icon_color'               => '#1E75F1',
							'icon_size'                => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'text_color'               => '#333333',
							'space_between'            => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'text_indent'              => [ 'unit' => 'px', 'size' => 10, 'sizes' => [] ],
							'typography_typography'     => 'custom',
							'typography_font_family'    => 'Noto Sans',
							'typography_font_size'      => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'typography_font_weight'    => '500',
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 5: FAQ (화이트 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'ebook_faq',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#FFFFFF',
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '70', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 800, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'ebook_faq_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// FAQ 라벨
					[
						'id'         => 'ebook_faq_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'FAQ',
							'header_size'                => 'h6',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// FAQ 타이틀
					[
						'id'         => 'ebook_faq_title',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => '자주 묻는 질문',
							'header_size'                  => 'h2',
							'align'                        => 'center',
							'title_color'                  => '#000000',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 26, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '40', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 아코디언
					[
						'id'         => 'ebook_faq_accordion',
						'elType'     => 'widget',
						'widgetType' => 'accordion',
						'settings'   => [
							'tabs' => [
								[
									'tab_title'   => '정말 무료인가요?',
									'tab_content' => '네, 100% 무료입니다. 이메일 주소만 입력하시면 즉시 전자책을 받아보실 수 있습니다. 별도의 결제나 카드 정보 입력은 전혀 없습니다.',
									'_id'         => 'faq_1',
								],
								[
									'tab_title'   => '어떤 내용이 담겨 있나요?',
									'tab_content' => '온라인 비즈니스의 전체 구조를 5단계로 정리한 가이드입니다. 지식 상품 기획, 플랫폼 구축, 마케팅 자동화, 수익화까지의 전체 흐름을 한눈에 볼 수 있습니다.',
									'_id'         => 'faq_2',
								],
								[
									'tab_title'   => '초보자도 이해할 수 있나요?',
									'tab_content' => '네, 완전 초보자를 위해 작성되었습니다. 전문 용어를 최소화하고, 실제 사례 중심으로 설명하여 누구나 쉽게 따라갈 수 있습니다.',
									'_id'         => 'faq_3',
								],
								[
									'tab_title'   => '전자책을 받은 후 어떻게 하면 되나요?',
									'tab_content' => '전자책을 읽고 전체 흐름을 파악한 후, 더 심화된 학습을 원하시면 무료 특강이나 입문 VOD 과정을 통해 실전 역량을 키우실 수 있습니다.',
									'_id'         => 'faq_4',
								],
							],
							'title_color'                      => '#1B1B1B',
							'title_background'                 => '#F8F9FA',
							'tab_active_color'                 => '#1E75F1',
							'content_color'                    => '#646464',
							'border_color'                     => '#E5E5E5',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'content_typography_typography'     => 'custom',
							'content_typography_font_family'    => 'Noto Sans',
							'content_typography_font_size'      => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'content_typography_font_weight'    => '400',
							'content_typography_line_height'    => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 6: 최종 CTA (다크 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'ebook_final_cta',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#000000',
			'padding'               => [ 'unit' => 'px', 'top' => '120', 'right' => '0', 'bottom' => '120', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '80', 'right' => '30', 'bottom' => '80', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '60', 'right' => '20', 'bottom' => '60', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 700, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'ebook_cta_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// FREE EBOOK 라벨
					[
						'id'         => 'ebook_cta_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'FREE EBOOK',
							'header_size'                => 'h6',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// CTA 헤드라인
					[
						'id'         => 'ebook_cta_headline',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "온라인 비즈니스, 어디서부터<br>\n시작해야 할지 모르겠다면",
							'header_size'                  => 'h2',
							'align'                        => 'center',
							'title_color'                  => '#FFFFFF',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 38, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// CTA 서브
					[
						'id'         => 'ebook_cta_sub',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => "지금 바로 무료 전자책을 신청하세요.<br>\n비용 없이, 구매 권유 없이 — 전체 흐름을 먼저 확인하세요.",
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#A4A4A4',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 17, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '40', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 폼 숏코드
					[
						'id'         => 'ebook_cta_form',
						'elType'     => 'widget',
						'widgetType' => 'shortcode',
						'settings'   => [
							'shortcode' => '<!-- 여기에 폼 숏코드를 넣으세요. 예: [fluentform id="1"] 또는 [wpforms id="1"] -->',
						],
						'elements' => [],
					],
				],
			],
		],
	],
];
