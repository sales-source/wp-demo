<?php
/**
 * 회사 소개 (About Us) 페이지 — Elementor 데이터
 *
 * Kit 디자인 참고: 다크/라이트 테마, #1E75F1 블루 액센트, Noto Sans
 * Section/Column 구조 (Elementor Classic)
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return [
	// ─────────────────────────────────────────────
	// 섹션 1: Hero (다크 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'about_hero',
		'elType'   => 'section',
		'settings' => [
			'background_background'  => 'classic',
			'background_color'       => '#000000',
			'padding'                => [ 'unit' => 'px', 'top' => '120', 'right' => '0', 'bottom' => '120', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '80', 'right' => '30', 'bottom' => '80', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'margin'                 => [ 'unit' => 'px', 'top' => '0', 'right' => 0, 'bottom' => '0', 'left' => 0, 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'about_hero_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'     => 100,
					'_inline_size'     => null,
					'content_position' => 'center',
				],
				'elements' => [
					// 라벨: About Us
					[
						'id'         => 'about_hero_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'About Us',
							'header_size'                => 'h6',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'typography_line_height'      => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '20', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 메인 헤드라인
					[
						'id'         => 'about_hero_headline',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => '우리는 순서를 설계합니다.',
							'header_size'                  => 'h1',
							'align'                        => 'center',
							'title_color'                  => '#FFFFFF',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 42, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.5, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 32, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 24, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '20', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// Sub 1
					[
						'id'         => 'about_hero_sub1',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => 'AI 영상 제작이 어렵지 않습니다.',
							'header_size'                  => 'h3',
							'align'                        => 'center',
							'title_color'                  => '#FFFFFF',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'typography_font_weight'        => '400',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// Sub 2
					[
						'id'         => 'about_hero_sub2',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => '무엇부터 배워야 할지 몰라서 헤매는 것입니다.',
							'header_size'                  => 'h3',
							'align'                        => 'center',
							'title_color'                  => '#A4A4A4',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_weight'        => '400',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '10', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// Sub 3
					[
						'id'         => 'about_hero_sub3',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => '테라아이는 그 순서를 만드는 팀입니다.',
							'header_size'                  => 'h3',
							'align'                        => 'center',
							'title_color'                  => '#1E75F1',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_weight'        => '600',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 2: Our Story (화이트 배경, 2컬럼)
	// ─────────────────────────────────────────────
	[
		'id'       => 'about_story',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '20',
			'background_background'  => 'classic',
			'background_color'       => '#FFFFFF',
			'padding'                => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '70', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			// 좌측: 텍스트 영역
			[
				'id'       => 'about_story_left',
				'elType'   => 'column',
				'settings' => [
					'_column_size'     => 50,
					'_inline_size'     => null,
					'content_position' => 'center',
					'padding'          => [ 'unit' => 'px', 'top' => '0', 'right' => '30', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
					'padding_mobile'   => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '30', 'left' => '0', 'isLinked' => false ],
				],
				'elements' => [
					// OUR STORY 라벨
					[
						'id'         => 'about_story_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'OUR STORY',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'typography_line_height'      => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 헤드라인
					[
						'id'         => 'about_story_headline',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "\xe2\x80\x9c왜 배워도<br>\n결과물이 없을까?\xe2\x80\x9d",
							'header_size'                  => 'h2',
							'title_color'                  => '#000000',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 설명
					[
						'id'         => 'about_story_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '테라아이는 이 질문에서 시작했습니다. AI 툴은 넘쳐나는데, 실제로 영상 한 편을 완성한 사람은 드뭅니다.',
							'header_size'                => 'h4',
							'title_color'                => '#646464',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
			// 우측: 아이콘 박스 3개
			[
				'id'       => 'about_story_right',
				'elType'   => 'column',
				'settings' => [
					'_column_size'     => 50,
					'_inline_size'     => null,
					'content_position' => 'center',
				],
				'elements' => [
					// 아이콘 박스 1
					[
						'id'         => 'about_story_icon1',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '순서가 없었다',
							'description_text'           => '배울 건 많은데 뭐부터 해야 할지 몰라서 포기합니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#000000',
							'description_color'          => '#646464',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '25', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 아이콘 박스 2
					[
						'id'         => 'about_story_icon2',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '결과물이 없었다',
							'description_text'           => '강의는 들었지만 완성작은 없는 상태가 반복됩니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#000000',
							'description_color'          => '#646464',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '25', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 아이콘 박스 3
					[
						'id'         => 'about_story_icon3',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '경험이 없었다',
							'description_text'           => '혼자 해본 적이 없으니 자신감도 생기지 않습니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#000000',
							'description_color'          => '#646464',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 3: Mission & Values (라이트 그레이 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'about_mission',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#F8F9FA',
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '50', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '70', 'right' => '30', 'bottom' => '40', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '30', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 800, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'about_mission_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// MISSION & VALUES 라벨
					[
						'id'         => 'about_mission_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'MISSION & VALUES',
							'header_size'                => 'h6',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 헤드라인
					[
						'id'         => 'about_mission_headline',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => '우리가 존재하는 이유',
							'header_size'                  => 'h2',
							'align'                        => 'center',
							'title_color'                  => '#000000',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '20', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// Quote 1
					[
						'id'         => 'about_mission_quote1',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => "\xe2\x80\x9cAI 영상 제작은 누구나 할 수 있어야 합니다.<br>\n툴이 어려워서가 아니라, 순서가 없어서 포기하는 사람을 위해.\xe2\x80\x9d",
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#333333',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// Quote 2
					[
						'id'         => 'about_mission_quote2',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => "테라아이는 왕초보가 2주 안에 첫 영상을 완성하는 경험을 만들기 위해 존재합니다.<br>\n완성의 경험이 자신감을 만들고, 자신감이 다음 행동을 이끕니다.",
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#646464',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '50', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// Mission & Values 아이콘 박스 3컬럼
	[
		'id'       => 'about_mission_cards',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '30',
			'background_background'  => 'classic',
			'background_color'       => '#F8F9FA',
			'padding'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '0', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '0', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			// Col 1: 순서 설계
			[
				'id'       => 'about_mv_col1',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 33,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#FFFFFF',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '30', 'right' => '30', 'bottom' => '30', 'left' => '30', 'isLinked' => true ],
				],
				'elements' => [
					[
						'id'         => 'about_mv_icon1',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-route', 'library' => 'fa-solid' ],
							'title_text'                 => '순서 설계',
							'description_text'           => '무엇부터 해야 하는지 명확한 순서를 설계합니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#000000',
							'description_color'          => '#646464',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
			// Col 2: 완성 중심
			[
				'id'       => 'about_mv_col2',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 33,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#FFFFFF',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '30', 'right' => '30', 'bottom' => '30', 'left' => '30', 'isLinked' => true ],
				],
				'elements' => [
					[
						'id'         => 'about_mv_icon2',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-film', 'library' => 'fa-solid' ],
							'title_text'                 => '완성 중심',
							'description_text'           => '이론이 아닌 실제 결과물을 만드는 데 집중합니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#000000',
							'description_color'          => '#646464',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
			// Col 3: 동반 성장
			[
				'id'       => 'about_mv_col3',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 33,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#FFFFFF',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '30', 'right' => '30', 'bottom' => '30', 'left' => '30', 'isLinked' => true ],
				],
				'elements' => [
					[
						'id'         => 'about_mv_icon3',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-users', 'library' => 'fa-solid' ],
							'title_text'                 => '동반 성장',
							'description_text'           => '혼자가 아닌 함께 성장하는 구조를 만듭니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#000000',
							'description_color'          => '#646464',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 4: Our Approach (다크 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'about_approach',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#000000',
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '50', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '70', 'right' => '30', 'bottom' => '40', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '30', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 800, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'about_approach_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// OUR APPROACH 라벨
					[
						'id'         => 'about_approach_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'OUR APPROACH',
							'header_size'                => 'h6',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 헤드라인
					[
						'id'         => 'about_approach_headline',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "다른 강의와<br>\n무엇이 다른가요.",
							'header_size'                  => 'h2',
							'align'                        => 'center',
							'title_color'                  => '#FFFFFF',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 설명
					[
						'id'         => 'about_approach_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '기능 나열이 아닌, 실제로 결과물이 나오는 방식으로 가르칩니다.',
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#646464',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 17, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '60', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// Approach: DIFFERENCE 01 & 02 (2컬럼)
	[
		'id'       => 'about_approach_row1',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '20',
			'background_background'  => 'classic',
			'background_color'       => '#000000',
			'padding'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '20', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '0', 'right' => '30', 'bottom' => '20', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '0', 'right' => '20', 'bottom' => '20', 'left' => '20', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			// DIFFERENCE 01
			[
				'id'       => 'about_diff1_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 50,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#0E0E0E',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '25', 'right' => '25', 'bottom' => '25', 'left' => '25', 'isLinked' => true ],
				],
				'elements' => [
					// DIFFERENCE 01 라벨
					[
						'id'         => 'about_diff1_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'DIFFERENCE 01',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 아이콘 박스
					[
						'id'         => 'about_diff1_iconbox',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '순서가 있습니다',
							'description_text'           => '뭘 배울지가 아니라, 어떤 순서로 해야 결과가 나오는지를 알려줍니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#FFFFFF',
							'description_color'          => '#888888',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
			// DIFFERENCE 02
			[
				'id'       => 'about_diff2_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 50,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#0E0E0E',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '25', 'right' => '25', 'bottom' => '25', 'left' => '25', 'isLinked' => true ],
				],
				'elements' => [
					// DIFFERENCE 02 라벨
					[
						'id'         => 'about_diff2_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'DIFFERENCE 02',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 아이콘 박스
					[
						'id'         => 'about_diff2_iconbox',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '결과물이 남습니다',
							'description_text'           => '강의를 듣고 끝이 아니라, 매주 실제 영상을 완성합니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#FFFFFF',
							'description_color'          => '#888888',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// Approach: DIFFERENCE 03 & 04 (2컬럼)
	[
		'id'       => 'about_approach_row2',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '20',
			'background_background'  => 'classic',
			'background_color'       => '#000000',
			'padding'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '0', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '0', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			// DIFFERENCE 03
			[
				'id'       => 'about_diff3_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 50,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#0E0E0E',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '25', 'right' => '25', 'bottom' => '25', 'left' => '25', 'isLinked' => true ],
				],
				'elements' => [
					// DIFFERENCE 03 라벨
					[
						'id'         => 'about_diff3_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'DIFFERENCE 03',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 아이콘 박스
					[
						'id'         => 'about_diff3_iconbox',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '1:1 피드백',
							'description_text'           => '막히는 순간마다 직접 물어볼 수 있습니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#FFFFFF',
							'description_color'          => '#888888',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
			// DIFFERENCE 04
			[
				'id'       => 'about_diff4_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 50,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#0E0E0E',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '25', 'right' => '25', 'bottom' => '25', 'left' => '25', 'isLinked' => true ],
				],
				'elements' => [
					// DIFFERENCE 04 라벨
					[
						'id'         => 'about_diff4_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'DIFFERENCE 04',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 아이콘 박스
					[
						'id'         => 'about_diff4_iconbox',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '실전 중심',
							'description_text'           => '이론 최소화. 바로 써먹을 수 있는 방법만 알려줍니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#FFFFFF',
							'description_color'          => '#888888',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 5: Real Results (블루 그레이 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'about_results',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#EBF1F6',
			'padding'               => [ 'unit' => 'px', 'top' => '100', 'right' => '0', 'bottom' => '50', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '70', 'right' => '30', 'bottom' => '40', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '50', 'right' => '20', 'bottom' => '30', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 800, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'about_results_header_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// REAL RESULTS 라벨
					[
						'id'         => 'about_results_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'REAL RESULTS',
							'header_size'                => 'h6',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 헤드라인
					[
						'id'         => 'about_results_headline',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "아무것도 몰랐는데,<br>\n이런 변화가 생겼습니다.",
							'header_size'                  => 'h2',
							'align'                        => 'center',
							'title_color'                  => '#000000',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '50', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// Real Results 카드 3컬럼
	[
		'id'       => 'about_results_cards',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '30',
			'background_background'  => 'classic',
			'background_color'       => '#EBF1F6',
			'padding'                => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '50', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '0', 'right' => '30', 'bottom' => '40', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '0', 'right' => '20', 'bottom' => '30', 'left' => '20', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			// Col 1
			[
				'id'       => 'about_result_col1',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 33,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#FFFFFF',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '25', 'right' => '25', 'bottom' => '25', 'left' => '25', 'isLinked' => true ],
				],
				'elements' => [
					[
						'id'         => 'about_result1_heading',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'BEFORE → AFTER',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'about_result1_iconbox',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '포기 반복 → 첫 영상 완성',
							'description_text'           => '혼자 시도만 하다 포기했지만, 체계적 순서로 첫 영상을 완성했습니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#000000',
							'description_color'          => '#646464',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
			// Col 2
			[
				'id'       => 'about_result_col2',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 33,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#FFFFFF',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '25', 'right' => '25', 'bottom' => '25', 'left' => '25', 'isLinked' => true ],
				],
				'elements' => [
					[
						'id'         => 'about_result2_heading',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'BEFORE → AFTER',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'about_result2_iconbox',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '툴 공포 → 자유자재',
							'description_text'           => 'AI 툴이 두려웠지만, 3가지 핵심 툴만으로 자유롭게 제작합니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#000000',
							'description_color'          => '#646464',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
			// Col 3
			[
				'id'       => 'about_result_col3',
				'elType'   => 'column',
				'settings' => [
					'_column_size'            => 33,
					'_inline_size'            => null,
					'background_background'   => 'classic',
					'background_color'        => '#FFFFFF',
					'border_radius'           => [ 'unit' => 'px', 'top' => '16', 'right' => '16', 'bottom' => '16', 'left' => '16', 'isLinked' => true ],
					'padding'                 => [ 'unit' => 'px', 'top' => '25', 'right' => '25', 'bottom' => '25', 'left' => '25', 'isLinked' => true ],
				],
				'elements' => [
					[
						'id'         => 'about_result3_heading',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => 'BEFORE → AFTER',
							'header_size'                => 'h6',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '600',
							'typography_letter_spacing'   => [ 'unit' => 'px', 'size' => 1.2, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					[
						'id'         => 'about_result3_iconbox',
						'elType'     => 'widget',
						'widgetType' => 'icon-box',
						'settings'   => [
							'selected_icon'              => [ 'value' => 'fas fa-exclamation-circle', 'library' => 'fa-solid' ],
							'title_text'                 => '방향 없음 → 로드맵 확보',
							'description_text'           => '무엇을 해야 할지 몰랐지만, 이제 명확한 방향이 있습니다.',
							'icon_color'                 => '#1E75F1',
							'title_color'                => '#000000',
							'description_color'          => '#646464',
							'title_typography_typography'       => 'custom',
							'title_typography_font_family'      => 'Noto Sans',
							'title_typography_font_size'        => [ 'unit' => 'px', 'size' => 18, 'sizes' => [] ],
							'title_typography_font_weight'      => '600',
							'description_typography_typography'       => 'custom',
							'description_typography_font_family'      => 'Noto Sans',
							'description_typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'description_typography_font_weight'      => '400',
							'description_typography_line_height'      => [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ],
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// Stats 3컬럼
	[
		'id'       => 'about_stats',
		'elType'   => 'section',
		'settings' => [
			'structure'              => '30',
			'background_background'  => 'classic',
			'background_color'       => '#EBF1F6',
			'padding'                => [ 'unit' => 'px', 'top' => '30', 'right' => '0', 'bottom' => '100', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'         => [ 'unit' => 'px', 'top' => '20', 'right' => '30', 'bottom' => '70', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'         => [ 'unit' => 'px', 'top' => '20', 'right' => '20', 'bottom' => '50', 'left' => '20', 'isLinked' => false ],
			'content_width'          => [ 'unit' => 'px', 'size' => 1138, 'sizes' => [] ],
		],
		'elements' => [
			// Stat 1: 350명+
			[
				'id'       => 'about_stat1_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size' => 33,
					'_inline_size' => null,
				],
				'elements' => [
					// 숫자
					[
						'id'         => 'about_stat1_num',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '350',
							'header_size'                => 'h2',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 48, 'sizes' => [] ],
							'typography_font_weight'      => '700',
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 단위
					[
						'id'         => 'about_stat1_unit',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '명+',
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#000000',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '5', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 라벨
					[
						'id'         => 'about_stat1_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '누적수강생',
							'header_size'                => 'p',
							'align'                      => 'center',
							'title_color'                => '#888888',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '400',
						],
						'elements' => [],
					],
				],
			],
			// Stat 2: 50%
			[
				'id'       => 'about_stat2_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size' => 33,
					'_inline_size' => null,
				],
				'elements' => [
					// 숫자
					[
						'id'         => 'about_stat2_num',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '50',
							'header_size'                => 'h2',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 48, 'sizes' => [] ],
							'typography_font_weight'      => '700',
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 단위
					[
						'id'         => 'about_stat2_unit',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '%',
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#000000',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '5', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 라벨
					[
						'id'         => 'about_stat2_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '미션 완료율',
							'header_size'                => 'p',
							'align'                      => 'center',
							'title_color'                => '#888888',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '400',
						],
						'elements' => [],
					],
				],
			],
			// Stat 3: 3일 이내
			[
				'id'       => 'about_stat3_col',
				'elType'   => 'column',
				'settings' => [
					'_column_size' => 33,
					'_inline_size' => null,
				],
				'elements' => [
					// 숫자
					[
						'id'         => 'about_stat3_num',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '3일',
							'header_size'                => 'h2',
							'align'                      => 'center',
							'title_color'                => '#1E75F1',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 48, 'sizes' => [] ],
							'typography_font_weight'      => '700',
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 36, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 단위
					[
						'id'         => 'about_stat3_unit',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '이내',
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#000000',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 20, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '5', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// 라벨
					[
						'id'         => 'about_stat3_label',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => '첫 영상 제작',
							'header_size'                => 'p',
							'align'                      => 'center',
							'title_color'                => '#888888',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 14, 'sizes' => [] ],
							'typography_font_weight'      => '400',
						],
						'elements' => [],
					],
				],
			],
		],
	],

	// ─────────────────────────────────────────────
	// 섹션 6: Final CTA (다크 배경)
	// ─────────────────────────────────────────────
	[
		'id'       => 'about_final_cta',
		'elType'   => 'section',
		'settings' => [
			'background_background' => 'classic',
			'background_color'      => '#000000',
			'padding'               => [ 'unit' => 'px', 'top' => '120', 'right' => '0', 'bottom' => '120', 'left' => '0', 'isLinked' => false ],
			'padding_tablet'        => [ 'unit' => 'px', 'top' => '80', 'right' => '30', 'bottom' => '80', 'left' => '30', 'isLinked' => false ],
			'padding_mobile'        => [ 'unit' => 'px', 'top' => '60', 'right' => '20', 'bottom' => '60', 'left' => '20', 'isLinked' => false ],
			'content_width'         => [ 'unit' => 'px', 'size' => 700, 'sizes' => [] ],
		],
		'elements' => [
			[
				'id'       => 'about_cta_col',
				'elType'   => 'column',
				'settings' => [ '_column_size' => 100, '_inline_size' => null ],
				'elements' => [
					// CTA 헤드라인
					[
						'id'         => 'about_cta_headline',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                        => "무료 전자책 부터 보고<br>\n결정하셔도 늦지 않습니다.",
							'header_size'                  => 'h2',
							'align'                        => 'center',
							'title_color'                  => '#FFFFFF',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 38, 'sizes' => [] ],
							'typography_font_weight'        => '700',
							'typography_line_height'        => [ 'unit' => 'em', 'size' => 1.4, 'sizes' => [] ],
							'typography_font_size_tablet'   => [ 'unit' => 'px', 'size' => 28, 'sizes' => [] ],
							'typography_font_size_mobile'   => [ 'unit' => 'px', 'size' => 22, 'sizes' => [] ],
							'_margin'                       => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '15', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// CTA 설명
					[
						'id'         => 'about_cta_desc',
						'elType'     => 'widget',
						'widgetType' => 'heading',
						'settings'   => [
							'title'                      => "테라아이의 제작 방식을 먼저 확인하세요.<br>\n어떤 흐름인지, 나에게 맞는지 — 다 보여드립니다.",
							'header_size'                => 'h4',
							'align'                      => 'center',
							'title_color'                => '#A4A4A4',
							'typography_typography'       => 'custom',
							'typography_font_family'      => 'Noto Sans',
							'typography_font_size'        => [ 'unit' => 'px', 'size' => 17, 'sizes' => [] ],
							'typography_font_weight'      => '400',
							'typography_line_height'      => [ 'unit' => 'em', 'size' => 1.7, 'sizes' => [] ],
							'typography_font_size_mobile' => [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ],
							'_margin'                     => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '40', 'left' => '0', 'isLinked' => false ],
						],
						'elements' => [],
					],
					// CTA 버튼
					[
						'id'         => 'about_cta_button',
						'elType'     => 'widget',
						'widgetType' => 'button',
						'settings'   => [
							'text'                         => '무료 전자책 신청하기',
							'link'                         => [ 'url' => '/freepdf/', 'is_external' => '', 'nofollow' => '' ],
							'align'                        => 'center',
							'size'                         => 'lg',
							'button_text_color'            => '#FFFFFF',
							'background_color'             => '#1E75F1',
							'border_radius'                => [ 'unit' => 'px', 'top' => '8', 'right' => '8', 'bottom' => '8', 'left' => '8', 'isLinked' => true ],
							'button_hover_color'           => '#FFFFFF',
							'button_background_hover_color' => '#1565D8',
							'typography_typography'         => 'custom',
							'typography_font_family'        => 'Noto Sans',
							'typography_font_size'          => [ 'unit' => 'px', 'size' => 16, 'sizes' => [] ],
							'typography_font_weight'        => '600',
						],
						'elements' => [],
					],
				],
			],
		],
	],
];
