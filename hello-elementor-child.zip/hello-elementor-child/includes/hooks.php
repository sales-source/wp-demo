<?php
/**
 * 커스텀 훅 및 필터 정의
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 테마 활성화 시 초기 설정
 * - 카카오 로그인 페이지 자동 생성
 * - WooCommerce 체크아웃/장바구니를 클래식 숏코드로 전환
 */
add_action( 'after_switch_theme', 'hello_child_setup_theme' );
function hello_child_setup_theme() {
	// 플러그인 설치는 무거우므로 admin_init으로 지연 실행
	set_transient( 'hello_child_needs_plugin_install', true, 300 );

	$steps = array(
		'hello_child_configure_locale',
		'hello_child_create_login_page',
		'hello_child_ensure_classic_checkout',
		'hello_child_configure_woocommerce',
		'hello_child_complete_wc_onboarding',
		'hello_child_set_accent_color',
		'hello_child_create_pg_shop',
		'hello_child_create_vod_products',
		'hello_child_create_freepdf_product',
		'hello_child_create_menus',
		'hello_child_disable_elementor_defaults',
		'hello_child_create_auto_content',
		'hello_child_create_blog_archive_page',
		'hello_child_set_full_width_layout',
		'hello_child_assign_policy_pages',
	);

	foreach ( $steps as $step ) {
		try {
			if ( function_exists( $step ) ) {
				$step();
			}
		} catch ( \Throwable $e ) {
			error_log( 'Hello Child Theme setup: ' . $step . ' failed — ' . $e->getMessage() );
		}
	}

	flush_rewrite_rules();
}

/**
 * 플러그인 설치를 admin_init에서 지연 실행 (활성화 500 에러 방지)
 */
add_action( 'admin_init', 'hello_child_deferred_plugin_install' );
function hello_child_deferred_plugin_install() {
	if ( ! get_transient( 'hello_child_needs_plugin_install' ) ) {
		return;
	}
	delete_transient( 'hello_child_needs_plugin_install' );

	try {
		hello_child_install_required_plugins();
	} catch ( \Throwable $e ) {
		error_log( 'Hello Child Theme: plugin install failed — ' . $e->getMessage() );
	}

	// 플러그인 설치 후 WC 의존 설정 재실행
	if ( class_exists( 'WooCommerce' ) ) {
		hello_child_ensure_classic_checkout();
		hello_child_configure_woocommerce();
		hello_child_complete_wc_onboarding();
		hello_child_create_pg_shop();
		hello_child_create_vod_products();
		hello_child_create_freepdf_product();
		hello_child_create_menus();
	}

	// elementor 설치 직후 onboarding 차단
	hello_child_skip_elementor_onboarding();

	// 검수 미통과 #91: 플러그인/세팅 설치 직후 현재 admin 요청은 이미 헤더가
	// 일부 출력된 상태라 새 대시보드/세팅이 반영되지 않음 → 사용자가 수동으로
	// 새로고침을 한 번 해야 함. 이를 자동화하기 위해 1회성 redirect를 건다.
	if ( ! wp_doing_ajax() && ! headers_sent() && is_admin() ) {
		set_transient( 'hello_child_post_install_redirect', true, 30 );
		wp_safe_redirect( admin_url() );
		exit;
	}
}

/**
 * 첫 활성화 후 자동 redirect로 도착한 admin 페이지에서 1회 안내 표시
 */
add_action( 'admin_notices', 'hello_child_post_install_notice' );
function hello_child_post_install_notice() {
	if ( ! get_transient( 'hello_child_post_install_redirect' ) ) {
		return;
	}
	delete_transient( 'hello_child_post_install_redirect' );
	echo '<div class="notice notice-success is-dismissible"><p><strong>Hello Elementor Child:</strong> 테마 자동 설정이 완료되었습니다.</p></div>';
}

/**
 * admin_init에서 누락된 setup 항목 자동 복구
 *
 * 첫 활성화 시 일부 함수가 실패했거나 의존 플러그인이 늦게 로드된 경우,
 * 매 admin 요청마다 한 번씩 누락 여부를 체크해 복구한다.
 */
add_action( 'admin_init', 'hello_child_ensure_setup', 10 );
function hello_child_ensure_setup() {
	if ( wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}

	// 1. 메뉴 누락 또는 중복 감지 → 재생성/정리
	// 검수 미통과 #134: 메뉴가 이미 존재하지만 동명 term 복수 또는 항목 중복인
	// 케이스에서도 create_menus() 의 dedup 로직이 타도록 가드 확장.
	$needs_menu_sync = false;

	if ( ! wp_get_nav_menu_object( '주메뉴' ) || ! wp_get_nav_menu_object( '푸터메뉴' ) ) {
		$needs_menu_sync = true;
	} else {
		// 동명 nav_menu term 복수 여부
		foreach ( array( '주메뉴', '푸터메뉴' ) as $menu_name_check ) {
			$dupe_terms = get_terms( array(
				'taxonomy'   => 'nav_menu',
				'name'       => $menu_name_check,
				'hide_empty' => false,
			) );
			if ( ! is_wp_error( $dupe_terms ) && is_array( $dupe_terms ) && count( $dupe_terms ) > 1 ) {
				$needs_menu_sync = true;
				break;
			}
		}

		// 푸터메뉴 항목 URL 중복 여부
		if ( ! $needs_menu_sync ) {
			$footer_menu_obj = wp_get_nav_menu_object( '푸터메뉴' );
			if ( $footer_menu_obj ) {
				$footer_items = wp_get_nav_menu_items( $footer_menu_obj->term_id );
				if ( is_array( $footer_items ) ) {
					$seen_paths = array();
					foreach ( $footer_items as $fi ) {
						$p = wp_parse_url( (string) $fi->url, PHP_URL_PATH );
						$p = $p ? rtrim( $p, '/' ) . '/' : '';
						if ( $p && isset( $seen_paths[ $p ] ) ) {
							$needs_menu_sync = true;
							break;
						}
						$seen_paths[ $p ] = true;
					}
				}
			}
		}

		// LMS 플러그인 상태와 주메뉴 실제 상태 어긋남 감지 (안전망)
		// - 플러그인 활성인데 소개/클래스룸/커뮤니티/캘린더 중 누락 → 재생성
		// - 플러그인 비활성인데 해당 항목 잔존 → 정리
		if ( ! $needs_menu_sync ) {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				include_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$lms_on   = class_exists( 'Terra_LMS_Public' )
				|| is_plugin_active( 'terra-lms/terra-lms.php' );
			$main_obj = wp_get_nav_menu_object( '주메뉴' );
			if ( $main_obj ) {
				$main_items   = wp_get_nav_menu_items( $main_obj->term_id );
				$lms_paths    = array( '/about/', '/classroom/', '/community/', '/calendar/' );
				$found_paths  = array();
				if ( is_array( $main_items ) ) {
					foreach ( $main_items as $mi ) {
						$p = wp_parse_url( (string) $mi->url, PHP_URL_PATH );
						$p = $p ? '/' . trim( $p, '/' ) . '/' : '';
						if ( in_array( $p, $lms_paths, true ) ) {
							$found_paths[ $p ] = true;
						}
					}
				}
				$found_count = count( $found_paths );
				if ( $lms_on && $found_count < 4 ) {
					$needs_menu_sync = true;
				} elseif ( ! $lms_on && $found_count > 0 ) {
					$needs_menu_sync = true;
				}
			}
		}
	}

	if ( $needs_menu_sync ) {
		try {
			hello_child_create_menus();
		} catch ( \Throwable $e ) {
			error_log( 'Hello Child ensure_setup: menus failed — ' . $e->getMessage() );
		}
	}

	// 2. WC 활성 + PG 카테고리/페이지 누락 → 재생성 (샘플 상품은 생성 안 함)
	if ( class_exists( 'WooCommerce' ) ) {
		$pg_term = get_term_by( 'slug', 'pg', 'product_cat' );
		$pg_page = get_page_by_path( 'pg-shop' );
		if ( ! $pg_term || ! $pg_page ) {
			try { hello_child_create_pg_shop(); }
			catch ( \Throwable $e ) { error_log( 'Hello Child: pg_shop failed — ' . $e->getMessage() ); }
		}

		// 2-1. PG 샘플 상품(HTML/CSS, JS, WordPress)이 잔존하면 항상 cleanup
		$pg_samples_check = get_posts( array(
			'post_type'   => 'product',
			'title'       => 'HTML/CSS 웹 퍼블리싱 입문',
			'numberposts' => 1,
			'post_status' => array( 'publish', 'draft' ),
		) );
		if ( ! empty( $pg_samples_check ) ) {
			try { hello_child_cleanup_pg_sample_products(); }
			catch ( \Throwable $e ) { error_log( 'Hello Child: pg cleanup failed — ' . $e->getMessage() ); }
		}

		// VOD 샘플 상품은 1회성 — 영속 옵션 플래그로 가드.
		// 운영자가 샘플을 휴지통/비공개 처리해도 다시 생성되지 않도록 함.
		if ( ! get_option( 'hello_child_vod_samples_created' ) ) {
			$vod_exists = get_posts( array(
				'post_type'   => 'product',
				'post_status' => 'any',
				'meta_key'    => '_hello_child_vod_sample',
				'meta_value'  => '1',
				'numberposts' => 1,
			) );
			if ( empty( $vod_exists ) ) {
				try { hello_child_create_vod_products(); }
				catch ( \Throwable $e ) { error_log( 'Hello Child: vod failed — ' . $e->getMessage() ); }
			}
			update_option( 'hello_child_vod_samples_created', 1, false );
		}

		// freepdf 상품도 1회성 플래그로 가드
		if ( ! get_option( 'hello_child_freepdf_created' ) ) {
			$freepdf_term = get_term_by( 'slug', 'freepdf', 'product_cat' );
			if ( ! $freepdf_term ) {
				try { hello_child_create_freepdf_product(); }
				catch ( \Throwable $e ) { error_log( 'Hello Child: freepdf failed — ' . $e->getMessage() ); }
			}
			update_option( 'hello_child_freepdf_created', 1, false );
		}
	}

	// 3. 자동 콘텐츠(블로그 글) 누락 → 재생성
	// 영속 플래그가 있으면 스킵 (#167 VOD 패턴). status='any'로 trash/draft 포함 검사.
	if ( ! get_option( 'hello_child_auto_content_created' ) ) {
		$auto_content = get_posts( array(
			'post_type'   => 'post',
			'post_status' => 'any',
			'meta_key'    => '_hello_child_auto_content',
			'meta_value'  => '1',
			'numberposts' => 1,
		) );
		if ( empty( $auto_content ) ) {
			try { hello_child_create_auto_content(); }
			catch ( \Throwable $e ) { error_log( 'Hello Child: auto_content failed — ' . $e->getMessage() ); }
		} else {
			update_option( 'hello_child_auto_content_created', 1, false );
		}
	}

	// 3-1. Hello world! 기본 글이 남아있으면 정리
	$hello_world = get_posts( array(
		'name'        => 'hello-world',
		'post_type'   => 'post',
		'post_status' => array( 'publish', 'draft' ),
		'numberposts' => 1,
	) );
	if ( ! empty( $hello_world ) && function_exists( 'hello_child_remove_hello_world_post' ) ) {
		try { hello_child_remove_hello_world_post(); }
		catch ( \Throwable $e ) { error_log( 'Hello Child: hello_world failed — ' . $e->getMessage() ); }
	}

	// 4. 블로그 모음 페이지 누락 → 재생성
	if ( ! get_page_by_path( 'blogs' ) ) {
		try { hello_child_create_blog_archive_page(); }
		catch ( \Throwable $e ) { error_log( 'Hello Child: blog_archive failed — ' . $e->getMessage() ); }
	}

	// 5. 정책 페이지 미지정/잘못 지정 → 자동 재지정 + Draft 정리
	// 검수 미통과 #114, #116, #117, #119: WP/WC가 기본 Draft 페이지를 만들고 자동
	// 지정해버리는 케이스가 있어, "현재 지정값이 우리 /privacy·/terms와 일치하는지"
	// + "Draft가 잔존하는지" 양쪽을 매번 검사한다.
	$needs_policy_run = false;

	$privacy_id      = (int) get_option( 'wp_page_for_privacy_policy', 0 );
	$privacy_page    = get_page_by_path( 'privacy' );
	if ( ! $privacy_id || ! get_post( $privacy_id ) ) {
		$needs_policy_run = true;
	} elseif ( $privacy_page && (int) $privacy_id !== (int) $privacy_page->ID ) {
		$needs_policy_run = true;
	}

	if ( ! $needs_policy_run && class_exists( 'WooCommerce' ) ) {
		$terms_id   = (int) get_option( 'woocommerce_terms_page_id', 0 );
		$terms_page = get_page_by_path( 'terms' );
		if ( $terms_page && (int) $terms_id !== (int) $terms_page->ID ) {
			$needs_policy_run = true;
		}
	}

	if ( ! $needs_policy_run ) {
		// Draft 잔존 검사 (privacy-policy / refund_returns)
		$wp_default_privacy = get_page_by_path( 'privacy-policy' );
		if ( $wp_default_privacy && 'draft' === $wp_default_privacy->post_status ) {
			$needs_policy_run = true;
		}
		if ( ! $needs_policy_run ) {
			foreach ( array( 'refund_returns', 'refund-returns', 'refund-and-returns-policy' ) as $slug ) {
				$page = get_page_by_path( $slug );
				if ( $page && 'draft' === $page->post_status ) {
					$needs_policy_run = true;
					break;
				}
			}
		}
	}

	if ( $needs_policy_run ) {
		try { hello_child_assign_policy_pages(); }
		catch ( \Throwable $e ) { error_log( 'Hello Child: policy_pages failed — ' . $e->getMessage() ); }
	}

	// 6. WC 온보딩 미완료 → 자동 완료
	if ( class_exists( 'WooCommerce' ) && 'yes' !== get_option( 'woocommerce_task_list_hidden', 'no' ) ) {
		try { hello_child_complete_wc_onboarding(); }
		catch ( \Throwable $e ) { error_log( 'Hello Child: wc_onboarding failed — ' . $e->getMessage() ); }
	}

	// 7. Elementor onboarded 미설정 → 차단
	if ( 'yes' !== get_option( 'elementor_onboarded', '' ) ) {
		try { hello_child_skip_elementor_onboarding(); }
		catch ( \Throwable $e ) { error_log( 'Hello Child: elementor_onboarding failed — ' . $e->getMessage() ); }
	}
}

/**
 * Elementor 첫 로드 시 onboarding 화면 자동 스킵
 *
 * child 활성화 직후 elementor가 자동으로 onboarding wizard를 띄우는 것을 방지.
 * 미리 onboarded 옵션을 설정해 redirect 자체를 차단.
 */
add_action( 'activated_plugin', 'hello_child_skip_elementor_onboarding', 5 );
add_action( 'after_switch_theme', 'hello_child_skip_elementor_onboarding', 5 );
function hello_child_skip_elementor_onboarding( $plugin = '' ) {
	// elementor가 처음 활성화될 때 onboarding redirect 차단
	update_option( 'elementor_onboarded', 'yes' );
	delete_transient( 'elementor_activation_redirect' );

	// 첫 활성화 wizard 스킵
	if ( false === get_option( '_elementor_installed_time' ) ) {
		update_option( '_elementor_installed_time', time() );
	}
}

/**
 * elementor-app#onboarding 페이지 진입 시 wp-admin으로 redirect
 *
 * skip_elementor_onboarding 옵션이 무시되는 케이스 대비.
 */
add_action( 'admin_init', 'hello_child_block_elementor_onboarding_page', 1 );
function hello_child_block_elementor_onboarding_page() {
	if ( ! is_admin() || wp_doing_ajax() ) {
		return;
	}
	if ( isset( $_GET['page'] ) && 'elementor-app' === $_GET['page'] ) {
		// onboarding hash 또는 onboarding action일 때만 차단
		if ( ! isset( $_GET['onboarding_skip'] ) && ( ! isset( $_GET['action'] ) || empty( $_GET['action'] ) ) ) {
			update_option( 'elementor_onboarded', 'yes' );
			wp_safe_redirect( admin_url() );
			exit;
		}
	}
}

/**
 * WooCommerce 온보딩 가이드 모든 단계 완료 처리
 *
 * 검수자 요청: "온보딩 가이드 모든 체크 해제되어야 하는데 일부 체크됨" — 즉, 일부만
 * 체크된 어중간한 상태가 보임. 모두 완료(=hidden) 처리해서 가이드 자체가 안 뜨도록 함.
 */
function hello_child_complete_wc_onboarding() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	// 태스크 리스트 숨김
	update_option( 'woocommerce_task_list_hidden', 'yes' );
	update_option( 'woocommerce_extended_task_list_hidden', 'yes' );
	update_option( 'woocommerce_task_list_complete', 'yes' );
	update_option( 'woocommerce_task_list_dismissed_tasks', wp_json_encode( array( 'setup' ) ) );

	// 온보딩 프로필 — completed 표시
	$profile = get_option( 'woocommerce_onboarding_profile', array() );
	if ( ! is_array( $profile ) ) {
		$profile = array();
	}
	$profile = array_merge( $profile, array(
		'completed'           => true,
		'skipped'             => true,
		'industry'            => array( array( 'slug' => 'education' ) ),
		'product_types'       => array( 'downloads' ),
		'product_count'       => '1-10',
		'selling_venues'      => 'no',
		'business_extensions' => array(),
		'theme'               => 'hello-elementor-child',
		'setup_client'        => false,
	) );
	update_option( 'woocommerce_onboarding_profile', $profile );

	// 각 task 완료 처리
	$completed_tasks = array(
		'store_details', 'products', 'woocommerce-payments', 'payments', 'tax',
		'shipping', 'marketing', 'appearance', 'purchase',
	);
	foreach ( $completed_tasks as $task ) {
		update_option( 'woocommerce_task_' . $task . '_completed', 'yes' );
	}

	// admin 노트 무시
	update_option( 'woocommerce_show_marketplace_suggestions', 'no' );
	update_option( 'woocommerce_admin_notices', array() );

	// 영업 시작 모드 활성화 (Coming Soon 비활성화)
	update_option( 'woocommerce_coming_soon', 'no' );
}

/**
 * 사이트 강조색 자동 설정 (Customizer accent color)
 *
 * 검수자 요청: 온보딩 사이트 정보 상단 강조색 지정 필드 반영 안 됨
 */
function hello_child_set_accent_color() {
	$accent = '#0064FF';

	// hello-elementor 부모 테마 customizer
	set_theme_mod( 'hello_elementor_accent_color', $accent );

	// WC store/site color
	update_option( 'woocommerce_demo_store', 'no' );

	// WP customizer header_textcolor
	set_theme_mod( 'header_textcolor', '191F28' );

	// hello-elementor color scheme
	set_theme_mod( 'hello_elementor_link_color', $accent );
	set_theme_mod( 'hello_elementor_link_hover_color', '#0050CC' );
	set_theme_mod( 'hello_elementor_button_background_color', $accent );
}

/**
 * 한국어 기본 언어 강제 설정 (admin_init에서 재시도)
 *
 * after_switch_theme의 hello_child_configure_locale가 첫 활성화 시 실패할 수 있어
 * admin_init에서 재시도하여 ko_KR 적용을 보장한다.
 *
 * 검수 미통과 #115: Cloudways 등 일부 환경에서 wp_install_language()가 silent
 * fail하여 옵션은 ko_KR이지만 실제 언어팩이 없어 영어로 표시되는 케이스 대응.
 * → wp_download_language_pack()으로 명시적으로 언어팩 다운로드 + locale 필터 폴백.
 */
add_action( 'admin_init', 'hello_child_force_korean_locale', 5 );
function hello_child_force_korean_locale() {
	// 옵션 항상 ko_KR로 강제 (값이 다르면 갱신)
	if ( 'ko_KR' !== get_option( 'WPLANG', '' ) ) {
		update_option( 'WPLANG', 'ko_KR' );
	}

	// 언어팩이 이미 설치되어 있으면 (mo 파일 존재) 재다운로드 불필요
	$ko_mo = WP_LANG_DIR . '/ko_KR.mo';
	if ( file_exists( $ko_mo ) ) {
		return;
	}

	// 언어팩 다운로드 (translation-install.php 로드 필수)
	if ( ! function_exists( 'wp_download_language_pack' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/translation-install.php';
	}

	if ( function_exists( 'wp_download_language_pack' ) ) {
		try {
			wp_download_language_pack( 'ko_KR' );
		} catch ( \Throwable $e ) {
			error_log( 'Hello Child: ko_KR download failed — ' . $e->getMessage() );
		}
	}

	// fallback: wp_install_language도 시도
	if ( function_exists( 'wp_install_language' ) ) {
		try {
			wp_install_language( 'ko_KR' );
		} catch ( \Throwable $e ) {
			// silent
		}
	}

	// WC 언어팩
	if ( class_exists( 'WooCommerce' ) && function_exists( 'wp_download_language_pack' ) ) {
		try { wp_download_language_pack( 'ko_KR' ); }
		catch ( \Throwable $e ) { /* silent */ }
	}
}

/**
 * 언어팩 미설치 시 최종 폴백: locale 필터로 ko_KR 강제
 *
 * wp_download_language_pack까지 실패하여 ko_KR.mo가 없는 환경에서도
 * 최소한 옵션이 ko_KR인 동안에는 get_locale()이 ko_KR을 반환하도록 한다.
 */
add_filter( 'locale', 'hello_child_force_locale_filter', 99 );
function hello_child_force_locale_filter( $locale ) {
	if ( 'ko_KR' === get_option( 'WPLANG', '' ) ) {
		return 'ko_KR';
	}
	return $locale;
}

/**
 * WooCommerce가 테마 활성화 이후에 설치/활성화된 경우,
 * 미완료된 WC 의존 setup을 재실행한다.
 */
add_action( 'activated_plugin', 'hello_child_on_wc_activated' );
function hello_child_on_wc_activated( $plugin ) {
	if ( 'woocommerce/woocommerce.php' !== $plugin ) {
		return;
	}

	hello_child_ensure_classic_checkout();
	hello_child_configure_woocommerce();
	hello_child_create_pg_shop();
	hello_child_create_vod_products();
	hello_child_create_freepdf_product();
	hello_child_create_menus();
}

/**
 * Terra LMS 플러그인 활성/비활성 시 주메뉴 동기화
 *
 * 활성: 소개/클래스룸/커뮤니티/캘린더 메뉴 항목 자동 추가
 * 비활성: 동일 항목 자동 제거
 * 실제 추가/제거 로직은 hello_child_create_menus() 내부에서 is_plugin_active 분기 처리.
 */
add_action( 'activated_plugin',   'hello_child_on_terra_lms_toggle' );
add_action( 'deactivated_plugin', 'hello_child_on_terra_lms_toggle' );
function hello_child_on_terra_lms_toggle( $plugin ) {
	// 폴더명이 다를 수 있으므로 basename으로 매칭 (terra-lms 포함 여부)
	if ( false === stripos( (string) $plugin, 'terra-lms' ) ) {
		return;
	}
	hello_child_create_menus();
}

/**
 * 필수 플러그인 자동 설치 및 활성화
 *
 * 테마 활성화 시 WooCommerce와 Elementor가 없으면
 * wordpress.org에서 다운로드·설치·활성화한다.
 */
function hello_child_install_required_plugins() {
	$required = array(
		'woocommerce/woocommerce.php' => 'woocommerce',
		'elementor/elementor.php'     => 'elementor',
	);

	include_once ABSPATH . 'wp-admin/includes/plugin.php';

	foreach ( $required as $plugin_file => $slug ) {
		if ( is_plugin_active( $plugin_file ) ) {
			continue;
		}

		// 설치되어 있지만 비활성인 경우
		$plugin_path = WP_PLUGIN_DIR . '/' . $plugin_file;
		if ( file_exists( $plugin_path ) ) {
			activate_plugin( $plugin_file );
			continue;
		}

		// 미설치 → wordpress.org에서 다운로드·설치·활성화
		include_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		include_once ABSPATH . 'wp-admin/includes/file.php';

		$api = plugins_api( 'plugin_information', array(
			'slug'   => $slug,
			'fields' => array( 'sections' => false ),
		) );

		if ( is_wp_error( $api ) ) {
			continue;
		}

		$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
		$result   = $upgrader->install( $api->download_link );

		if ( true === $result ) {
			activate_plugin( $plugin_file );
		}
	}
}

/**
 * 사이트 기본 레이아웃 설정
 *
 * - 헤더/푸터: boxed (컨테이너)
 */
function hello_child_set_full_width_layout() {
	set_theme_mod( 'hello_header_width', 'full_width' );
	set_theme_mod( 'hello_footer_width', 'full_width' );
}

/**
 * 자동 생성된 약관/개인정보 페이지를 WP/WC 기본 정책 페이지로 지정
 *
 * - WP wp_page_for_privacy_policy → /privacy
 * - WC woocommerce_terms_page_id → /terms
 * - WP/WC가 자동 생성한 Draft 정책 페이지(privacy-policy, refund_returns)는 휴지통 처리
 *
 * Idempotent: 매 admin_init마다 호출되어도 안전. 재실행 시
 * - 이미 올바른 페이지가 지정되어 있으면 update_option은 동일값으로 no-op
 * - Draft 정리는 항상 실행되어 WC 재설치 시에도 누적 방지
 */
function hello_child_assign_policy_pages() {
	$privacy = get_page_by_path( 'privacy' );
	$terms   = get_page_by_path( 'terms' );

	// 1) WP Privacy Policy → /privacy 강제 재지정
	// 검수 미통과 #114: WP가 기본 'privacy-policy' Draft을 생성하면 자동으로 그 페이지가
	// 지정됨. 우리 /privacy 페이지가 있으면 무조건 덮어씀.
	if ( $privacy ) {
		$current_privacy_id = (int) get_option( 'wp_page_for_privacy_policy', 0 );
		if ( $current_privacy_id !== (int) $privacy->ID ) {
			update_option( 'wp_page_for_privacy_policy', $privacy->ID );
		}

		if ( class_exists( 'WooCommerce' ) ) {
			update_option( 'woocommerce_checkout_privacy_policy_text',
				'개인정보는 [privacy_policy] 에 따라 처리됩니다.' );
		}
	}

	// 2) WC Terms → /terms 강제 재지정 (#119 — privacy 게이트와 무관하게 항상 실행)
	if ( $terms && class_exists( 'WooCommerce' ) ) {
		$current_terms_id = (int) get_option( 'woocommerce_terms_page_id', 0 );
		if ( $current_terms_id !== (int) $terms->ID ) {
			update_option( 'woocommerce_terms_page_id', $terms->ID );
		}
		update_option( 'woocommerce_checkout_terms_and_conditions_checkbox_text',
			'[terms] 에 동의합니다' );
	}

	// 3) WP가 자동 생성한 기본 'Privacy Policy' Draft 정리 (#116)
	// 슬러그 'privacy-policy' (우리 /privacy와 다름). 발견 시 휴지통.
	$wp_default_privacy = get_page_by_path( 'privacy-policy' );
	if ( $wp_default_privacy && 'draft' === $wp_default_privacy->post_status ) {
		// 우리 /privacy 페이지와 ID가 다른 경우만 휴지통 처리 (안전장치)
		if ( ! $privacy || (int) $wp_default_privacy->ID !== (int) $privacy->ID ) {
			wp_trash_post( $wp_default_privacy->ID );
		}
	}

	// 4) WC가 자동 생성한 'Refund and Returns Policy' Draft 정리 (#117)
	// 옵션값/슬러그 양쪽 모두 체크 (WC가 옵션 설정 전에 페이지만 생성한 케이스 대응)
	if ( class_exists( 'WooCommerce' ) ) {
		$refund_id = (int) get_option( 'woocommerce_refund_returns_page_id', 0 );

		// 옵션에서 가리키는 페이지 정리
		if ( $refund_id ) {
			$refund_page = get_post( $refund_id );
			if ( $refund_page && 'draft' === $refund_page->post_status ) {
				if ( $terms ) {
					update_option( 'woocommerce_refund_returns_page_id', $terms->ID );
				}
				wp_trash_post( $refund_id );
			}
		}

		// 슬러그 기반으로도 잔존 Draft 청소
		$refund_slugs = array( 'refund_returns', 'refund-returns', 'refund-and-returns-policy' );
		foreach ( $refund_slugs as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page && 'draft' === $page->post_status ) {
				if ( ! $terms || (int) $page->ID !== (int) $terms->ID ) {
					wp_trash_post( $page->ID );
				}
			}
		}
	}
}

/**
 * 한국어 언어팩 자동 설치 및 로케일 설정
 */
function hello_child_configure_locale() {
	if ( function_exists( 'wp_install_language' ) ) {
		wp_install_language( 'ko_KR' );
	}
	update_option( 'WPLANG', 'ko_KR' );

	// WooCommerce 언어팩도 설치
	if ( function_exists( 'wp_install_language' ) && class_exists( 'WooCommerce' ) ) {
		wp_install_language( 'ko_KR', 'woocommerce' );
	}
}

/**
 * WooCommerce 기본 설정 자동 구성
 *
 * - 상점 가시성: 영업중
 * - 판매 국가: 대한민국
 * - 통화: 원화 (₩), 소수점 0자리
 * - 회원 전용 결제 (비회원 체크아웃 비활성)
 */
function hello_child_configure_woocommerce() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	$settings = array(
		// 상점 가시성: 영업중
		'woocommerce_coming_soon'           => 'no',

		// 국가/지역
		'woocommerce_default_country'       => 'KR',
		'woocommerce_allowed_countries'     => 'specific',
		'woocommerce_specific_allowed_countries' => array( 'KR' ),

		// 통화
		'woocommerce_currency'              => 'KRW',
		'woocommerce_currency_pos'          => 'left',
		'woocommerce_price_thousand_sep'    => ',',
		'woocommerce_price_decimal_sep'     => '.',
		'woocommerce_price_num_decimals'    => '0',
	);

	foreach ( $settings as $key => $value ) {
		update_option( $key, $value );
	}

	// 토스페이먼츠 테스트 키 자동 설정 (기존 키가 없을 때만)
	hello_child_configure_tosspay_test_keys();
}

/**
 * 토스페이먼츠 일반결제 테스트 키 자동 저장
 */
function hello_child_configure_tosspay_test_keys() {
	$existing = get_option( 'woocommerce_tosspay_onetime_settings', array() );

	// 이미 키가 설정되어 있으면 건너뛰기
	if ( ! empty( $existing['client_key'] ) && ! empty( $existing['secret_key'] ) ) {
		return;
	}

	$defaults = array(
		'enabled'     => 'yes',
		'title'       => '일반 결제',
		'description' => '카드 저장 없이 결제합니다.',
		'client_key'  => 'test_ck_DnyRpQWGrNDo2b00d6n23Kwv1M9E',
		'secret_key'  => 'test_sk_24xLea5zVAmeaAvQ29XbVQAMYNwW',
		'mid'         => '',
	);

	update_option( 'woocommerce_tosspay_onetime_settings', array_merge( $defaults, $existing ) );
}

/**
 * WooCommerce 체크아웃/장바구니 페이지를 클래식 숏코드로 자동 전환
 *
 * 테라 플러그인 CSS + 클래식 WooCommerce 훅은 블록 체크아웃에서 작동하지 않음.
 * 블록 콘텐츠가 감지되면 클래식 숏코드로 교체.
 */
function hello_child_ensure_classic_checkout() {
	$pages = array(
		'woocommerce_checkout_page_id' => '[woocommerce_checkout]',
		'woocommerce_cart_page_id'     => '[woocommerce_cart]',
	);

	foreach ( $pages as $option => $shortcode ) {
		$page_id = get_option( $option );
		if ( ! $page_id ) {
			continue;
		}

		$page = get_post( $page_id );
		if ( ! $page ) {
			continue;
		}

		// 이미 클래식 숏코드면 건너뛰기
		if ( strpos( $page->post_content, $shortcode ) !== false
			&& strpos( $page->post_content, 'wp:woocommerce/' ) === false ) {
			continue;
		}

		wp_update_post( array(
			'ID'           => $page_id,
			'post_content' => $shortcode,
		) );
	}
}

/**
 * init 시점에도 클래식 체크아웃 보장 (WooCommerce 업데이트가 블록으로 되돌릴 수 있음)
 */
add_action( 'init', 'hello_child_maybe_fix_classic_checkout' );
function hello_child_maybe_fix_classic_checkout() {
	if ( wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}

	// 매 요청마다 DB 조회 방지 — 플래그로 1회만 실행
	if ( get_option( 'hello_child_classic_checkout_set' ) === HELLO_CHILD_VERSION ) {
		return;
	}

	hello_child_ensure_classic_checkout();
	update_option( 'hello_child_classic_checkout_set', HELLO_CHILD_VERSION, false );
}

/**
 * 카카오 로그인 페이지 자동 생성 (슬러그: login)
 *
 * 검수 미통과 #135: 로그인 페이지 중복 생성 방지.
 * get_page_by_path('login') 은 publish 상태만 매칭하고 WP 는 기존 슬러그가
 * 다른 상태(trash/draft)로 남아있으면 새 페이지에 'login-2' 식으로 자동
 * 증분 슬러그를 붙여버려, 결과적으로 '로그인' 제목의 페이지가 여러 개
 * 누적되는 현상이 있었음. 아래 로직은 제목 '로그인' 또는 슬러그 'login*' 에
 * 해당하는 페이지를 전수 조사해 최초 publish 1건만 남기고 나머지를 영구 삭제.
 */
function hello_child_create_login_page() {
	$login_pages = get_posts( array(
		'post_type'      => 'page',
		'post_status'    => array( 'publish', 'draft', 'trash', 'private', 'pending', 'future' ),
		'posts_per_page' => -1,
		'orderby'        => 'ID',
		'order'          => 'ASC',
	) );

	$matched = array();
	foreach ( $login_pages as $lp ) {
		$slug  = (string) $lp->post_name;
		$title = trim( (string) $lp->post_title );

		// 정규 login 슬러그: 정확히 'login', WP 자동 증분 'login-2'/'login-3'/…,
		// WP trash suffix 'login__trashed'. 임의 prefix (예: login-faq, login-guide)
		// 는 매칭하지 않는다 — 사용자의 정상 페이지가 잘못 삭제되는 것을 방지.
		$slug_is_canonical =
			'login' === $slug
			|| (bool) preg_match( '/^login-\d+$/', $slug )
			|| 0 === strpos( $slug, 'login__trashed' );

		// 추가 방어: 제목이 '로그인' 이면서 슬러그가 canonical 일 때만 login 페이지로 인정.
		// 제목만으로 매칭하지 않음 (타 용도로 '로그인' 제목을 쓰는 사용자 페이지 보호).
		if ( $slug_is_canonical && '로그인' === $title ) {
			$matched[] = $lp;
		}
	}

	// 우선순위: publish 상태 > 가장 작은 ID
	usort( $matched, function ( $a, $b ) {
		$sa = 'publish' === $a->post_status ? 0 : 1;
		$sb = 'publish' === $b->post_status ? 0 : 1;
		if ( $sa !== $sb ) {
			return $sa - $sb;
		}
		return $a->ID - $b->ID;
	} );

	$keep = null;
	if ( ! empty( $matched ) ) {
		$keep = array_shift( $matched );
		foreach ( $matched as $dup ) {
			wp_delete_post( $dup->ID, true );
		}
	}

	if ( $keep ) {
		// publish 로 승격 + 슬러그 정상화
		$update = array( 'ID' => $keep->ID );
		if ( 'publish' !== $keep->post_status ) {
			$update['post_status'] = 'publish';
		}
		if ( 'login' !== $keep->post_name ) {
			$update['post_name'] = 'login';
		}
		if ( count( $update ) > 1 ) {
			wp_update_post( $update );
		}
		update_post_meta( $keep->ID, '_wp_page_template', 'templates/kakao-login.php' );
		return;
	}

	$page_id = wp_insert_post( array(
		'post_title'   => '로그인',
		'post_name'    => 'login',
		'post_status'  => 'publish',
		'post_type'    => 'page',
		'post_content' => '',
	) );

	if ( $page_id && ! is_wp_error( $page_id ) ) {
		update_post_meta( $page_id, '_wp_page_template', 'templates/kakao-login.php' );
	}
}

/**
 * 로그인 페이지가 없거나 중복된 경우 init 시점에 자동 복구
 */
add_action( 'init', 'hello_child_ensure_login_page' );
function hello_child_ensure_login_page() {
	if ( wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}

	$page = get_page_by_path( 'login' );

	if ( ! $page ) {
		hello_child_create_login_page();
		return;
	}

	// publish 상태의 '로그인' 페이지가 2개 이상이면 dedup 실행
	$dup_check = get_posts( array(
		'post_type'      => 'page',
		'post_status'    => 'publish',
		'title'          => '로그인',
		'posts_per_page' => 2,
		'fields'         => 'ids',
	) );
	if ( is_array( $dup_check ) && count( $dup_check ) > 1 ) {
		hello_child_create_login_page();
	}
}

/**
 * 기존 PG 샘플 상품 cleanup (제목 매칭 + 메타키 매칭 둘 다)
 *
 * 검수자 요청으로 PG 샘플 상품(HTML/CSS, JavaScript, WordPress)을 자동 생성에서
 * 제외했으므로, 이전 버전에서 만들어진 것이 남아있으면 휴지통으로 보낸다.
 *
 * ensure_setup에서 매 admin 요청마다 실행되므로 카테고리/페이지 존재 여부와
 * 무관하게 항상 정리된다.
 */
function hello_child_cleanup_pg_sample_products() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	// 1) 메타키로 매칭
	$by_meta = get_posts( array(
		'post_type'   => 'product',
		'meta_key'    => '_hello_child_pg_sample',
		'meta_value'  => '1',
		'numberposts' => -1,
		'post_status' => array( 'publish', 'draft' ),
	) );

	// 2) 제목으로 매칭 (메타키가 없는 잔여 상품 대비)
	$titles = array(
		'HTML/CSS 웹 퍼블리싱 입문',
		'JavaScript 프론트엔드 실전',
		'WordPress 쇼핑몰 구축 마스터',
	);
	$by_title = array();
	foreach ( $titles as $title ) {
		$found = get_posts( array(
			'post_type'   => 'product',
			'title'       => $title,
			'numberposts' => 5,
			'post_status' => array( 'publish', 'draft' ),
		) );
		$by_title = array_merge( $by_title, $found );
	}

	// 통합 (중복 제거)
	$ids = array();
	foreach ( array_merge( $by_meta, $by_title ) as $p ) {
		$ids[ $p->ID ] = $p;
	}

	foreach ( $ids as $p ) {
		wp_trash_post( $p->ID );
	}
}

/**
 * PG Shop 페이지 + pg 카테고리 자동 생성
 *
 * 샘플 상품(HTML/CSS, JavaScript, WordPress) 생성은 제외 — 검수자 요청으로
 * 자동 생성에서 빼고 카테고리/페이지만 만든다.
 */
function hello_child_create_pg_shop() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	// 1. pg 카테고리 생성
	$term = get_term_by( 'slug', 'pg', 'product_cat' );
	if ( ! $term ) {
		wp_insert_term( 'PG', 'product_cat', array(
			'slug'        => 'pg',
			'description' => 'PG 결제 테스트 상품',
		) );
	}

	// 2. PG 샘플 상품 정리 (cleanup 함수 호출)
	hello_child_cleanup_pg_sample_products();

	// 3. PG Shop 페이지 생성 (PG 카테고리 상품 노출 — PG 심사용)
	$pg_shop_content  = '[products category="pg" columns="3" limit="3" orderby="date" order="DESC"]';
	$pg_shop_template = 'templates/pg-shop.php';
	$page = get_page_by_path( 'pg-shop' );
	if ( ! $page ) {
		$page_id = wp_insert_post( array(
			'post_title'   => 'PG Shop',
			'post_name'    => 'pg-shop',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_content' => $pg_shop_content,
		) );
		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_post_meta( $page_id, '_wp_page_template', $pg_shop_template );
		}
	} else {
		// 기존 페이지 콘텐츠 + 템플릿 동기화
		if ( $page->post_content !== $pg_shop_content ) {
			wp_update_post( array(
				'ID'           => $page->ID,
				'post_content' => $pg_shop_content,
			) );
		}
		update_post_meta( $page->ID, '_wp_page_template', $pg_shop_template );
	}
}

/**
 * Elementor 기본 Color/Typography scheme 비활성화
 *
 * 테마 CSS(home-v2.css 등)가 정의한 디자인이 Elementor 기본 typography/color
 * scheme에 의해 덮이는 것을 방지. 사용자가 Elementor 편집기에서 직접 편집한
 * 값은 여전히 inline/scoped CSS로 출력되어 우선 적용됨.
 *
 * 정책: 테마 디자인 = 기본 템플릿, 사용자 Elementor 편집 = 커스터마이징.
 */
function hello_child_disable_elementor_defaults() {
	update_option( 'elementor_disable_color_schemes', 'yes' );
	update_option( 'elementor_disable_typography_schemes', 'yes' );
}

/**
 * 주메뉴 + 푸터메뉴 자동 생성 (자동 생성된 페이지 기반)
 */
function hello_child_create_menus() {
	// 주메뉴 (Header)
	$menu_name   = '주메뉴';
	$menu_exists = wp_get_nav_menu_object( $menu_name );

	if ( $menu_exists ) {
		$menu_id = $menu_exists->term_id;
	} else {
		$menu_id = wp_create_nav_menu( $menu_name );
	}

	// 블로그 항목 보장 + 중복 정리 (재활성화/재실행 시 누적 방지)
	// 검수 미통과 #113: 주메뉴에 '블로그'가 2개 생성되는 케이스 발견 →
	// 슬러그/타이틀 양쪽으로 매칭 후 첫 항목만 남기고 나머지는 삭제.
	if ( ! is_wp_error( $menu_id ) ) {
		$blog_page  = get_page_by_path( 'blogs' );
		$menu_items = wp_get_nav_menu_items( $menu_id );
		$blog_items = array();

		if ( is_array( $menu_items ) ) {
			foreach ( $menu_items as $item ) {
				$is_blog = false;

				// post_type 매칭: object_id가 blogs 페이지 ID인 경우
				if ( $blog_page && (int) $item->object_id === (int) $blog_page->ID ) {
					$is_blog = true;
				}
				// 슬러그 매칭: object_id가 가리키는 페이지 슬러그가 'blogs'인 경우
				if ( ! $is_blog && $item->object_id ) {
					if ( 'blogs' === get_post_field( 'post_name', $item->object_id ) ) {
						$is_blog = true;
					}
				}
				// custom URL 매칭: /blogs/ 를 가리키는 custom 항목
				if ( ! $is_blog && 'custom' === $item->type && false !== strpos( (string) $item->url, '/blogs' ) ) {
					$is_blog = true;
				}
				// 타이틀 매칭 (마지막 안전망)
				if ( ! $is_blog && '블로그' === trim( (string) $item->title ) ) {
					$is_blog = true;
				}

				if ( $is_blog ) {
					$blog_items[] = $item;
				}
			}
		}

		// 중복 제거 — 첫 항목만 남기고 나머지 삭제
		if ( count( $blog_items ) > 1 ) {
			foreach ( array_slice( $blog_items, 1 ) as $dup ) {
				wp_delete_post( $dup->ID, true );
			}
			$blog_items = array_slice( $blog_items, 0, 1 );
		}

		// 블로그 항목이 없으면 추가 (LMS 메뉴 뒤, position 5)
		if ( empty( $blog_items ) && $blog_page ) {
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => '블로그',
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $blog_page->ID,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
				'menu-item-position'  => 5,
			) );
		}

		// LMS 플러그인 연동 메뉴: 소개 / 클래스룸 / 커뮤니티 / 캘린더
		// Terra LMS 플러그인이 활성화되어 있을 때만 주메뉴에 노출.
		// 비활성 상태에서는 기존에 생성된 해당 메뉴 항목을 제거 (플러그인 재활성화 시 자동 복구).
		// 슬러그는 terra-lms 플러그인 Terra_LMS_Public::$lms_pages 와 일치해야 함.
		if ( ! function_exists( 'is_plugin_active' ) ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		// 클래스 기반 + 파일 경로 기반 이중 감지 — 폴더명이 다르더라도 안전
		$lms_active = class_exists( 'Terra_LMS_Public' )
			|| is_plugin_active( 'terra-lms/terra-lms.php' );

		// 라벨은 terra-lms 플러그인의 원본 페이지 타이틀과 일치시킴
		// (Terra_LMS_Public::$lms_pages → 'about' => 'About')
		$lms_menu_items = array(
			array( 'title' => 'About',    'slug' => 'about',     'url' => '/about/' ),
			array( 'title' => '클래스룸', 'slug' => 'classroom', 'url' => '/classroom/' ),
			array( 'title' => '커뮤니티', 'slug' => 'community', 'url' => '/community/' ),
			array( 'title' => '캘린더',   'slug' => 'calendar',  'url' => '/calendar/' ),
		);

		// 기존 LMS 메뉴 항목 스캔 (슬러그/URL/타이틀 매칭)
		$existing_lms   = array(); // slug => WP_Post
		$all_menu_items = wp_get_nav_menu_items( $menu_id );
		if ( is_array( $all_menu_items ) ) {
			foreach ( $all_menu_items as $item ) {
				foreach ( $lms_menu_items as $lms ) {
					$matched = false;
					// custom URL 매칭
					if ( 'custom' === $item->type ) {
						$path = wp_parse_url( (string) $item->url, PHP_URL_PATH );
						$path = $path ? '/' . trim( $path, '/' ) . '/' : '';
						if ( $path === $lms['url'] ) {
							$matched = true;
						}
					}
					// 타이틀 매칭 (안전망)
					if ( ! $matched && trim( (string) $item->title ) === $lms['title'] ) {
						$matched = true;
					}
					if ( $matched ) {
						// 중복이면 추가분 삭제, 첫 항목만 keep
						if ( isset( $existing_lms[ $lms['slug'] ] ) ) {
							wp_delete_post( $item->ID, true );
						} else {
							$existing_lms[ $lms['slug'] ] = $item;
						}
						break;
					}
				}
			}
		}

		if ( $lms_active ) {
			// 플러그인 활성: 누락된 항목 추가 (요청 순서 1~4)
			foreach ( $lms_menu_items as $pos => $lms ) {
				if ( isset( $existing_lms[ $lms['slug'] ] ) ) {
					continue;
				}
				wp_update_nav_menu_item( $menu_id, 0, array(
					'menu-item-title'    => $lms['title'],
					'menu-item-url'      => home_url( $lms['url'] ),
					'menu-item-type'     => 'custom',
					'menu-item-status'   => 'publish',
					'menu-item-position' => $pos + 1,
				) );
			}
		} else {
			// 플러그인 비활성: 기존 LMS 메뉴 항목 제거 (재활성화 시 복구됨)
			foreach ( $existing_lms as $item ) {
				wp_delete_post( $item->ID, true );
			}
		}
	}

	// 푸터메뉴: FAQ / 용어집 / 이용약관 / 개인정보 처리방침
	// 검수 미통과 #134: 동명 푸터메뉴가 여러 개 생성되거나 항목이 중복되는 케이스 →
	// 1) 동명 메뉴가 복수면 가장 오래된 것만 남기고 나머지 삭제
	// 2) 지정된 4개 링크만 남도록 dedupe + 누락 항목 추가
	$footer_name     = '푸터메뉴';
	$footer_menus    = get_terms( array(
		'taxonomy'   => 'nav_menu',
		'name'       => $footer_name,
		'hide_empty' => false,
	) );
	if ( ! is_wp_error( $footer_menus ) && is_array( $footer_menus ) && count( $footer_menus ) > 1 ) {
		usort( $footer_menus, function ( $a, $b ) { return $a->term_id - $b->term_id; } );
		$keep = array_shift( $footer_menus );
		foreach ( $footer_menus as $dup_menu ) {
			wp_delete_nav_menu( $dup_menu->term_id );
		}
		$footer_exists = $keep;
	} else {
		$footer_exists = wp_get_nav_menu_object( $footer_name );
	}

	if ( $footer_exists ) {
		$footer_id = $footer_exists->term_id;
	} else {
		$footer_id = wp_create_nav_menu( $footer_name );
	}

	$footer_links = array(
		array( 'title' => 'FAQ',               'url' => '/faq/' ),
		array( 'title' => '용어집',             'url' => '/glossary/' ),
		array( 'title' => '이용약관',           'url' => '/terms/' ),
		array( 'title' => '개인정보 처리방침',   'url' => '/privacy/' ),
	);

	if ( ! is_wp_error( $footer_id ) ) {
		$existing_items   = wp_get_nav_menu_items( $footer_id );
		$existing_by_url  = array();
		$seen_urls        = array();

		if ( is_array( $existing_items ) ) {
			foreach ( $existing_items as $item ) {
				$url_path = wp_parse_url( (string) $item->url, PHP_URL_PATH );
				$url_path = $url_path ? rtrim( $url_path, '/' ) . '/' : '';

				// 등록 대상 링크 목록에 있는 URL만 유지, 첫 항목만 keep
				$in_target = false;
				foreach ( $footer_links as $link ) {
					if ( $url_path === $link['url'] ) {
						$in_target = true;
						break;
					}
				}

				if ( ! $in_target || isset( $seen_urls[ $url_path ] ) ) {
					wp_delete_post( $item->ID, true );
					continue;
				}

				$seen_urls[ $url_path ]       = true;
				$existing_by_url[ $url_path ] = $item;
			}
		}

		foreach ( $footer_links as $pos => $link ) {
			if ( isset( $existing_by_url[ $link['url'] ] ) ) {
				continue;
			}
			wp_update_nav_menu_item( $footer_id, 0, array(
				'menu-item-title'    => $link['title'],
				'menu-item-url'      => home_url( $link['url'] ),
				'menu-item-type'     => 'custom',
				'menu-item-status'   => 'publish',
				'menu-item-position' => $pos + 1,
			) );
		}
	}

	// 메뉴 위치는 항상 할당 (기존 메뉴가 있어도 location이 빠져있을 수 있음)
	$locations = get_theme_mod( 'nav_menu_locations', array() );
	if ( ! is_wp_error( $menu_id ) ) {
		$locations['menu-1'] = $menu_id;
	}
	if ( ! is_wp_error( $footer_id ) ) {
		$locations['menu-2'] = $footer_id;
	}
	set_theme_mod( 'nav_menu_locations', $locations );
}

/**
 * 블로그 모음 페이지 자동 생성 (슬러그: blogs)
 *
 * '블로그 모음' 커스텀 템플릿을 적용하고 엘리멘토 편집을 차단.
 * 기존 페이지가 있으면 템플릿만 재적용.
 */
function hello_child_create_blog_archive_page() {
	$page = get_page_by_path( 'blogs' );

	if ( $page ) {
		update_post_meta( $page->ID, '_wp_page_template', 'templates/blog-archive.php' );
		delete_post_meta( $page->ID, '_elementor_edit_mode' );
		delete_post_meta( $page->ID, '_elementor_data' );
		return;
	}

	$page_id = wp_insert_post( array(
		'post_title'   => '블로그',
		'post_name'    => 'blogs',
		'post_status'  => 'publish',
		'post_type'    => 'page',
		'post_content' => '',
	) );

	if ( $page_id && ! is_wp_error( $page_id ) ) {
		update_post_meta( $page_id, '_wp_page_template', 'templates/blog-archive.php' );
	}
}

/**
 * '블로그 모음' 템플릿 페이지에서 엘리멘토 편집 차단
 */
add_filter( 'elementor/editor/is_edit_mode', 'hello_child_block_elementor_on_blog_archive' );
function hello_child_block_elementor_on_blog_archive( $is_edit_mode ) {
	if ( ! $is_edit_mode ) {
		return false;
	}

	$post_id = get_the_ID();
	if ( ! $post_id && isset( $_GET['post'] ) ) {
		$post_id = (int) $_GET['post'];
	}

	if ( $post_id ) {
		$template = get_post_meta( $post_id, '_wp_page_template', true );
		if ( $template === 'templates/blog-archive.php' ) {
			return false;
		}
	}

	return $is_edit_mode;
}

/**
 * WP 편집 화면에서 "Elementor로 편집" 버튼 숨김 (블로그 모음 페이지)
 */
add_action( 'admin_head', 'hello_child_hide_elementor_btn_on_blog_archive' );
function hello_child_hide_elementor_btn_on_blog_archive() {
	global $post;
	if ( ! $post ) return;

	$template = get_post_meta( $post->ID, '_wp_page_template', true );
	if ( $template === 'templates/blog-archive.php' ) {
		echo '<style>#elementor-switch-mode, #elementor-editor { display: none !important; }</style>';
	}
}

/**
 * GEO 카테고리 + FAQ/용어집 샘플 글 자동 생성
 *
 * AI 인용 최적화 페이지:
 * - h2 + p 클린 구조
 * - 3줄 요약 메타박스만 활성화
 * - FAQPage / DefinedTermSet Schema 자동 주입
 */
/* hello_child_create_geo_posts() — auto-content.php로 이전됨 */

/**
 * /my-account/ 로그인 폼에 카카오 로그인 버튼 자동 표시
 *
 * 사용자가 페이지에 숏코드를 입력할 필요 없음. terra_kakao_rest_api_key
 * 옵션이 설정되어 있으면 자동으로 폼 위에 카카오 로그인 카드가 표시된다.
 *
 * /login/ 페이지의 kakao-login.php와 동일한 방식 (직접 HTML 렌더링).
 *
 * 다중 hook 등록 + the_content 필터 fallback으로 어떤 WC 템플릿 오버라이드
 * 환경에서도 작동을 보장한다.
 */

/**
 * tosspay 플러그인의 카카오 로그인 카드를 우리 디자인으로 교체
 *
 * 원래: terra-tosspay/public/checkout/class-checkout-ui.php::display_kakao_login_card
 *       → <div class="tosspay-kakao-login-card"> + <h3>로그인</h3> + [terra_kakao_login id="1"]
 *
 * 변경: 같은 클래스명 카드 안에 우리 디자인 카카오 버튼 직접 출력
 *       - h3 "로그인"
 *       - 카카오 버튼 ("3초만에 시작하기")
 *       - "또는 아이디로 로그인" 문구 삭제
 */
add_action( 'wp', 'hello_child_replace_tosspay_kakao_card', 99 );
function hello_child_replace_tosspay_kakao_card() {
	if ( ! is_admin() && function_exists( 'is_account_page' ) ) {
		// tosspay 플러그인의 기존 카카오 카드 hook 제거
		global $wp_filter;
		if ( isset( $wp_filter['woocommerce_before_customer_login_form'] ) ) {
			foreach ( $wp_filter['woocommerce_before_customer_login_form']->callbacks as $priority => $callbacks ) {
				foreach ( $callbacks as $key => $cb ) {
					if ( is_array( $cb['function'] ) && is_object( $cb['function'][0] )
						&& method_exists( $cb['function'][0], 'display_kakao_login_card' )
						&& 'display_kakao_login_card' === $cb['function'][1] ) {
						unset( $wp_filter['woocommerce_before_customer_login_form']->callbacks[ $priority ][ $key ] );
					}
				}
			}
		}
	}
}

/**
 * 우리만의 tosspay-kakao-login-card 출력
 * (tosspay 플러그인의 카드를 위에서 제거했으므로 안전하게 대체)
 */
add_action( 'woocommerce_before_customer_login_form', 'hello_child_render_tosspay_kakao_card', 10 );
function hello_child_render_tosspay_kakao_card() {
	if ( is_user_logged_in() ) {
		return;
	}
	$redirect  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
	$login_url = add_query_arg( 'redirect', urlencode( $redirect ), home_url( '/klogin' ) );
	?>
	<div class="tosspay-kakao-login-card">
		<h3>로그인</h3>
		<a href="<?php echo esc_url( $login_url ); ?>" class="hello-child-myaccount-kakao-btn">
			<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 256 256" aria-hidden="true">
				<path fill="#000000" d="M128 36C70.562 36 24 72.713 24 118c0 29.279 19.466 54.97 48.748 69.477-1.593 5.494-10.237 35.344-10.581 37.689 0 0-.207 1.762.934 2.434s2.483.15 2.483.15c3.272-.457 37.943-24.811 43.944-29.03 5.995.849 12.168 1.28 18.472 1.28 57.438 0 104-36.712 104-82c0-45.287-46.562-82-104-82"/>
			</svg>
			<span>3초만에 시작하기</span>
		</a>
	</div>
	<?php
}

/**
 * 헬퍼: 카카오 로그인 버튼 HTML (다른 곳에서 재사용 가능)
 */
function hello_child_get_myaccount_kakao_html() {
	$redirect  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
	$login_url = add_query_arg( 'redirect', urlencode( $redirect ), home_url( '/klogin' ) );

	ob_start();
	?>
	<div class="hello-child-myaccount-kakao">
		<a href="<?php echo esc_url( $login_url ); ?>" class="hello-child-myaccount-kakao-btn">
			<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 256 256" aria-hidden="true">
				<path fill="#000000" d="M128 36C70.562 36 24 72.713 24 118c0 29.279 19.466 54.97 48.748 69.477-1.593 5.494-10.237 35.344-10.581 37.689 0 0-.207 1.762.934 2.434s2.483.15 2.483.15c3.272-.457 37.943-24.811 43.944-29.03 5.995.849 12.168 1.28 18.472 1.28 57.438 0 104-36.712 104-82c0-45.287-46.562-82-104-82"/>
			</svg>
			<span>3초만에 시작하기</span>
		</a>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * LiteSpeed 캐시 제외 — 로그인 상태에 따라 다른 콘텐츠
 */
add_action( 'template_redirect', 'hello_child_login_page_nocache' );
function hello_child_login_page_nocache() {
	if ( is_page( 'login' ) || ( function_exists( 'is_checkout' ) && is_checkout() ) ) {
		do_action( 'litespeed_control_set_nocache', 'hello_child_dynamic_page' );
	}
}

/**
 * 체크아웃 페이지 — 비회원이면 주문자 정보(billing) 숨기고 카카오 로그인 카드 표시
 *
 * 주문 내역(order_review)은 그대로 보여주고,
 * billing fields + 결제 버튼을 카카오 로그인 카드로 대체.
 * 로그인 후 다시 /checkout/으로 돌아옴.
 */
add_action( 'woocommerce_after_checkout_form', 'hello_child_checkout_kakao_login', 5 );
function hello_child_checkout_kakao_login() {
	if ( is_user_logged_in() ) {
		return;
	}

	// 비회원 결제가 허용되어 있으면 카카오 로그인 불필요
	if ( 'yes' === get_option( 'woocommerce_enable_guest_checkout', 'yes' ) ) {
		return;
	}

	$rest_api_key = get_option( 'terra_kakao_rest_api_key', '' );
	if ( empty( $rest_api_key ) ) {
		return;
	}

	$login_url = add_query_arg( 'redirect', urlencode( wc_get_checkout_url() ), home_url( '/klogin' ) );
	?>
	<div class="hello-child-checkout-login-card">
		<h3 class="hello-child-checkout-login-title">결제를 진행하려면 먼저 로그인해주세요.</h3>
		<a href="<?php echo esc_url( $login_url ); ?>" class="hello-child-checkout-kakao-btn">
			<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 256 256">
				<path fill="#000000" d="M128 36C70.562 36 24 72.713 24 118c0 29.279 19.466 54.97 48.748 69.477-1.593 5.494-10.237 35.344-10.581 37.689 0 0-.207 1.762.934 2.434s2.483.15 2.483.15c3.272-.457 37.943-24.811 43.944-29.03 5.995.849 12.168 1.28 18.472 1.28 57.438 0 104-36.712 104-82c0-45.287-46.562-82-104-82"/>
			</svg>
			<span>카카오로 로그인</span>
		</a>
	</div>
	<?php
}

/**
 * 체크아웃 — 비회원이면 billing fields 숨기기
 */
add_filter( 'woocommerce_checkout_fields', 'hello_child_hide_checkout_fields_for_guest', 9999 );
function hello_child_hide_checkout_fields_for_guest( $fields ) {
	if ( is_user_logged_in() || 'yes' === get_option( 'woocommerce_enable_guest_checkout', 'yes' ) ) {
		return $fields;
	}

	unset( $fields['billing'] );
	unset( $fields['shipping'] );
	unset( $fields['order'] );

	return $fields;
}

/**
 * 체크아웃 — 비회원이면 결제 버튼 숨기기 + 카카오 로그인 카드 스타일
 */
add_action( 'wp_head', 'hello_child_checkout_guest_styles' );
function hello_child_checkout_guest_styles() {
	if ( is_user_logged_in() || ! function_exists( 'is_checkout' ) || ! is_checkout()
		|| 'yes' === get_option( 'woocommerce_enable_guest_checkout', 'yes' ) ) {
		return;
	}
	?>
	<style>
		.woocommerce-checkout #customer_details,
		.woocommerce-checkout #payment {
			display: none !important;
		}

		.hello-child-checkout-login-card {
			background: var(--toss-white, #FFFFFF);
			border-radius: var(--toss-radius-md, 12px);
			padding: 32px 24px;
			box-shadow: var(--toss-shadow-sm, 0 1px 2px rgba(0,0,0,0.04));
			border: 1px solid var(--toss-gray-200, #E5E8EB);
			text-align: center;
			width: 100%;
			max-width: 600px;
			margin: 20px auto 0;
			box-sizing: border-box;
		}
		.hello-child-checkout-login-title {
			font-size: 16px !important;
			font-weight: 700 !important;
			color: var(--toss-black, #191F28) !important;
			margin: 0 0 20px !important;
			padding: 0 !important;
			border: none !important;
		}
		.hello-child-checkout-kakao-btn {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			gap: 8px;
			width: 100%;
			padding: 14px 20px;
			background-color: #FEE500;
			color: #000000;
			font-size: 16px;
			font-weight: 600;
			border-radius: var(--toss-radius-sm, 8px);
			text-decoration: none;
			transition: background-color 0.2s;
			box-sizing: border-box;
		}
		.hello-child-checkout-kakao-btn:hover {
			background-color: #F0D800;
			color: #000000;
		}
	</style>
	<?php
}

/**
 * pg-shop 페이지에 woocommerce body class 추가 (상품 카드 스타일 적용용)
 */
add_filter( 'body_class', 'hello_child_pg_shop_body_class' );
function hello_child_pg_shop_body_class( $classes ) {
	if ( is_page( 'pg-shop' ) ) {
		$classes[] = 'woocommerce';
		$classes[] = 'page-pg-shop';
	}
	return $classes;
}

/* =============================================================================
   VOD 강의 샘플 상품 자동 생성 (입문 / 중급 / 고급)
   — VOD + PG 카테고리 동시 할당 (PG 심사용 메인 전환 시 PG 카테고리로 노출)
   ============================================================================= */
function hello_child_create_vod_products() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	// VOD 카테고리 생성
	$term = get_term_by( 'slug', 'vod', 'product_cat' );
	if ( ! $term ) {
		$result = wp_insert_term( 'VOD', 'product_cat', array(
			'slug'        => 'vod',
			'description' => 'VOD 강의 상품',
		) );
		if ( ! is_wp_error( $result ) ) {
			$term_id = $result['term_id'];
		}
	} else {
		$term_id = $term->term_id;
	}

	if ( empty( $term_id ) ) {
		return;
	}

	// 이미 VOD 상품이 있으면 스킵
	$existing = get_posts( array(
		'post_type'   => 'product',
		'meta_key'    => '_hello_child_vod_sample',
		'meta_value'  => '1',
		'numberposts' => 1,
	) );

	if ( ! empty( $existing ) ) {
		return;
	}

	// 디폴트 이미지 업로드
	$img_dir    = get_stylesheet_directory() . '/assets/images/';
	$target_imgs = array();
	$target_files = array( '2123043-3.jpg', '2123043-1.jpg', '2123043.jpg' );

	require_once ABSPATH . 'wp-admin/includes/image.php';

	foreach ( $target_files as $file ) {
		$path = $img_dir . $file;
		if ( file_exists( $path ) ) {
			$upload_dir = wp_upload_dir();
			$dest       = $upload_dir['path'] . '/' . $file;
			if ( ! file_exists( $dest ) ) {
				@copy( $path, $dest );
			}
			if ( file_exists( $dest ) ) {
				$attach_id = wp_insert_attachment( array(
					'post_mime_type' => 'image/jpeg',
					'post_title'     => pathinfo( $file, PATHINFO_FILENAME ),
					'post_status'    => 'inherit',
				), $dest );
				$metadata = wp_generate_attachment_metadata( $attach_id, $dest );
				wp_update_attachment_metadata( $attach_id, $metadata );
				$target_imgs[] = $attach_id;
			}
		}
	}

	// 4개 슬롯용 이미지 (3개를 순환)
	$img1 = $target_imgs[0] ?? 0;
	$img2 = $target_imgs[1] ?? 0;
	$img3 = $target_imgs[2] ?? 0;
	$img4 = $target_imgs[0] ?? 0;

	// ─── 상품 데이터 정의 ───
	$products = array(

		// 입문
		array(
			'title'         => '온라인 마케팅 입문 클래스',
			'excerpt'       => '마케팅 완전 초보를 위한 4주 기초 과정. 용어부터 도구 세팅까지 — 16강으로 시작합니다.',
			'regular_price' => '99000',
			'sale_price'    => '49000',
			'why'           => array(
				'title' => '마케팅, 어디서부터 시작할지 모르겠다면.',
				'body'  => '블로그? SNS? 광고? 너무 많은 정보 속에서 뭘 먼저 해야 할지 막막하셨죠. 이 클래스는 딱 하나에 집중합니다 — 마케팅의 전체 그림을 잡는 것. 4주 후에는 내 비즈니스에 어떤 마케팅이 필요한지 스스로 판단할 수 있게 됩니다.',
			),
			'benefits'      => array(
				array( 'icon' => 'play-circle', 'title' => 'VOD 강의 16강', 'desc' => '평균 12분, 핵심만 담은 짧고 명확한 강의. 영구 수강권.' ),
				array( 'icon' => 'book-open', 'title' => '입문자 전용 워크북', 'desc' => '강의마다 실습 과제가 포함된 PDF 워크북 제공.' ),
				array( 'icon' => 'file-text', 'title' => '마케팅 용어 사전', 'desc' => 'CTR, CPC, 퍼널, 리드… 헷갈리는 용어를 한 권으로 정리.' ),
				array( 'icon' => 'users', 'title' => '수강생 전용 커뮤니티', 'desc' => '같은 출발선의 동료들과 질문, 피드백, 동기부여.' ),
			),
			'targets'       => array(
				array( 'text' => '마케팅이 완전 처음인 분' ),
				array( 'text' => '용어부터 헷갈리는 분' ),
				array( 'text' => '혼자 공부하다 포기한 분' ),
				array( 'text' => '부업·창업을 준비 중인 분' ),
			),
			'curriculum'    => array(
				array( 'title' => '마케팅 기초 개념', 'items' => array(
					array( 'title' => '디지털 마케팅이란?', 'desc' => '온라인 마케팅의 전체 지도를 그립니다' ),
					array( 'title' => '고객 여정과 퍼널 이해', 'desc' => '방문자가 고객이 되는 과정을 배웁니다' ),
				) ),
				array( 'title' => '도구 세팅 실습', 'items' => array(
					array( 'title' => '워드프레스 기본 세팅', 'desc' => '호스팅부터 테마 설치까지 따라하기' ),
					array( 'title' => 'Google Analytics 연동', 'desc' => '방문자 데이터 수집 환경 구축' ),
				) ),
				array( 'title' => '콘텐츠 마케팅 입문', 'items' => array(
					array( 'title' => '블로그 글쓰기 기초', 'desc' => '검색에 잘 걸리는 글의 구조' ),
					array( 'title' => 'SNS 채널 세팅', 'desc' => '인스타그램·유튜브 프로필 최적화' ),
				) ),
				array( 'title' => '첫 마케팅 캠페인', 'items' => array(
					array( 'title' => '랜딩 페이지 만들기', 'desc' => '전환율 높은 페이지의 필수 요소' ),
					array( 'title' => '첫 이메일 캠페인 발송', 'desc' => '메일침프로 첫 뉴스레터 보내기' ),
				) ),
			),
			'instructor'    => array(
				'photo_id' => 0, 'name' => '박지은', 'title' => '마케팅 입문 전문 강사',
				'bio' => '비전공자 출신으로 마케팅을 독학한 경험을 바탕으로, 진짜 초보 눈높이의 커리큘럼을 설계합니다. "어려운 말 없이 쉽게"가 교육 철학입니다.',
				'tags' => '마케팅 입문, 워드프레스, 수강생 500명+',
			),
			'faq'           => array(
				array( 'q' => '컴퓨터를 잘 못하는데 따라갈 수 있나요?', 'a' => '네. 마우스 클릭과 타이핑만 할 수 있으면 충분합니다. 화면을 그대로 따라하는 방식으로 진행됩니다.' ),
				array( 'q' => '입문 과정만 들어도 실무에 적용할 수 있나요?', 'a' => '기본적인 블로그 운영, SNS 세팅, 이메일 마케팅은 바로 실행할 수 있습니다. 더 깊은 전략은 중급 과정에서 다룹니다.' ),
				array( 'q' => '수강 기간이 정해져 있나요?', 'a' => '영구 수강입니다. 한 번 구매하면 언제든 반복해서 볼 수 있습니다.' ),
				array( 'q' => '실시간 강의를 놓쳐도 다시 볼 수 있나요?', 'a' => '네. 모든 라이브 강의는 녹화되어 수강생 전용 페이지에 업로드됩니다. 놓친 강의도 언제든 녹화본으로 다시 볼 수 있습니다.' ),
			),
		),

		// 중급
		array(
			'title'         => '온라인 마케팅 실전 VOD 클래스',
			'excerpt'       => '마케팅 왕초보를 위한 8주 완성 VOD. 콘텐츠 마케팅, 퍼널 설계, 이메일 자동화, 광고 운영까지 — 32강으로 완성합니다.',
			'regular_price' => '199000',
			'sale_price'    => '99000',
			'why'           => array(
				'title' => '결과물이 나오는 순서로 가르칩니다.',
				'body'  => '마케팅 강의는 많지만, 수료 후 실제로 시스템을 완성한 사람은 드뭅니다. 문제는 가르치는 순서에 있었습니다. 이 클래스는 8주 안에 콘텐츠 → 퍼널 → 자동화까지 직접 만들어보는 것을 목표로 설계했습니다. 이론이 아니라 결과물로 증명합니다.',
			),
			'benefits'      => array(
				array( 'icon' => 'play-circle', 'title' => 'VOD 강의 32강', 'desc' => '핵심만 담은 평균 20분 강의. 매주 4강씩, 영구 수강권.' ),
				array( 'icon' => 'check-square', 'title' => '주차별 실행 체크리스트', 'desc' => '매주 명확한 실행 목록. 따라가면 결과물이 쌓입니다.' ),
				array( 'icon' => 'award', 'title' => '수료증 + 수료 선물', 'desc' => '8주 완주 시 수료증 발급 및 고급 과정 할인 쿠폰.' ),
				array( 'icon' => 'file-text', 'title' => '마케팅 실전 템플릿 팩', 'desc' => '퍼널 설계, 이메일 시퀀스, 랜딩 페이지, 콘텐츠 캘린더.' ),
			),
			'targets'       => array(
				array( 'text' => '마케팅 기초는 아는데 실행이 안 되는 분' ),
				array( 'text' => '콘텐츠를 만들어도 성과가 없는 분' ),
				array( 'text' => '퍼널·자동화를 직접 만들고 싶은 분' ),
				array( 'text' => '매출로 연결되는 구조가 필요한 분' ),
			),
			'curriculum'    => array(
				array( 'title' => '마케팅 전략 수립', 'items' => array(
					array( 'title' => '디지털 마케팅 전체 구조 이해', 'desc' => '입문 — 콘텐츠, 퍼널, 광고, 데이터의 전체 흐름을 잡습니다' ),
					array( 'title' => '타겟 고객 페르소나 설계', 'desc' => '누구에게 팔 것인가 — 고객 분석 프레임워크' ),
				) ),
				array( 'title' => '콘텐츠 마케팅 실전', 'items' => array(
					array( 'title' => '블로그 SEO 콘텐츠 작성법', 'desc' => '검색 상위 노출되는 글의 구조와 키워드 전략' ),
					array( 'title' => 'SNS 콘텐츠 기획과 운영', 'desc' => '인스타그램·유튜브 채널 성장 로드맵' ),
				) ),
				array( 'title' => '퍼널 설계 · 이메일 자동화', 'items' => array(
					array( 'title' => '리드 마그넷과 랜딩 페이지', 'desc' => '방문자를 잠재 고객으로 전환하는 장치 설계' ),
					array( 'title' => '이메일 시퀀스 자동화', 'desc' => '환영 → 교육 → 판매 흐름을 자동으로 구축' ),
				) ),
				array( 'title' => '광고 · 데이터 분석', 'items' => array(
					array( 'title' => '메타·구글 광고 기초 운영', 'desc' => '적은 예산으로 시작하는 유료 광고 실전' ),
					array( 'title' => '데이터 분석과 스케일링', 'desc' => 'GA4 기반 성과 측정과 다음 단계 전략 수립' ),
				) ),
			),
			'instructor'    => array(
				'photo_id' => 0, 'name' => '김미현', 'title' => '대표 강사 · 온라인 마케팅 전문가',
				'bio' => '온라인 마케팅 실전 VOD 커리큘럼 총괄. 수백 명의 수강생이 막히는 포인트를 직접 검증하며 지금의 흐름을 설계했습니다.',
				'tags' => '온라인 마케팅, 퍼널 설계, 수강생 300명+',
			),
			'faq'           => array(
				array( 'q' => '마케팅 기초 지식이 없어도 되나요?', 'a' => '기본적인 마케팅 개념(퍼널, 콘텐츠, SEO)을 알고 있으면 수강에 무리가 없습니다. 입문 과정을 먼저 수강하시면 더 수월합니다.' ),
				array( 'q' => 'VOD를 수강 기간이 지나도 볼 수 있나요?', 'a' => '네. 영구 수강입니다. 한 번 구매하면 언제든 다시 볼 수 있습니다.' ),
				array( 'q' => '어떤 도구를 사용하나요?', 'a' => '워드프레스, 우커머스, Google Analytics, 메일침프 등 무료 또는 저비용 도구 위주로 구성됩니다.' ),
				array( 'q' => '실시간 강의를 놓쳐도 다시 볼 수 있나요?', 'a' => '네. 모든 라이브 강의는 녹화되어 수강생 전용 페이지에 업로드됩니다. 놓친 강의도 언제든 녹화본으로 다시 볼 수 있습니다.' ),
			),
		),

		// 고급
		array(
			'title'         => '온라인 마케팅 고급 마스터 클래스',
			'excerpt'       => '매출을 만드는 마케팅 시스템 12주 과정. 광고 최적화, 자동화 퍼널, 데이터 분석까지 — 48강 + 1:1 컨설팅.',
			'regular_price' => '399000',
			'sale_price'    => '249000',
			'why'           => array(
				'title' => '매출을 만드는 시스템을 설계합니다.',
				'body'  => '기초는 아는데 매출로 연결이 안 되시나요? 이 과정에서는 실제 매출이 발생하는 마케팅 시스템을 직접 구축합니다. 광고 최적화, A/B 테스트, 자동화 퍼널, 데이터 기반 의사결정까지 — 12주 후에는 감이 아닌 숫자로 마케팅을 운영할 수 있습니다.',
			),
			'benefits'      => array(
				array( 'icon' => 'play-circle', 'title' => 'VOD 강의 48강', 'desc' => '실전 케이스 스터디 중심 평균 25분 심화 강의.' ),
				array( 'icon' => 'headphones', 'title' => '1:1 전략 컨설팅 2회', 'desc' => '내 비즈니스에 맞는 맞춤 전략을 화상으로 설계.' ),
				array( 'icon' => 'zap', 'title' => '마케팅 자동화 템플릿', 'desc' => '이메일 시퀀스, 리타게팅, 퍼널 설계도 실전 템플릿.' ),
				array( 'icon' => 'users', 'title' => '수료 후 멘토링 그룹', 'desc' => '3개월간 월간 그룹 멘토링으로 실행 점검.' ),
				array( 'icon' => 'trending-up', 'title' => '데이터 분석 대시보드', 'desc' => '핵심 지표를 한눈에 보는 마케팅 대시보드 구축.' ),
				array( 'icon' => 'gift', 'title' => '보너스: 광고 크리에이티브 팩', 'desc' => '성과 검증된 광고 카피 50종 + 디자인 템플릿.' ),
			),
			'targets'       => array(
				array( 'text' => '기초는 아는데 매출이 안 나오는 분' ),
				array( 'text' => '광고비 ROI를 높이고 싶은 분' ),
				array( 'text' => '마케팅 자동화를 구축하고 싶은 분' ),
				array( 'text' => '데이터로 의사결정하고 싶은 분' ),
			),
			'curriculum'    => array(
				array( 'title' => '마케팅 시스템 설계', 'items' => array(
					array( 'title' => '매출 퍼널 아키텍처', 'desc' => '인지→관심→전환→재구매 전체 설계' ),
					array( 'title' => '고객 세그먼트 분석', 'desc' => '데이터 기반 타겟 고객 정의' ),
					array( 'title' => '경쟁사 분석 프레임워크', 'desc' => '블루오션 포지셔닝 전략 수립' ),
				) ),
				array( 'title' => '퍼포먼스 광고 마스터', 'items' => array(
					array( 'title' => '메타 광고 고급 전략', 'desc' => '리타게팅, 유사 타겟, 캠페인 구조 최적화' ),
					array( 'title' => '구글 광고 실전', 'desc' => '검색 광고 + 디스플레이 + 리마케팅' ),
					array( 'title' => 'A/B 테스트 설계', 'desc' => '과학적으로 광고 성과를 개선하는 방법' ),
				) ),
				array( 'title' => '마케팅 자동화', 'items' => array(
					array( 'title' => '이메일 시퀀스 자동화', 'desc' => '환영→교육→판매→리텐션 자동 흐름' ),
					array( 'title' => 'CRM 연동과 리드 스코어링', 'desc' => '뜨거운 리드를 자동으로 분류하는 시스템' ),
					array( 'title' => '챗봇·알림 자동화', 'desc' => '24시간 응대하는 마케팅 봇 구축' ),
				) ),
				array( 'title' => '데이터 분석·스케일링', 'items' => array(
					array( 'title' => '마케팅 대시보드 구축', 'desc' => '핵심 지표를 한눈에 보는 대시보드' ),
					array( 'title' => 'ROI 분석과 예산 배분', 'desc' => '채널별 성과를 숫자로 판단하는 방법' ),
					array( 'title' => '스케일업 전략', 'desc' => '월 매출 1000만 원에서 1억으로 가는 로드맵' ),
				) ),
			),
			'instructor'    => array(
				'photo_id' => 0, 'name' => '이준호', 'title' => '마케팅 시스템 설계 전문가 · 前 대행사 이사',
				'bio' => '10년간 300개+ 브랜드의 마케팅을 설계하고 실행한 경험을 바탕으로, 이론이 아닌 실전에서 검증된 시스템만 가르칩니다. "감이 아닌 데이터로 결정하라"가 교육 철학입니다.',
				'tags' => '퍼포먼스 마케팅, 마케팅 자동화, 데이터 분석, 수강생 200명+',
			),
			'faq'           => array(
				array( 'q' => '입문/중급 과정을 안 들어도 되나요?', 'a' => '기본적인 마케팅 개념과 도구 사용 경험이 있다면 바로 수강 가능합니다. 퍼널, 광고, 데이터 분석 용어가 익숙하시면 됩니다.' ),
				array( 'q' => '1:1 컨설팅은 어떻게 진행되나요?', 'a' => '수강 4주차, 8주차에 각 1회씩 30분 화상 미팅으로 진행됩니다. 내 비즈니스에 맞는 전략을 직접 설계해 드립니다.' ),
				array( 'q' => '실제 매출 사례가 있나요?', 'a' => '수강생 평균 3개월 내 광고 ROAS 2.5배 개선, 이메일 자동화 도입 후 재구매율 40% 향상 등의 성과가 보고되고 있습니다.' ),
				array( 'q' => '실시간 강의를 놓쳐도 다시 볼 수 있나요?', 'a' => '네. 모든 라이브 강의는 녹화되어 수강생 전용 페이지에 업로드됩니다. 놓친 강의도 언제든 녹화본으로 다시 볼 수 있습니다.' ),
			),
		),
	);

	// ─── 상품 생성 루프 ───
	foreach ( $products as $p ) {
		// 동일 제목 상품이 이미 있으면 스킵 (재호출 시 중복 방지)
		$dupe = get_posts( array(
			'post_type'   => 'product',
			'post_status' => 'any',
			'title'       => $p['title'],
			'numberposts' => 1,
			'fields'      => 'ids',
		) );
		if ( ! empty( $dupe ) ) {
			continue;
		}

		$product_id = wp_insert_post( array(
			'post_title'   => $p['title'],
			'post_content' => '',
			'post_excerpt' => $p['excerpt'],
			'post_status'  => 'publish',
			'post_type'    => 'product',
		) );

		if ( ! $product_id || is_wp_error( $product_id ) ) {
			continue;
		}

		// WooCommerce 기본 메타
		wp_set_object_terms( $product_id, 'simple', 'product_type' );
				// VOD + PG 카테고리 동시 할당
		$pg_term = get_term_by( 'slug', 'pg', 'product_cat' );
		$cat_ids = array( $term_id );
		if ( $pg_term ) { $cat_ids[] = $pg_term->term_id; }
		wp_set_object_terms( $product_id, $cat_ids, 'product_cat' );
		update_post_meta( $product_id, '_regular_price', $p['regular_price'] );
		update_post_meta( $product_id, '_sale_price', $p['sale_price'] );
		update_post_meta( $product_id, '_price', $p['sale_price'] );
		update_post_meta( $product_id, '_virtual', 'yes' );
		update_post_meta( $product_id, '_stock_status', 'instock' );
		update_post_meta( $product_id, '_hello_child_vod_sample', '1' );

		// 커스텀 메타박스 데이터
		update_post_meta( $product_id, '_sp_why', $p['why'] );
		update_post_meta( $product_id, '_sp_benefits', $p['benefits'] );

		// 타겟 — 이미지 ID 매핑
		$targets_with_img = array();
		foreach ( $p['targets'] as $i => $t ) {
			$imgs = array( $img1, $img2, $img3, $img4 );
			$targets_with_img[] = array(
				'img_id' => $imgs[ $i ] ?? 0,
				'text'   => $t['text'],
			);
		}
		update_post_meta( $product_id, '_sp_targets', $targets_with_img );

		update_post_meta( $product_id, '_sp_curriculum', $p['curriculum'] );
		update_post_meta( $product_id, '_sp_instructor', $p['instructor'] );
		update_post_meta( $product_id, '_sp_faq', $p['faq'] );

		// 환불 규정
		update_post_meta( $product_id, '_sp_refund_policy', "결제 후 7일 이내 환불 가능 (미수강 시)\n수강 시작 후에는 환불 불가\n콘텐츠 특성상 부분 환불 불가" );
	}
}

/* =============================================================================
   무료 PDF 상품 자동 생성 (freepdf 카테고리)
   — 카카오 로그인 후 다운로드 방식 (wc-product 브랜치에서 템플릿 구현)
   ============================================================================= */

function hello_child_create_freepdf_product() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	// freepdf 카테고리 생성
	$term = get_term_by( 'slug', 'freepdf', 'product_cat' );
	if ( ! $term ) {
		$result = wp_insert_term( 'freepdf', 'product_cat', array(
			'slug'        => 'freepdf',
			'description' => '카카오 로그인 후 무료 다운로드 상품',
		) );
		if ( ! is_wp_error( $result ) ) {
			$term_id = $result['term_id'];
		}
	} else {
		$term_id = $term->term_id;
	}

	if ( empty( $term_id ) ) {
		return;
	}

	// 이미 freepdf 상품이 있으면 스킵
	$existing = get_posts( array(
		'post_type'   => 'product',
		'meta_key'    => '_hello_child_freepdf_sample',
		'meta_value'  => '1',
		'numberposts' => 1,
	) );

	if ( ! empty( $existing ) ) {
		return;
	}

	$product_id = wp_insert_post( array(
		'post_title'   => '온라인 마케팅 무료 가이드북',
		'post_content' => '',
		'post_excerpt' => '온라인 마케팅을 처음 시작하는 분을 위한 핵심 가이드. 퍼널 설계, 콘텐츠 전략, 광고 기초까지 한 권으로 정리했습니다.',
		'post_status'  => 'publish',
		'post_type'    => 'product',
	) );

	if ( ! $product_id || is_wp_error( $product_id ) ) {
		return;
	}

	// WooCommerce 기본 메타
	wp_set_object_terms( $product_id, 'simple', 'product_type' );
	wp_set_object_terms( $product_id, $term_id, 'product_cat' );
	update_post_meta( $product_id, '_regular_price', '0' );
	update_post_meta( $product_id, '_price', '0' );
	update_post_meta( $product_id, '_virtual', 'yes' );
	update_post_meta( $product_id, '_downloadable', 'yes' );
	update_post_meta( $product_id, '_stock_status', 'instock' );
	update_post_meta( $product_id, '_hello_child_freepdf_sample', '1' );

	// 커스텀 메타박스 데이터 (싱글 프로덕트 템플릿에서 렌더링)
	update_post_meta( $product_id, '_sp_why', array(
		'title' => '마케팅, 어디서부터 시작할지 모르겠다면.',
		'body'  => '블로그, SNS, 광고, 이메일… 너무 많은 채널 앞에서 막막하셨죠? 이 가이드북은 "지금 당장 뭘 해야 하는지"에 집중합니다. 30페이지로 온라인 마케팅의 전체 그림을 잡고, 내 비즈니스에 맞는 첫 번째 액션 플랜을 세울 수 있습니다.',
	) );

	update_post_meta( $product_id, '_sp_benefits', array(
		array( 'icon' => 'file-text', 'title' => 'PDF 가이드북 30페이지', 'desc' => '핵심만 담은 실전 마케팅 입문서. 다운로드 즉시 읽기 시작.' ),
		array( 'icon' => 'check-square', 'title' => '마케팅 체크리스트', 'desc' => '오늘 바로 실행할 수 있는 10가지 액션 아이템.' ),
		array( 'icon' => 'trending-up', 'title' => '퍼널 설계 템플릿', 'desc' => '방문자 → 리드 → 고객 전환 흐름을 한 장으로 정리.' ),
		array( 'icon' => 'users', 'title' => '성공 사례 3건', 'desc' => '실제 소규모 비즈니스의 마케팅 성과 사례.' ),
	) );

	// 디폴트 이미지 업로드 (VOD 상품과 동일 방식)
	$img_dir      = get_stylesheet_directory() . '/assets/images/';
	$target_imgs  = array();
	$target_files = array( '2123043-3.jpg', '2123043-1.jpg', '2123043.jpg' );

	require_once ABSPATH . 'wp-admin/includes/image.php';

	foreach ( $target_files as $file ) {
		$path = $img_dir . $file;
		if ( file_exists( $path ) ) {
			$upload_dir = wp_upload_dir();
			$dest       = $upload_dir['path'] . '/' . $file;
			if ( ! file_exists( $dest ) ) {
				@copy( $path, $dest );
			}
			if ( file_exists( $dest ) ) {
				$existing = get_posts( array(
					'post_type'  => 'attachment',
					'meta_key'   => '_wp_attached_file',
					'meta_value' => basename( $dest ),
					'numberposts' => 1,
					'fields'     => 'ids',
				) );
				if ( ! empty( $existing ) ) {
					$target_imgs[] = $existing[0];
				} else {
					$attach_id = wp_insert_attachment( array(
						'post_mime_type' => 'image/jpeg',
						'post_title'     => pathinfo( $file, PATHINFO_FILENAME ),
						'post_status'    => 'inherit',
					), $dest );
					$metadata = wp_generate_attachment_metadata( $attach_id, $dest );
					wp_update_attachment_metadata( $attach_id, $metadata );
					$target_imgs[] = $attach_id;
				}
			}
		}
	}

	$fp_img1 = $target_imgs[0] ?? 0;
	$fp_img2 = $target_imgs[1] ?? 0;
	$fp_img3 = $target_imgs[2] ?? 0;
	$fp_img4 = $target_imgs[0] ?? 0;

	update_post_meta( $product_id, '_sp_targets', array(
		array( 'img_id' => $fp_img1, 'text' => '온라인 마케팅을 처음 시작하는 분' ),
		array( 'img_id' => $fp_img2, 'text' => '블로그·SNS를 하고 있지만 성과가 없는 분' ),
		array( 'img_id' => $fp_img3, 'text' => '부업·창업을 준비 중인 분' ),
		array( 'img_id' => $fp_img4, 'text' => '마케팅 외주 전 기초를 잡고 싶은 분' ),
	) );

	update_post_meta( $product_id, '_sp_faq', array(
		array( 'q' => '정말 무료인가요?', 'a' => '네. 카카오 로그인만 하시면 바로 다운로드할 수 있습니다. 별도 결제는 없습니다.' ),
		array( 'q' => '어떤 내용이 담겨있나요?', 'a' => '온라인 마케팅 전체 구조, 퍼널 설계 기초, 콘텐츠 마케팅 시작법, 광고 기초, 실행 체크리스트가 포함됩니다.' ),
		array( 'q' => '카카오 로그인은 왜 필요한가요?', 'a' => '다운로드 링크를 안전하게 전달하고, 향후 유용한 마케팅 정보를 보내드리기 위해 필요합니다.' ),
	) );
}

/* =============================================================================
   freepdf 기존 상품 — 디폴트 이미지 없으면 자동 채움 (일회성)
   ============================================================================= */

add_action( 'admin_init', 'hello_child_freepdf_backfill_target_images' );
function hello_child_freepdf_backfill_target_images() {
	if ( get_option( 'hello_child_freepdf_img_backfilled' ) ) {
		return;
	}

	$freepdf_products = get_posts( array(
		'post_type'   => 'product',
		'tax_query'   => array( array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => 'freepdf' ) ),
		'numberposts' => -1,
		'fields'      => 'ids',
	) );

	if ( empty( $freepdf_products ) ) {
		return;
	}

	$img_dir      = get_stylesheet_directory() . '/assets/images/';
	$target_files = array( '2123043-3.jpg', '2123043-1.jpg', '2123043.jpg' );
	$target_imgs  = array();

	require_once ABSPATH . 'wp-admin/includes/image.php';

	foreach ( $target_files as $file ) {
		$path = $img_dir . $file;
		if ( ! file_exists( $path ) ) { continue; }
		$upload_dir = wp_upload_dir();
		$dest       = $upload_dir['path'] . '/' . $file;
		if ( ! file_exists( $dest ) ) { @copy( $path, $dest ); }
		if ( ! file_exists( $dest ) ) { continue; }

		// 기존 attachment 재사용
		$existing = get_posts( array(
			'post_type'   => 'attachment',
			'post_status' => 'inherit',
			'title'       => pathinfo( $file, PATHINFO_FILENAME ),
			'numberposts' => 1,
			'fields'      => 'ids',
		) );
		if ( ! empty( $existing ) ) {
			$target_imgs[] = $existing[0];
		} else {
			$attach_id = wp_insert_attachment( array(
				'post_mime_type' => 'image/jpeg',
				'post_title'     => pathinfo( $file, PATHINFO_FILENAME ),
				'post_status'    => 'inherit',
			), $dest );
			wp_update_attachment_metadata( $attach_id, wp_generate_attachment_metadata( $attach_id, $dest ) );
			$target_imgs[] = $attach_id;
		}
	}

	if ( empty( $target_imgs ) ) { return; }

	$imgs = array(
		$target_imgs[0] ?? 0,
		$target_imgs[1] ?? 0,
		$target_imgs[2] ?? 0,
		$target_imgs[0] ?? 0,
	);

	foreach ( $freepdf_products as $pid ) {
		$targets = get_post_meta( $pid, '_sp_targets', true );
		if ( ! is_array( $targets ) ) { continue; }
		$needs_update = false;
		foreach ( $targets as &$t ) {
			if ( empty( $t['img_id'] ) || $t['img_id'] == 0 ) {
				$needs_update = true;
			}
		}
		if ( $needs_update ) {
			foreach ( $targets as $i => &$t ) {
				$t['img_id'] = $imgs[ $i ] ?? $imgs[0];
			}
			update_post_meta( $pid, '_sp_targets', $targets );
		}
	}

	update_option( 'hello_child_freepdf_img_backfilled', true, false );
}

/* =============================================================================
   무료 다운로드 판별 — freepdf 카테고리 OR 할인가 0원 downloadable 상품
   ============================================================================= */

function hello_child_is_free_download( $product ) {
	if ( has_term( 'freepdf', 'product_cat', $product->get_id() ) ) {
		return true;
	}
	if ( $product->is_downloadable() && (float) $product->get_price() === 0.0 ) {
		return true;
	}
	return false;
}

/* =============================================================================
   무료 PDF — 가격 "무료" 표시 + 구매 버튼 교체 (Elementor 호환)
   ============================================================================= */

add_filter( 'body_class', 'hello_child_freepdf_body_class' );
function hello_child_freepdf_body_class( $classes ) {
	if ( is_singular( 'product' ) ) {
		$product = wc_get_product( get_the_ID() );
		if ( $product && hello_child_is_free_download( $product ) ) {
			$classes[] = 'is-freepdf';
		}
	}
	return $classes;
}

add_filter( 'woocommerce_get_price_html', 'hello_child_freepdf_price_html', 20, 2 );
function hello_child_freepdf_price_html( $price_html, $product ) {
	if ( ! hello_child_is_free_download( $product ) ) {
		return $price_html;
	}
	$regular = (float) $product->get_regular_price();
	if ( $regular > 0 ) {
		return '<span style="display:inline-flex;align-items:center;gap:8px;">'
			. '<del style="color:#999;font-size:0.9em;">' . wp_kses_post( wc_price( $regular ) ) . '</del>'
			. '<span class="sp-freepdf-price-free" style="font-size:1.4em;font-weight:800;color:#6C5CE7;">무료</span>'
			. '</span>';
	}
	return '<span class="sp-freepdf-price-free" style="font-size:1.4em;font-weight:800;color:#6C5CE7;">무료</span>';
}

add_filter( 'woocommerce_product_get_price', 'hello_child_freepdf_ensure_price', 20, 2 );
function hello_child_freepdf_ensure_price( $price, $product ) {
	if ( $price === '' && has_term( 'freepdf', 'product_cat', $product->get_id() ) ) { // keep has_term to avoid recursion
		return '0';
	}
	return $price;
}

add_filter( 'woocommerce_loop_add_to_cart_link', 'hello_child_freepdf_loop_btn', 20, 2 );
function hello_child_freepdf_loop_btn( $html, $product ) {
	if ( hello_child_is_free_download( $product ) ) {
		$url = add_query_arg( 'freepdf', $product->get_id(), home_url( '/freepdf-download/' ) );
		return '<a href="' . esc_url( $url ) . '" class="button sp-freepdf-btn--loop">무료 신청</a>';
	}
	return $html;
}

add_action( 'woocommerce_before_add_to_cart_form', 'hello_child_freepdf_replace_cart_form' );
function hello_child_freepdf_replace_cart_form() {
	global $product;
	if ( ! $product || ! hello_child_is_free_download( $product ) ) {
		return;
	}

	$product_id = $product->get_id();

	if ( is_user_logged_in() ) {
		$url = add_query_arg( 'freepdf', $product_id, home_url( '/freepdf-download/' ) );
		echo '<div class="sp-freepdf-cta">';
		echo '<a href="' . esc_url( $url ) . '" class="button sp-freepdf-btn sp-freepdf-btn--download">';
		echo '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>';
		echo ' 무료 신청</a></div>';
	} else {
		$redirect  = add_query_arg( 'freepdf', $product_id, home_url( '/freepdf-download/' ) );
		$login_url = add_query_arg( 'redirect', urlencode( $redirect ), home_url( '/klogin' ) );
		echo '<div class="sp-freepdf-cta">';
		echo '<a href="' . esc_url( $login_url ) . '" class="button sp-freepdf-btn sp-freepdf-btn--kakao">';
		echo '<svg width="20" height="20" viewBox="0 0 256 256"><path fill="#3C1E1E" d="M128 36C70.562 36 24 72.713 24 118c0 29.279 19.466 54.97 48.748 69.477-1.593 5.494-10.237 35.344-10.581 37.689 0 0-.207 1.762.934 2.434s2.483.15 2.483.15c3.272-.457 37.943-24.811 43.944-29.03 5.995.849 12.168 1.28 18.472 1.28 57.438 0 104-36.712 104-82c0-45.287-46.562-82-104-82"/></svg>';
		echo ' 카카오 로그인 후 다운로드</a></div>';
	}

	// 기본 add-to-cart 폼 숨기기 + 가격 "무료" 삽입
	?>
	<style>
	body.is-freepdf .elementor-add-to-cart form.cart,
	body.is-freepdf form.cart,
	body.is-freepdf .single_add_to_cart_button { display: none !important; height: 0 !important; overflow: hidden !important; visibility: hidden !important; }
	.sp-freepdf-cta .sp-freepdf-btn { display: inline-flex; align-items: center; gap: 8px; padding: 14px 28px; border-radius: 10px; font-size: 15px; font-weight: 700; text-decoration: none; transition: background 0.15s; }
	.sp-freepdf-btn--kakao { background: #FEE500 !important; color: #191919 !important; }
	.sp-freepdf-btn--kakao:hover { background: #F0D800 !important; }
	.sp-freepdf-btn--download { background: #6C5CE7 !important; color: #fff !important; }
	.sp-freepdf-btn--download:hover { background: #5A4BD1 !important; }
	</style>
	<script>
	document.addEventListener('DOMContentLoaded', function() {
		// 모든 cart 폼 숨기기
		document.querySelectorAll('form.cart').forEach(function(f) {
			f.style.display = 'none';
		});
		// "클래스 판매가" 라벨 뒤에 "무료" 삽입
		var label = document.querySelector('.elementor-element-sp_sidebar_price_label');
		if (label && !document.querySelector('.sp-freepdf-price-injected')) {
			var priceDiv = document.createElement('div');
			priceDiv.className = 'sp-freepdf-price-injected';
			priceDiv.style.cssText = 'font-size:1.6em;font-weight:800;color:#6C5CE7;margin:8px 0 16px;';
			priceDiv.textContent = '무료';
			label.after(priceDiv);
		}
	});
	</script>
	<?php
}

/* =============================================================================
   무료 PDF 다운로드 — 카카오 로그인 후 자동 주문 + 즉시 다운로드
   /freepdf-download/?freepdf={product_id} 엔드포인트
   ============================================================================= */

add_action( 'init', 'hello_child_freepdf_rewrite' );
function hello_child_freepdf_rewrite() {
	add_rewrite_rule( '^freepdf-download/?$', 'index.php?hc_freepdf_download=1', 'top' );
}

add_filter( 'query_vars', 'hello_child_freepdf_query_vars' );
function hello_child_freepdf_query_vars( $vars ) {
	$vars[] = 'hc_freepdf_download';
	return $vars;
}

add_action( 'template_redirect', 'hello_child_freepdf_handle', 5 );
function hello_child_freepdf_handle() {
	if ( ! get_query_var( 'hc_freepdf_download' ) ) {
		return;
	}

	// 로그인 필수
	if ( ! is_user_logged_in() ) {
		$product_id = isset( $_GET['freepdf'] ) ? (int) $_GET['freepdf'] : 0;
		$redirect   = add_query_arg( 'freepdf', $product_id, home_url( '/freepdf-download/' ) );
		wp_redirect( add_query_arg( 'redirect', urlencode( $redirect ), home_url( '/klogin' ) ) );
		exit;
	}

	$product_id = isset( $_GET['freepdf'] ) ? (int) $_GET['freepdf'] : 0;
	$product    = wc_get_product( $product_id );

	if ( ! $product || ! hello_child_is_free_download( $product ) ) {
		wp_redirect( home_url( '/shop/' ) );
		exit;
	}

	$user_id = get_current_user_id();

	$downloads_url = wc_get_endpoint_url( 'downloads', '', wc_get_page_permalink( 'myaccount' ) );

	// 중복 주문 방지: 이미 completed 주문이 있으면 다운로드 페이지로
	$existing_order = hello_child_freepdf_find_existing_order( $user_id, $product_id );
	if ( $existing_order ) {
		wp_redirect( $downloads_url );
		exit;
	}

	// 자동 주문 생성 (checkout/payment 완전 우회)
	$order = wc_create_order( array( 'customer_id' => $user_id ) );
	$order->add_product( $product, 1 );
	$order->set_total( 0 );
	$order->set_payment_method( '' );
	$order->set_payment_method_title( '무료 다운로드' );

	// 사용자 빌링 정보 설정
	$user = get_userdata( $user_id );
	$order->set_billing_email( $user->user_email );
	$order->set_billing_first_name( $user->display_name );

	$order->set_status( 'completed', '무료 PDF 자동 주문 (카카오 로그인)' );
	$order->save();

	// WooCommerce 다운로드 권한 부여
	wc_downloadable_product_permissions( $order->get_id() );

	wp_redirect( $downloads_url );
	exit;
}

/**
 * 동일 사용자 + 동일 freepdf 상품의 기존 completed 주문 조회
 */
function hello_child_freepdf_find_existing_order( $user_id, $product_id ) {
	$orders = wc_get_orders( array(
		'customer_id' => $user_id,
		'status'      => 'completed',
		'limit'       => -1,
	) );

	foreach ( $orders as $order ) {
		foreach ( $order->get_items() as $item ) {
			if ( $item->get_product_id() === $product_id ) {
				return $order;
			}
		}
	}

	return null;
}

