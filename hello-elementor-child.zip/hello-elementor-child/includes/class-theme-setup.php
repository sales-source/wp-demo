<?php
/**
 * 테마 활성화 시 기본 페이지 자동 생성
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hello_Child_Theme_Setup {

	/**
	 * 생성할 Elementor Theme Builder 템플릿 목록
	 */
	private static $templates = [
		'header' => [
			'title'         => '헤더',
			'template_file' => 'includes/templates/header.php',
			'type'          => 'header',
			'location'      => 'header',
			'conditions'    => [ 'include/general' ],
		],
		'footer' => [
			'title'         => '푸터',
			'template_file' => 'includes/templates/footer.php',
			'type'          => 'footer',
			'location'      => 'footer',
			'conditions'    => [ 'include/general' ],
		],
	];

	/**
	 * 생성할 페이지 목록 (slug => 설정)
	 */
	private static $pages = [
		// 옛 'home' 페이지 (terra_home_* 숏코드 기반) 는 home-v2 로 교체되어 자동 생성 대상에서 제외.
		// shortcode-home.php 자체는 호환을 위해 유지하지만, theme 활성화 시 새 home 페이지를 만들지 않음.
		'home-v2' => [
			'title'         => 'Home',
			'template'      => 'includes/templates/home-v2.php',
			'page_template' => 'elementor_header_footer',
			'show_on_front' => true,
		],
		'terms' => [
			'title'    => '이용약관',
			'content'  => true,
		],
		'privacy' => [
			'title'    => '개인정보 처리방침',
			'content'  => true,
		],
	];

	/**
	 * 초기화
	 */
	public static function init() {
		add_action( 'after_switch_theme', [ __CLASS__, 'setup_pages' ] );
		// elementor 로드 후 페이지/템플릿 생성 재시도 (첫 활성화 시 elementor 미로드 케이스)
		add_action( 'admin_init', [ __CLASS__, 'setup_pages' ], 20 );
		add_action( 'admin_init', [ __CLASS__, 'ensure_templates' ], 30 );
		add_action( 'admin_notices', [ __CLASS__, 'admin_notice' ] );
	}

	/**
	 * Theme Builder 헤더/푸터 템플릿이 누락된 경우 자동 복구
	 *
	 * 활성화 시 500 에러 등으로 템플릿 생성이 실패했을 때
	 * admin 접속 시 자동으로 재생성한다.
	 */
	public static function ensure_templates() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		foreach ( self::$templates as $key => $config ) {
			$existing = get_posts( [
				'post_type'      => 'elementor_library',
				'post_status'    => 'publish',
				'title'          => $config['title'],
				'posts_per_page' => 1,
			] );

			if ( empty( $existing ) ) {
				try {
					self::create_theme_template( $key, $config );
				} catch ( \Throwable $e ) {
					error_log( 'Hello Child: ensure_templates ' . $key . ' failed — ' . $e->getMessage() );
				}
			}
		}
	}

	/**
	 * 테마 활성화 시 / admin_init 시 페이지 생성
	 *
	 * 검수 미통과 #132 / #129:
	 * - 기존 hello_child_pages_created 옵션 존재만으로 early-return 하던 가드를 제거.
	 *   해당 옵션이 남아있는 사이트에서 home-v2 페이지가 누락되는 문제가 있었음
	 *   (휴지통 이동 / 수동 삭제 / 예전 install 잔여 등). 이제 옵션이 있어도 페이지별
	 *   존재 여부를 확인해 누락된 것만 재생성한다.
	 * - 추가로 슬러그 'home' (옛 home 페이지) 이 휴지통에 남아있는 경우 영구 삭제.
	 *   옛 home 은 home-v2 로 완전히 대체되었으므로 보존할 필요 없음.
	 */
	public static function setup_pages() {
		// Elementor 활성화 확인
		if ( ! did_action( 'elementor/loaded' ) ) {
			set_transient( 'hello_child_need_elementor', true, 60 );
			return;
		}

		// 옛 'home' 페이지 영구 삭제 (휴지통/publish/draft 모두)
		$old_homes = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft', 'trash', 'private', 'pending', 'future' ),
			'name'           => 'home',
			'posts_per_page' => -1,
		) );
		foreach ( $old_homes as $old_home ) {
			wp_delete_post( $old_home->ID, true );
		}

		$created = get_option( 'hello_child_pages_created', array() );
		if ( ! is_array( $created ) ) {
			$created = array();
		}

		foreach ( self::$pages as $slug => $config ) {
			// 기존 옵션에 기록된 ID 가 여전히 유효하고 publish 상태인지 확인
			$recorded_id = isset( $created[ $slug ] ) ? (int) $created[ $slug ] : 0;
			if ( $recorded_id && 'page' === get_post_type( $recorded_id ) && 'publish' === get_post_status( $recorded_id ) ) {
				continue;
			}

			try {
				$page_id = self::create_page( $slug, $config );
				if ( $page_id ) {
					$created[ $slug ] = $page_id;
				}
			} catch ( \Throwable $e ) {
				error_log( 'Hello Child Theme setup_pages: ' . $slug . ' failed — ' . $e->getMessage() );
			}
		}

		// Theme Builder 템플릿 생성
		foreach ( self::$templates as $key => $config ) {
			try {
				$tpl_id = self::create_theme_template( $key, $config );
				if ( $tpl_id ) {
					$created[ 'tpl_' . $key ] = $tpl_id;
				}
			} catch ( \Throwable $e ) {
				error_log( 'Hello Child Theme setup_pages: template ' . $key . ' failed — ' . $e->getMessage() );
			}
		}

		// Elementor Kit 글로벌 색상/폰트를 테마 디자인 토큰과 동기화
		try {
			self::sync_elementor_kit_globals();
		} catch ( \Throwable $e ) {
			error_log( 'Hello Child Theme: sync_elementor_kit_globals failed — ' . $e->getMessage() );
		}

		if ( ! empty( $created ) ) {
			update_option( 'hello_child_pages_created', $created );
		}
	}

	/**
	 * Elementor Kit 글로벌 색상 & 타이포그래피를 테마 디자인 토큰과 동기화
	 *
	 * global.css의 CSS custom properties와 동일한 값을 Elementor Kit에 설정.
	 * Elementor 편집기에서도 테마와 동일한 색상/폰트가 표시됨.
	 */
	public static function sync_elementor_kit_globals() {
		$kit_id = get_option( 'elementor_active_kit' );
		if ( ! $kit_id ) {
			return;
		}

		$settings = get_post_meta( $kit_id, '_elementor_page_settings', true );
		if ( ! is_array( $settings ) ) {
			$settings = [];
		}

		// ── 글로벌 색상 (Elementor 시스템 4색) ──
		$settings['system_colors'] = [
			[
				'_id'   => 'primary',
				'title' => 'Primary',
				'color' => '#000000',
			],
			[
				'_id'   => 'secondary',
				'title' => 'Secondary',
				'color' => '#191F28',
			],
			[
				'_id'   => 'text',
				'title' => 'Text',
				'color' => '#4E5968',
			],
			[
				'_id'   => 'accent',
				'title' => 'Accent',
				'color' => '#0064FF',
			],
		];

		// ── 커스텀 색상 (테마 디자인 토큰 확장) ──
		$settings['custom_colors'] = [
			[
				'_id'   => 'hc_success',
				'title' => 'Success',
				'color' => '#00C471',
			],
			[
				'_id'   => 'hc_warning',
				'title' => 'Warning',
				'color' => '#FF9500',
			],
			[
				'_id'   => 'hc_error',
				'title' => 'Error',
				'color' => '#F04452',
			],
			[
				'_id'   => 'hc_bg_secondary',
				'title' => 'Background',
				'color' => '#F8F9FA',
			],
			[
				'_id'   => 'hc_border',
				'title' => 'Border',
				'color' => '#E5E8EB',
			],
			[
				'_id'   => 'hc_text_muted',
				'title' => 'Text Muted',
				'color' => '#8B95A1',
			],
			[
				'_id'   => 'hc_dark_bg',
				'title' => 'Dark BG',
				'color' => '#191F28',
			],
		];

		// ── 글로벌 타이포그래피 (Pretendard) ──
		$pretendard_base = [
			'typography_typography'   => 'custom',
			'typography_font_family'  => 'Pretendard',
			'typography_font_weight'  => '400',
		];

		$settings['system_typography'] = [
			array_merge( $pretendard_base, [
				'_id'                    => 'primary',
				'title'                  => 'Primary',
				'typography_font_weight' => '700',
			] ),
			array_merge( $pretendard_base, [
				'_id'                    => 'secondary',
				'title'                  => 'Secondary',
				'typography_font_weight' => '600',
			] ),
			array_merge( $pretendard_base, [
				'_id'   => 'text',
				'title' => 'Text',
			] ),
			array_merge( $pretendard_base, [
				'_id'                    => 'accent',
				'title'                  => 'Accent',
				'typography_font_weight' => '500',
			] ),
		];

		// ── body 기본 타이포그래피 ──
		$settings['body_typography_typography']  = 'custom';
		$settings['body_typography_font_family'] = 'Pretendard';
		$settings['body_typography_font_weight'] = '400';
		$settings['body_typography_font_size']   = [ 'unit' => 'px', 'size' => 15, 'sizes' => [] ];
		$settings['body_typography_line_height'] = [ 'unit' => 'em', 'size' => 1.6, 'sizes' => [] ];
		$settings['body_color']                  = '#191F28';

		// ── 링크 색상 ──
		$settings['link_normal_color'] = '#0064FF';
		$settings['link_hover_color']  = '#0050CC';

		update_post_meta( $kit_id, '_elementor_page_settings', $settings );

		// Elementor CSS 캐시 초기화 (새 설정 반영)
		delete_post_meta( $kit_id, '_elementor_css' );
	}

	/**
	 * 개별 페이지 생성
	 */
	private static function create_page( $slug, $config ) {
		// 동일 slug 페이지가 이미 있으면 건너뜀
		$existing = get_page_by_path( $slug );
		if ( $existing ) {
			// 일반 텍스트 페이지 (Elementor 미사용)
			if ( ! empty( $config['content'] ) ) {
				$content_file = HELLO_CHILD_DIR . '/includes/pages/' . basename( $slug ) . '.php';
				if ( file_exists( $content_file ) ) {
					$html = include $content_file;
					if ( is_string( $html ) ) {
						wp_update_post( [ 'ID' => $existing->ID, 'post_content' => $html ] );
					}
				}
				return $existing->ID;
			}
			// Elementor 편집 가능 페이지 또는 기타 템플릿
			if ( ! empty( $config['elementor'] ) ) {
				// Elementor 데이터가 없을 때만 초기 데이터 삽입 (사용자 편집 보존)
				$existing_data = get_post_meta( $existing->ID, '_elementor_data', true );
				if ( empty( $existing_data ) ) {
					self::set_elementor_shortcode( $existing->ID, $config['elementor'] );
				}
			} elseif ( ! empty( $config['template'] ) ) {
				// Elementor data file: 사용자 편집 보존을 위해 데이터 없을 때만 초기화
				$existing_data = get_post_meta( $existing->ID, '_elementor_data', true );
				if ( empty( $existing_data ) ) {
					self::set_elementor_data( $existing->ID, $config['template'] );
				}
			}
			// page_template 은 template 와 독립적으로 항상 적용 (canvas 등)
			if ( ! empty( $config['page_template'] ) ) {
				update_post_meta( $existing->ID, '_wp_page_template', $config['page_template'] );
			}
			if ( ! empty( $config['show_on_front'] ) ) {
				self::set_front_page( $existing->ID );
			}
			return $existing->ID;
		}

		$post_args = [
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $config['title'],
			'post_name'    => basename( $slug ),
			'post_content' => '',
		];

		// 부모 페이지 설정
		if ( ! empty( $config['parent'] ) ) {
			$parent_page = get_page_by_path( $config['parent'] );
			if ( $parent_page ) {
				$post_args['post_parent'] = $parent_page->ID;
			}
		}

		$page_id = wp_insert_post( $post_args );

		if ( is_wp_error( $page_id ) ) {
			return false;
		}

		// 일반 텍스트 페이지 (Elementor 미사용)
		if ( ! empty( $config['content'] ) ) {
			$content_file = HELLO_CHILD_DIR . '/includes/pages/' . basename( $slug ) . '.php';
			if ( file_exists( $content_file ) ) {
				$html = include $content_file;
				if ( is_string( $html ) ) {
					wp_update_post( [ 'ID' => $page_id, 'post_content' => $html ] );
				}
			}
			return $page_id;
		}

		// Elementor 편집 가능 페이지 (숏코드 위젯으로 초기 콘텐츠 삽입)
		if ( ! empty( $config['elementor'] ) ) {
			self::set_elementor_shortcode( $page_id, $config['elementor'] );
		} elseif ( ! empty( $config['template'] ) ) {
			self::set_elementor_data( $page_id, $config['template'] );
		}
		// page_template 은 template 와 독립적으로 적용 (예: elementor_canvas)
		if ( ! empty( $config['page_template'] ) ) {
			update_post_meta( $page_id, '_wp_page_template', $config['page_template'] );
		}

		if ( ! empty( $config['show_on_front'] ) ) {
			self::set_front_page( $page_id );
		}

		return $page_id;
	}

	/**
	 * Elementor Theme Builder 템플릿 생성
	 *
	 * Lock 메커니즘:
	 * - hello_child_template_locked='yes' 옵션이 있으면 기존 _elementor_data를
	 *   덮어쓰지 않음 (사용자가 Elementor에서 직접 편집한 내용 보존)
	 * - 단, 템플릿이 아예 없는 경우(첫 활성화)는 PHP 파일에서 새로 생성
	 */
	private static function create_theme_template( $key, $config ) {
		// 동일 제목 템플릿이 이미 있으면 업데이트만
		$existing = get_posts( [
			'post_type'      => 'elementor_library',
			'post_status'    => 'publish',
			'title'          => $config['title'],
			'posts_per_page' => 1,
		] );

		$is_new = empty( $existing );

		if ( ! $is_new ) {
			$post_id = $existing[0]->ID;

			// Lock 활성화 + 기존 템플릿 → _elementor_data 덮어쓰지 않음
			if ( 'yes' === get_option( 'hello_child_template_locked', 'no' ) ) {
				// Theme Builder 위치/조건만 보장 (디자인은 사용자 편집 유지)
				update_post_meta( $post_id, '_elementor_location', $config['location'] );
				if ( ! empty( $config['conditions'] ) ) {
					update_post_meta( $post_id, '_elementor_conditions', $config['conditions'] );
					$pro_conditions = get_option( 'elementor_pro_theme_builder_conditions', [] );
					$pro_conditions[ $config['type'] ][ $post_id ] = $config['conditions'];
					update_option( 'elementor_pro_theme_builder_conditions', $pro_conditions );
				}
				return $post_id;
			}
		} else {
			$post_id = wp_insert_post( [
				'post_type'    => 'elementor_library',
				'post_status'  => 'publish',
				'post_title'   => $config['title'],
				'post_content' => '',
			] );

			if ( is_wp_error( $post_id ) ) {
				return false;
			}
		}

		$template_path = HELLO_CHILD_DIR . '/' . $config['template_file'];
		if ( ! file_exists( $template_path ) ) {
			return false;
		}

		$elementor_data = include $template_path;
		if ( ! is_array( $elementor_data ) ) {
			return false;
		}

		// 메뉴 ID 플레이스홀더를 실제 ID로 치환
		$json = wp_json_encode( $elementor_data );
		$header_menu = wp_get_nav_menu_object( '주메뉴' );
		$footer_menu = wp_get_nav_menu_object( '푸터메뉴' );
		if ( $header_menu ) {
			$json = str_replace( '__HEADER_MENU__', (string) $header_menu->term_id, $json );
		}
		if ( $footer_menu ) {
			$json = str_replace( '__FOOTER_MENU__', (string) $footer_menu->term_id, $json );
		}

		// Elementor 메타 설정
		update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) );
		update_post_meta( $post_id, '_elementor_version', '3.35.0' );
		update_post_meta( $post_id, '_elementor_template_type', $config['type'] );

		// Theme Builder 위치/조건 설정
		update_post_meta( $post_id, '_elementor_location', $config['location'] );

		// Elementor Pro conditions 설정
		if ( ! empty( $config['conditions'] ) ) {
			update_post_meta( $post_id, '_elementor_conditions', $config['conditions'] );
		}

		// Taxonomy 설정 (elementor_library_type)
		wp_set_object_terms( $post_id, $config['type'], 'elementor_library_type' );

		// Elementor Pro Theme Builder conditions 옵션에도 등록 (프론트 편집 아이콘 표시 필수)
		if ( ! empty( $config['conditions'] ) ) {
			$pro_conditions = get_option( 'elementor_pro_theme_builder_conditions', [] );
			$pro_conditions[ $config['type'] ][ $post_id ] = $config['conditions'];
			update_option( 'elementor_pro_theme_builder_conditions', $pro_conditions );
		}

		return $post_id;
	}

	/**
	 * Elementor 데이터를 페이지에 설정
	 */
	private static function set_elementor_data( $post_id, $template_file ) {
		$template_path = HELLO_CHILD_DIR . '/' . $template_file;

		if ( ! file_exists( $template_path ) ) {
			return;
		}

		$elementor_data = include $template_path;

		if ( ! is_array( $elementor_data ) ) {
			return;
		}

		update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $elementor_data ) ) );
		update_post_meta( $post_id, '_elementor_version', '3.35.0' );
		update_post_meta( $post_id, '_elementor_template_type', 'wp-page' );
		update_post_meta( $post_id, '_wp_page_template', 'elementor_header_footer' );
	}

	/**
	 * Elementor 숏코드 위젯으로 페이지 초기화
	 *
	 * 문자열이면 단일 숏코드, 배열이면 섹션별 숏코드로 분리.
	 * 사용자가 Elementor에서 편집하면 네이티브 위젯으로 교체 가능.
	 */
	private static function set_elementor_shortcode( $post_id, $shortcodes ) {
		if ( is_string( $shortcodes ) ) {
			$shortcodes = [ $shortcodes ];
		}

		$elementor_data = [];

		foreach ( $shortcodes as $shortcode ) {
			$section_id = substr( md5( uniqid( mt_rand(), true ) ), 0, 8 );
			$column_id  = substr( md5( uniqid( mt_rand(), true ) ), 0, 8 );
			$element_id = substr( md5( uniqid( mt_rand(), true ) ), 0, 8 );

			$elementor_data[] = [
				'id'       => $section_id,
				'elType'   => 'section',
				'settings' => [
					'layout'  => 'full_width',
					'gap'     => 'no',
					'padding' => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true ],
				],
				'elements' => [
					[
						'id'       => $column_id,
						'elType'   => 'column',
						'settings' => [ '_column_size' => 100 ],
						'elements' => [
							[
								'id'         => $element_id,
								'elType'     => 'widget',
								'widgetType' => 'shortcode',
								'settings'   => [ 'shortcode' => $shortcode ],
								'elements'   => [],
								'isInner'    => false,
							],
						],
						'isInner' => false,
					],
				],
				'isInner' => false,
			];
		}

		update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $elementor_data ) ) );
		update_post_meta( $post_id, '_elementor_version', '3.35.0' );
		update_post_meta( $post_id, '_elementor_template_type', 'wp-page' );
		update_post_meta( $post_id, '_wp_page_template', 'elementor_header_footer' );
	}

	/**
	 * 프론트 페이지로 설정
	 */
	private static function set_front_page( $page_id ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $page_id );
	}

	/**
	 * Elementor 미설치 안내
	 */
	public static function admin_notice() {
		if ( get_transient( 'hello_child_need_elementor' ) ) {
			echo '<div class="notice notice-warning is-dismissible">';
			echo '<p><strong>Hello Elementor Child:</strong> Elementor 플러그인을 활성화한 후 테마를 다시 활성화해주세요.</p>';
			echo '</div>';
			delete_transient( 'hello_child_need_elementor' );
		}
	}

	/**
	 * 페이지 재생성 (수동 트리거용)
	 * wp option delete hello_child_pages_created 후 테마 재활성화
	 */
	public static function reset() {
		delete_option( 'hello_child_pages_created' );
	}
}
