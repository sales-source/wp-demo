<?php
/**
 * 메인 페이지 섹션별 숏코드
 *
 * 10개 섹션이 독립 숏코드로 분리되어 Elementor에서 개별 편집/재배치 가능.
 * [terra_home_hero], [terra_home_stats], [terra_home_problem], [terra_home_solution],
 * [terra_home_roadmap], [terra_home_courses], [terra_home_freepdf], [terra_home_blog],
 * [terra_home_faq], [terra_home_cta]
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 스타일은 한 번만 로드
add_action( 'wp_head', 'hello_child_home_styles' );
function hello_child_home_styles() {
	if ( ! is_front_page() ) return;
	// home-v2 페이지는 home-v2.css 가 처리하므로 옛 inline CSS 를 inject 하지 않음.
	// home-v2 는 .hc-freepdf-cover 를 블루톤으로 정의하는데, 이 옛 CSS 의 녹색 버전이
	// wp_head 출력 순서상 나중에 로드되어 home-v2.css 를 override 하던 문제 방지.
	$front_id = (int) get_option( 'page_on_front' );
	if ( $front_id ) {
		$front = get_post( $front_id );
		if ( $front && 'home-v2' === $front->post_name ) {
			return;
		}
	}
	?>
<style>
/* ══════════════════════════════════════════════
   Home Page Styles — 기존 디자인 토큰 기반
   ══════════════════════════════════════════════ */

.hc-home *,
.hc-home *::before,
.hc-home *::after { box-sizing: border-box; }

.hc-home {
	font-family: var(--font-family, 'Pretendard', -apple-system, sans-serif);
	color: var(--color-text-primary, #191F28);
	line-height: 1.6;
	-webkit-font-smoothing: antialiased;
}

/* ── Section Base ── */
.hc-section {
	padding: 100px 40px;
}
.hc-section-inner {
	max-width: 1100px;
	margin: 0 auto;
}
.hc-section-narrow {
	max-width: 800px;
	margin: 0 auto;
}
.hc-section-label {
	font-size: 13px;
	font-weight: 700;
	letter-spacing: 3px;
	text-transform: uppercase;
	text-align: center;
	margin-bottom: 8px;
}
.hc-section-title {
	font-size: 32px;
	font-weight: 700;
	text-align: center;
	line-height: 1.4;
	margin-bottom: 8px;
}
.hc-section-desc {
	font-size: 16px;
	color: var(--color-text-tertiary, #8B95A1);
	text-align: center;
	margin-bottom: 48px;
}
.hc-text-center { text-align: center; }

/* ── Hero ── */
.hc-hero {
	position: relative;
	background: linear-gradient(160deg, #F0F4FF 0%, #FFFFFF 50%, #E8F0FE 100%);
	padding: 120px 40px 100px;
	text-align: center;
	overflow: hidden;
}
.hc-hero::before {
	content: '';
	position: absolute;
	top: -200px;
	right: -200px;
	width: 600px;
	height: 600px;
	background: radial-gradient(circle, rgba(0,100,255,0.06) 0%, transparent 70%);
	border-radius: 50%;
}
.hc-hero::after {
	content: '';
	position: absolute;
	bottom: -150px;
	left: -150px;
	width: 400px;
	height: 400px;
	background: radial-gradient(circle, rgba(0,196,113,0.05) 0%, transparent 70%);
	border-radius: 50%;
}
.hc-hero-badge {
	display: inline-block;
	font-size: 13px;
	font-weight: 600;
	color: var(--color-primary, #0064FF);
	background: var(--color-primary-light, #E8F0FE);
	padding: 6px 16px;
	border-radius: 20px;
	margin-bottom: 24px;
	letter-spacing: 0.5px;
}
.hc-hero-title {
	font-size: 48px;
	font-weight: 800;
	color: var(--color-text-primary, #191F28);
	line-height: 1.3;
	margin-bottom: 16px;
	position: relative;
	z-index: 1;
}
.hc-hero-title span {
	color: var(--color-primary, #0064FF);
}
.hc-hero-sub {
	font-size: 18px;
	font-weight: 400;
	color: var(--color-text-secondary, #4E5968);
	line-height: 1.7;
	margin-bottom: 36px;
	position: relative;
	z-index: 1;
}
.hc-hero-buttons {
	display: flex;
	gap: 16px;
	justify-content: center;
	flex-wrap: wrap;
	margin-bottom: 16px;
	position: relative;
	z-index: 1;
}
.hc-hero-micro {
	font-size: 13px;
	color: var(--color-text-tertiary, #8B95A1);
	position: relative;
	z-index: 1;
}

/* ── Buttons ── */
.hc-btn-primary,
a.hc-btn-primary,
a.hc-btn-primary:visited {
	display: inline-flex;
	align-items: center;
	gap: 8px;
	padding: 14px 32px;
	background: var(--color-primary, #0064FF) !important;
	color: #fff !important;
	font-size: 16px;
	font-weight: 600;
	border-radius: 30px;
	text-decoration: none !important;
	transition: background 0.2s, transform 0.15s;
	cursor: pointer;
	border: none;
}
.hc-btn-primary:hover,
a.hc-btn-primary:hover {
	background: var(--color-primary-hover, #0050CC) !important;
	color: #fff !important;
	transform: translateY(-1px);
}
.hc-btn-secondary {
	display: inline-flex;
	align-items: center;
	gap: 8px;
	padding: 14px 32px;
	background: transparent;
	color: var(--color-text-primary, #191F28);
	font-size: 16px;
	font-weight: 600;
	border: 1px solid var(--color-border, #E5E8EB);
	border-radius: 30px;
	text-decoration: none;
	transition: border-color 0.2s, background 0.2s;
	cursor: pointer;
}
.hc-btn-secondary:hover {
	border-color: var(--color-primary, #0064FF);
	background: var(--color-primary-light, #E8F0FE);
	color: var(--color-primary, #0064FF);
}
.hc-btn-success {
	display: inline-flex;
	align-items: center;
	gap: 8px;
	padding: 14px 32px;
	background: var(--color-success, #00C471);
	color: #FFFFFF;
	font-size: 16px;
	font-weight: 600;
	border-radius: 30px;
	text-decoration: none;
	transition: opacity 0.2s, transform 0.15s;
	cursor: pointer;
	border: none;
}
.hc-btn-success:hover {
	opacity: 0.9;
	transform: translateY(-1px);
}
.hc-btn-outline {
	display: inline-flex;
	align-items: center;
	gap: 6px;
	padding: 10px 24px;
	background: transparent;
	font-size: 15px;
	font-weight: 600;
	border: 1px solid var(--color-primary, #0064FF);
	color: var(--color-primary, #0064FF);
	border-radius: 8px;
	text-decoration: none;
	transition: background 0.15s;
	cursor: pointer;
}
.hc-btn-outline:hover {
	background: var(--color-primary-light, #E8F0FE);
}

/* ── Social Proof ── */
.hc-stats {
	background: var(--color-bg-primary, #fff);
	border-bottom: 1px solid var(--color-border, #E5E8EB);
	padding: 60px 40px;
}
.hc-stats-grid {
	max-width: 1100px;
	margin: 0 auto;
	display: grid;
	grid-template-columns: repeat(4, 1fr);
	gap: 24px;
	text-align: center;
}
.hc-stat-number {
	font-size: 40px;
	font-weight: 800;
	color: var(--color-primary, #0064FF);
	line-height: 1.2;
}
.hc-stat-label {
	font-size: 14px;
	font-weight: 500;
	color: var(--color-text-secondary, #4E5968);
	margin-top: 4px;
}

/* ── Problem Section ── */
.hc-problem {
	background: var(--color-bg-secondary, #F8F9FA);
}
.hc-problem-grid {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 20px;
	margin-top: 48px;
}
.hc-problem-card {
	background: var(--color-bg-primary, #fff);
	border-radius: 16px;
	padding: 32px 28px;
	border: 1px solid var(--color-border, #E5E8EB);
	text-align: center;
}
.hc-problem-icon {
	width: 56px;
	height: 56px;
	border-radius: 14px;
	display: flex;
	align-items: center;
	justify-content: center;
	margin: 0 auto 20px;
	background: #FEF2F2;
}
.hc-problem-icon svg {
	width: 28px;
	height: 28px;
	color: #EF4444;
}
.hc-problem-card h4 {
	font-size: 17px;
	font-weight: 700;
	color: var(--color-text-primary, #191F28);
	margin-bottom: 8px;
}
.hc-problem-card p {
	font-size: 14px;
	color: var(--color-text-tertiary, #8B95A1);
	line-height: 1.6;
}

/* ── Solution Section ── */
.hc-solution {
	background: var(--color-bg-primary, #fff);
}
.hc-solution-grid {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 20px;
	margin-top: 48px;
}
.hc-solution-card {
	background: var(--color-primary-light, #E8F0FE);
	border-radius: 16px;
	padding: 32px 28px;
	border: 1px solid transparent;
	text-align: center;
	transition: box-shadow 0.2s;
}
.hc-solution-card:hover {
	box-shadow: 0 8px 32px rgba(0,100,255,0.08);
}
.hc-solution-icon {
	width: 56px;
	height: 56px;
	border-radius: 14px;
	display: flex;
	align-items: center;
	justify-content: center;
	margin: 0 auto 20px;
	background: var(--color-primary, #0064FF);
}
.hc-solution-icon svg {
	width: 28px;
	height: 28px;
	color: #fff;
}
.hc-solution-card h4 {
	font-size: 17px;
	font-weight: 700;
	color: var(--color-text-primary, #191F28);
	margin-bottom: 8px;
}
.hc-solution-card p {
	font-size: 14px;
	color: var(--color-text-secondary, #4E5968);
	line-height: 1.6;
}

/* ── Roadmap ── */
.hc-roadmap {
	background: var(--color-bg-secondary, #F8F9FA);
}
.hc-roadmap-steps {
	display: flex;
	gap: 0;
	margin-top: 48px;
	position: relative;
}
.hc-roadmap-step {
	flex: 1;
	text-align: center;
	padding: 0 16px;
	position: relative;
}
.hc-roadmap-step::after {
	content: '';
	position: absolute;
	top: 28px;
	right: -50%;
	width: 100%;
	height: 2px;
	background: var(--color-border, #E5E8EB);
	z-index: 0;
}
.hc-roadmap-step:last-child::after {
	display: none;
}
.hc-roadmap-num {
	width: 56px;
	height: 56px;
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
	margin: 0 auto 16px;
	font-size: 20px;
	font-weight: 800;
	position: relative;
	z-index: 1;
	transition: transform 0.2s;
}
.hc-roadmap-step:hover .hc-roadmap-num {
	transform: scale(1.1);
}
.hc-roadmap-step:nth-child(1) .hc-roadmap-num { background: #E8FBF0; color: #00C471; }
.hc-roadmap-step:nth-child(2) .hc-roadmap-num { background: var(--color-primary-light, #E8F0FE); color: var(--color-primary, #0064FF); }
.hc-roadmap-step:nth-child(3) .hc-roadmap-num { background: #FFF4E8; color: #FF9500; }
.hc-roadmap-step:nth-child(4) .hc-roadmap-num { background: #F3E8FF; color: #8B5CF6; }
.hc-roadmap-step:nth-child(5) .hc-roadmap-num { background: #FEE2E2; color: #EF4444; }
.hc-roadmap-tag {
	display: inline-block;
	font-size: 11px;
	font-weight: 700;
	letter-spacing: 1px;
	text-transform: uppercase;
	margin-bottom: 8px;
}
.hc-roadmap-step:nth-child(1) .hc-roadmap-tag { color: #00C471; }
.hc-roadmap-step:nth-child(2) .hc-roadmap-tag { color: var(--color-primary, #0064FF); }
.hc-roadmap-step:nth-child(3) .hc-roadmap-tag { color: #FF9500; }
.hc-roadmap-step:nth-child(4) .hc-roadmap-tag { color: #8B5CF6; }
.hc-roadmap-step:nth-child(5) .hc-roadmap-tag { color: #EF4444; }
.hc-roadmap-step h4 {
	font-size: 16px;
	font-weight: 700;
	color: var(--color-text-primary, #191F28);
	margin-bottom: 6px;
}
.hc-roadmap-step p {
	font-size: 13px;
	color: var(--color-text-tertiary, #8B95A1);
	line-height: 1.5;
}

/* ── Courses ── */
.hc-courses {
	background: var(--color-bg-primary, #fff);
}
.hc-courses-grid {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 24px;
	margin-bottom: 32px;
}
.hc-course-card {
	background: var(--color-bg-secondary, #F8F9FA);
	border-radius: 12px;
	border: 1px solid var(--color-border, #E5E8EB);
	overflow: hidden;
	transition: box-shadow 0.2s, transform 0.2s;
	cursor: pointer;
	text-decoration: none;
	color: inherit;
	display: block;
}
.hc-course-card:hover {
	box-shadow: 0 8px 32px rgba(0,0,0,0.08);
	transform: translateY(-2px);
}
.hc-course-thumb {
	width: 100%;
	aspect-ratio: 16/9;
	object-fit: cover;
	display: block;
	background: var(--color-bg-tertiary, #F2F4F6);
}
.hc-course-thumb-placeholder {
	width: 100%;
	aspect-ratio: 16/9;
	display: flex;
	align-items: center;
	justify-content: center;
	background: linear-gradient(135deg, var(--color-primary-light, #E8F0FE), var(--color-bg-tertiary, #F2F4F6));
}
.hc-course-thumb-placeholder svg {
	width: 48px;
	height: 48px;
	color: var(--color-primary, #0064FF);
	opacity: 0.5;
}
.hc-course-body {
	padding: 20px 24px 24px;
}
.hc-course-badge {
	display: inline-block;
	font-size: 12px;
	font-weight: 600;
	padding: 3px 10px;
	border-radius: 20px;
	margin-bottom: 12px;
}
.hc-badge-blue { background: var(--color-primary-light, #E8F0FE); color: var(--color-primary, #0064FF); }
.hc-badge-orange { background: #FFF4E8; color: #FF9500; }
.hc-badge-green { background: #E8FBF0; color: #00C471; }
.hc-course-card h3 {
	font-size: 18px;
	font-weight: 700;
	color: var(--color-text-primary, #191F28);
	line-height: 1.4;
	margin-bottom: 8px;
}
.hc-course-card .hc-course-excerpt {
	font-size: 14px;
	color: var(--color-text-tertiary, #8B95A1);
	line-height: 1.6;
	margin-bottom: 16px;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	overflow: hidden;
}
.hc-course-meta {
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-size: 14px;
}
.hc-course-price {
	font-weight: 700;
	color: var(--color-primary, #0064FF);
}
.hc-course-price del {
	color: var(--color-text-tertiary, #8B95A1);
	font-weight: 400;
	font-size: 13px;
	margin-right: 6px;
}

/* ── Free PDF ── */
.hc-freepdf {
	background: linear-gradient(160deg, #F0FDF4 0%, #FFFFFF 40%, #E8F0FE 100%);
	position: relative;
	overflow: hidden;
}
.hc-freepdf::before {
	content: '';
	position: absolute;
	top: -100px;
	right: -100px;
	width: 400px;
	height: 400px;
	background: radial-gradient(circle, rgba(0,196,113,0.08) 0%, transparent 70%);
	border-radius: 50%;
}
.hc-freepdf-grid {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 60px;
	align-items: center;
}
.hc-freepdf-left {
	position: relative;
	z-index: 1;
}
.hc-freepdf-left h2 {
	font-size: 32px;
	font-weight: 700;
	color: var(--color-text-primary, #191F28);
	line-height: 1.4;
	margin-bottom: 12px;
}
.hc-freepdf-left h2 span {
	color: var(--color-success, #00C471);
}
.hc-freepdf-left > p {
	font-size: 16px;
	color: var(--color-text-secondary, #4E5968);
	line-height: 1.7;
	margin-bottom: 28px;
}
.hc-freepdf-features {
	list-style: none;
	padding: 0;
	margin: 0 0 32px;
}
.hc-freepdf-features li {
	display: flex;
	align-items: flex-start;
	gap: 12px;
	margin-bottom: 14px;
	font-size: 15px;
	color: var(--color-text-secondary, #4E5968);
	line-height: 1.5;
}
.hc-freepdf-features li svg {
	flex-shrink: 0;
	width: 20px;
	height: 20px;
	color: var(--color-success, #00C471);
	margin-top: 2px;
}
.hc-freepdf-right {
	position: relative;
	z-index: 1;
}
.hc-freepdf-cover {
	background: linear-gradient(145deg, #00C471, #00A85D);
	border-radius: 20px;
	padding: 48px 40px;
	color: #fff;
	text-align: center;
	box-shadow: 0 20px 60px rgba(0,196,113,0.2);
	position: relative;
	overflow: hidden;
}
.hc-freepdf-cover::before {
	content: '';
	position: absolute;
	top: -30px;
	right: -30px;
	width: 120px;
	height: 120px;
	background: rgba(255,255,255,0.1);
	border-radius: 50%;
}
.hc-freepdf-cover::after {
	content: '';
	position: absolute;
	bottom: -20px;
	left: -20px;
	width: 80px;
	height: 80px;
	background: rgba(255,255,255,0.08);
	border-radius: 50%;
}
.hc-freepdf-cover-tag {
	display: inline-block;
	font-size: 12px;
	font-weight: 700;
	letter-spacing: 2px;
	text-transform: uppercase;
	background: rgba(255,255,255,0.2);
	padding: 4px 14px;
	border-radius: 20px;
	margin-bottom: 24px;
}
.hc-freepdf-cover h3 {
	font-size: 24px;
	font-weight: 800;
	line-height: 1.4;
	margin-bottom: 12px;
	position: relative;
	z-index: 1;
}
.hc-freepdf-cover p {
	font-size: 14px;
	opacity: 0.85;
	line-height: 1.6;
	position: relative;
	z-index: 1;
}
.hc-freepdf-cover-icon {
	margin: 24px auto 0;
	width: 64px;
	height: 64px;
	background: rgba(255,255,255,0.2);
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
	position: relative;
	z-index: 1;
}
.hc-freepdf-cover-icon svg {
	width: 28px;
	height: 28px;
	color: #fff;
}
.hc-freepdf-checklist {
	list-style: none;
	padding: 0;
	margin: 24px 0 0;
	text-align: left;
	border-top: 1px solid rgba(255,255,255,0.2);
	padding-top: 20px;
}
.hc-freepdf-checklist li {
	display: flex;
	align-items: flex-start;
	gap: 10px;
	margin-bottom: 12px;
	font-size: 14px;
	color: rgba(255,255,255,0.9);
	line-height: 1.5;
}
.hc-freepdf-checklist li svg {
	flex-shrink: 0;
	width: 18px;
	height: 18px;
	color: #fff;
	margin-top: 2px;
}
.hc-freepdf-micro {
	font-size: 13px;
	color: var(--color-text-tertiary, #8B95A1);
	margin-top: 12px;
}

/* ── Blog ── */
.hc-blog {
	background: var(--color-bg-primary, #fff);
}
.hc-blog-grid {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 24px;
	margin-bottom: 32px;
}
.hc-blog-card {
	background: var(--color-bg-secondary, #F8F9FA);
	border-radius: 12px;
	border: 1px solid var(--color-border, #E5E8EB);
	overflow: hidden;
	transition: box-shadow 0.2s, transform 0.2s;
	cursor: pointer;
	text-decoration: none;
	color: inherit;
	display: block;
}
.hc-blog-card:hover {
	box-shadow: 0 8px 32px rgba(0,0,0,0.08);
	transform: translateY(-2px);
}
.hc-blog-thumb {
	width: 100%;
	aspect-ratio: 16/9;
	object-fit: cover;
	display: block;
	background: var(--color-bg-tertiary, #F2F4F6);
}
.hc-blog-thumb-placeholder {
	width: 100%;
	aspect-ratio: 16/9;
	display: flex;
	align-items: center;
	justify-content: center;
	background: linear-gradient(135deg, var(--color-bg-tertiary, #F2F4F6), var(--color-bg-secondary, #F8F9FA));
}
.hc-blog-thumb-placeholder svg {
	width: 40px;
	height: 40px;
	color: var(--color-text-tertiary, #8B95A1);
	opacity: 0.4;
}
.hc-blog-body {
	padding: 20px 24px 24px;
}
.hc-blog-category {
	font-size: 12px;
	color: var(--color-primary, #0064FF);
	font-weight: 600;
	margin-bottom: 8px;
}
.hc-blog-card h4 {
	font-size: 17px;
	font-weight: 700;
	color: var(--color-text-primary, #191F28);
	line-height: 1.5;
	margin-bottom: 8px;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	overflow: hidden;
}
.hc-blog-card .hc-blog-excerpt {
	font-size: 14px;
	color: var(--color-text-tertiary, #8B95A1);
	line-height: 1.6;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	overflow: hidden;
}

/* ── FAQ ── */
.hc-faq {
	background: var(--color-bg-secondary, #F8F9FA);
}
.hc-faq-item {
	border-bottom: 1px solid var(--color-border, #E5E8EB);
	padding: 20px 0;
}
.hc-faq-q {
	font-size: 16px;
	font-weight: 600;
	color: var(--color-text-primary, #191F28);
	cursor: pointer;
	display: flex;
	justify-content: space-between;
	align-items: center;
	background: none;
	border: none;
	width: 100%;
	text-align: left;
	padding: 0;
	font-family: inherit;
}
.hc-faq-q::after {
	content: '+';
	font-size: 20px;
	color: var(--color-text-tertiary, #8B95A1);
	transition: transform 0.2s;
	flex-shrink: 0;
	margin-left: 16px;
}
.hc-faq-item.open .hc-faq-q::after {
	content: '\2212';
}
.hc-faq-a {
	font-size: 14px;
	color: var(--color-text-secondary, #4E5968);
	line-height: 1.7;
	padding-top: 12px;
	display: none;
}
.hc-faq-item.open .hc-faq-a { display: block; }

/* ── Final CTA ── */
.hc-final-cta {
	background: linear-gradient(160deg, #191F28, #0A1628);
	padding: 120px 40px;
	text-align: center;
}
.hc-final-cta h2 {
	font-size: 36px;
	font-weight: 700;
	color: #fff;
	margin-bottom: 12px;
}
.hc-final-cta p {
	font-size: 16px;
	color: #B0B8C1;
	line-height: 1.7;
	margin-bottom: 32px;
}
.hc-final-cta .hc-btn-primary { background: var(--color-primary, #0064FF); }
.hc-final-cta .hc-btn-secondary {
	color: #fff;
	border-color: rgba(255,255,255,0.3);
}
.hc-final-cta .hc-btn-secondary:hover {
	border-color: rgba(255,255,255,0.6);
	background: rgba(255,255,255,0.05);
	color: #fff;
}

/* ── Responsive ── */
@media (max-width: 768px) {
	.hc-hero { padding: 80px 20px 60px; }
	.hc-hero-title { font-size: 28px; }
	.hc-hero-sub { font-size: 15px; }
	.hc-hero-buttons { flex-direction: column; align-items: center; }
	.hc-section { padding: 60px 20px; }
	.hc-section-title { font-size: 24px; }
	.hc-stats { padding: 40px 20px; }
	.hc-stats-grid { grid-template-columns: repeat(2, 1fr); gap: 24px; }
	.hc-stat-number { font-size: 28px; }
	.hc-problem-grid,
	.hc-solution-grid,
	.hc-courses-grid,
	.hc-blog-grid { grid-template-columns: 1fr; }
	.hc-roadmap-steps {
		flex-direction: column;
		gap: 24px;
	}
	.hc-roadmap-step::after { display: none; }
	.hc-roadmap-step { padding: 0; }
	.hc-freepdf-grid { grid-template-columns: 1fr; gap: 32px; }
	.hc-freepdf-left h2 { font-size: 24px; }
	.hc-final-cta { padding: 80px 20px; }
	.hc-final-cta h2 { font-size: 24px; }
}
</style>
	<?php
}

// 동적 데이터 수집 (섹션별 공유)
function _hello_child_home_data() {
	static $data = null;
	if ( $data !== null ) return $data;
	$data = array();
	$data['courses'] = get_posts( array(
		'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 3,
		'tax_query' => array( array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => 'vod' ) ),
		'meta_key' => '_price', 'orderby' => 'meta_value_num', 'order' => 'ASC',
	) );
	$data['blog_posts'] = get_posts( array(
		'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 3,
		'orderby' => 'date', 'order' => 'DESC',
	) );
	$freepdf = get_posts( array(
		'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 1,
		'tax_query' => array( array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => 'freepdf' ) ),
	) );
	$data['freepdf_product'] = ! empty( $freepdf ) ? $freepdf[0] : null;
	return $data;
}

add_shortcode( 'terra_home_hero', 'hello_child_home_hero_shortcode' );
function hello_child_home_hero_shortcode() {
	$d = _hello_child_home_data();
	$courses = $d['courses'];
	$blog_posts = $d['blog_posts'];
	$freepdf_product = $d['freepdf_product'];
	ob_start();
	?>
<!-- ═══ HERO ═══ -->
<section class="hc-hero">
	<div class="hc-section-narrow">
		<div class="hc-hero-badge">온라인 강의 + 마케팅 퍼널, 올인원 솔루션</div>
		<h1 class="hc-hero-title">배우고, 실행하고,<br><span>성과를 만드세요</span></h1>
		<p class="hc-hero-sub">무료 전자책부터 VOD 강의, 실시간 세션, 1:1 컨설팅까지<br>온라인 마케팅의 모든 여정을 한 곳에서 완성합니다.</p>
		<div class="hc-hero-buttons">
			<?php
			$hero_freepdf_url = $freepdf_product
				? get_permalink( $freepdf_product->ID )
				: home_url( '/freepdf/' );
			?>
			<a href="<?php echo esc_url( $hero_freepdf_url ); ?>" class="hc-btn-primary">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
				무료 가이드북 받기
			</a>
			<a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>" class="hc-btn-secondary">강의 둘러보기</a>
		</div>
		<p class="hc-hero-micro">카카오 로그인 한 번으로 바로 다운로드</p>
	</div>
</section>
	<?php
	return ob_get_clean();
}

add_shortcode( 'terra_home_stats', 'hello_child_home_stats_shortcode' );
function hello_child_home_stats_shortcode() {
	ob_start();
	?>
<section class="hc-stats">
	<div class="hc-stats-grid">
		<div>
			<div class="hc-stat-number">1,200+</div>
			<div class="hc-stat-label">누적 수강생</div>
		</div>
		<div>
			<div class="hc-stat-number">96%</div>
			<div class="hc-stat-label">수강 만족도</div>
		</div>
		<div>
			<div class="hc-stat-number">50+</div>
			<div class="hc-stat-label">VOD 강의</div>
		</div>
		<div>
			<div class="hc-stat-number">4.9</div>
			<div class="hc-stat-label">평균 평점</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

add_shortcode( 'terra_home_problem', 'hello_child_home_problem_shortcode' );
function hello_child_home_problem_shortcode() {
	ob_start();
	?>
<section class="hc-section hc-problem">
	<div class="hc-section-inner">
		<div class="hc-section-label" style="color:var(--color-error, #F04452);">PROBLEM</div>
		<h2 class="hc-section-title">이런 고민, 하고 계시지 않나요?</h2>
		<p class="hc-section-desc">온라인 마케팅을 시작하려는 많은 분들이 같은 벽에 부딪힙니다.</p>

		<div class="hc-problem-grid">
			<div class="hc-problem-card">
				<div class="hc-problem-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
				</div>
				<h4>어디서부터 시작해야 할지 모르겠다</h4>
				<p>블로그, SNS, 광고, 이메일... 정보는 넘치는데 뭘 먼저 해야 할지 막막합니다.</p>
			</div>
			<div class="hc-problem-card">
				<div class="hc-problem-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="9" y1="12" x2="15" y2="12"/></svg>
				</div>
				<h4>배워도 실행으로 연결이 안 된다</h4>
				<p>강의는 들었는데 실제 내 사업에 적용하면 막히고, 결국 포기하게 됩니다.</p>
			</div>
			<div class="hc-problem-card">
				<div class="hc-problem-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
				</div>
				<h4>여러 툴을 따로 써야 해서 비효율적이다</h4>
				<p>강의 플랫폼, 결제, 이메일, 커뮤니티를 각각 다른 서비스에서 관리하느라 지칩니다.</p>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

add_shortcode( 'terra_home_solution', 'hello_child_home_solution_shortcode' );
function hello_child_home_solution_shortcode() {
	ob_start();
	?>
<section class="hc-section hc-solution">
	<div class="hc-section-inner">
		<div class="hc-section-label" style="color:var(--color-primary, #0064FF);">SOLUTION</div>
		<h2 class="hc-section-title">여기서 한번에 해결됩니다</h2>
		<p class="hc-section-desc">흩어진 도구들을 하나로 통합하고, 단계별로 안내합니다.</p>

		<div class="hc-solution-grid">
			<div class="hc-solution-card">
				<div class="hc-solution-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
				</div>
				<h4>단계별 학습 로드맵</h4>
				<p>입문부터 고급까지, 내 수준에 맞는 커리큘럼을 따라가면 자연스럽게 실력이 쌓입니다.</p>
			</div>
			<div class="hc-solution-card">
				<div class="hc-solution-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
				</div>
				<h4>실행 중심 실습</h4>
				<p>이론이 아닌 실제 마케팅 시스템을 직접 구축하며 배웁니다. 수강 후 바로 적용 가능.</p>
			</div>
			<div class="hc-solution-card">
				<div class="hc-solution-icon">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
				</div>
				<h4>올인원 플랫폼</h4>
				<p>강의, 결제, 마케팅 자동화, 수강생 관리까지 하나의 사이트에서 모두 해결됩니다.</p>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

add_shortcode( 'terra_home_roadmap', 'hello_child_home_roadmap_shortcode' );
function hello_child_home_roadmap_shortcode() {
	ob_start();
	?>
<section class="hc-section hc-roadmap">
	<div class="hc-section-inner">
		<div class="hc-section-label" style="color:var(--color-primary, #0064FF);">ROADMAP</div>
		<h2 class="hc-section-title">학습 로드맵</h2>
		<p class="hc-section-desc">무료 자료부터 1:1 컨설팅까지, 단계별로 성장하는 구조입니다.</p>

		<div class="hc-roadmap-steps">
			<div class="hc-roadmap-step">
				<div class="hc-roadmap-num">1</div>
				<div class="hc-roadmap-tag">Free</div>
				<h4>무료 전자책</h4>
				<p>마케팅 기초 가이드를<br>PDF로 먼저 체험하세요</p>
			</div>
			<div class="hc-roadmap-step">
				<div class="hc-roadmap-num">2</div>
				<div class="hc-roadmap-tag">VOD</div>
				<h4>유료 강의</h4>
				<p>입문~고급 VOD 강의로<br>체계적으로 학습합니다</p>
			</div>
			<div class="hc-roadmap-step">
				<div class="hc-roadmap-num">3</div>
				<div class="hc-roadmap-tag">Live</div>
				<h4>실시간 강의</h4>
				<p>라이브 세션으로 직접<br>질문하고 피드백 받으세요</p>
			</div>
			<div class="hc-roadmap-step">
				<div class="hc-roadmap-num">4</div>
				<div class="hc-roadmap-tag">Community</div>
				<h4>수강생 소통</h4>
				<p>동료 수강생과 경험을<br>나누며 함께 성장합니다</p>
			</div>
			<div class="hc-roadmap-step">
				<div class="hc-roadmap-num">5</div>
				<div class="hc-roadmap-tag">Premium</div>
				<h4>1:1 컨설팅</h4>
				<p>내 비즈니스에 맞는<br>맞춤 전략을 설계합니다</p>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

add_shortcode( 'terra_home_courses', 'hello_child_home_courses_shortcode' );
function hello_child_home_courses_shortcode() {
	$d = _hello_child_home_data();
	$courses = $d['courses'];
	$blog_posts = $d['blog_posts'];
	$freepdf_product = $d['freepdf_product'];
	ob_start();
	?>
<section class="hc-section hc-courses">
	<div class="hc-section-inner">
		<div class="hc-section-label" style="color:var(--color-primary, #0064FF);">COURSES</div>
		<h2 class="hc-section-title">체계적으로 배우고, 바로 실행하세요</h2>
		<p class="hc-section-desc">실전 중심 커리큘럼으로 지식을 성과로 전환합니다.</p>

		<div class="hc-courses-grid">
			<?php if ( ! empty( $courses ) ) : ?>
				<?php
				$badges = array(
					0 => array( 'label' => '입문', 'class' => 'hc-badge-blue' ),
					1 => array( 'label' => '실전', 'class' => 'hc-badge-orange' ),
					2 => array( 'label' => '심화', 'class' => 'hc-badge-green' ),
				);
				foreach ( $courses as $i => $course ) :
					$thumb_id = get_post_thumbnail_id( $course->ID );
					$thumb_url = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium_large' ) : '';
					$product = wc_get_product( $course->ID );
					$badge = $badges[ $i ] ?? $badges[0];
				?>
				<a href="<?php echo esc_url( get_permalink( $course->ID ) ); ?>" class="hc-course-card">
					<?php if ( $thumb_url ) : ?>
						<img class="hc-course-thumb" src="<?php echo esc_url( $thumb_url ); ?>" alt="<?php echo esc_attr( $course->post_title ); ?>" loading="lazy">
					<?php else : ?>
						<div class="hc-course-thumb-placeholder">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
						</div>
					<?php endif; ?>
					<div class="hc-course-body">
						<span class="hc-course-badge <?php echo esc_attr( $badge['class'] ); ?>"><?php echo esc_html( $badge['label'] ); ?></span>
						<h3><?php echo esc_html( $course->post_title ); ?></h3>
						<p class="hc-course-excerpt"><?php echo esc_html( wp_strip_all_tags( $course->post_excerpt ) ); ?></p>
						<div class="hc-course-meta">
							<?php if ( $product ) : ?>
								<span class="hc-course-price">
									<?php if ( $product->get_sale_price() ) : ?>
										<del><?php echo wp_kses_post( wc_price( $product->get_regular_price() ) ); ?></del>
										<?php echo wp_kses_post( wc_price( $product->get_sale_price() ) ); ?>
									<?php else : ?>
										<?php echo wp_kses_post( $product->get_price_html() ); ?>
									<?php endif; ?>
								</span>
							<?php endif; ?>
						</div>
					</div>
				</a>
				<?php endforeach; ?>
			<?php else : ?>
				<div class="hc-course-card" style="grid-column: 1/-1; text-align:center; padding:60px 20px;">
					<p style="color:var(--color-text-tertiary);">강의가 준비 중입니다. 곧 만나보실 수 있습니다.</p>
				</div>
			<?php endif; ?>
		</div>
		<div class="hc-text-center">
			<a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>" class="hc-btn-outline">전체 강의 보기 →</a>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

add_shortcode( 'terra_home_freepdf', 'hello_child_home_freepdf_shortcode' );
function hello_child_home_freepdf_shortcode() {
	$d = _hello_child_home_data();
	$courses = $d['courses'];
	$blog_posts = $d['blog_posts'];
	$freepdf_product = $d['freepdf_product'];
	ob_start();
	?>
<section class="hc-section hc-freepdf">
	<div class="hc-section-inner">
		<div class="hc-freepdf-grid">
			<div class="hc-freepdf-left">
				<div class="hc-section-label" style="color:var(--color-success, #00C471);text-align:left;">FREE DOWNLOAD</div>
				<h2>마케팅, 어디서부터 시작할지<br>모르겠다면 <span>이 가이드북</span>부터</h2>
				<p>온라인 마케팅 기초부터 퍼널 설계까지, 실전 로드맵을 PDF로 정리했습니다. 카카오 로그인 한 번으로 바로 다운로드하세요.</p>
				<?php
				$freepdf_url = $freepdf_product
					? get_permalink( $freepdf_product->ID )
					: home_url( '/freepdf/' );
				?>
				<a href="<?php echo esc_url( $freepdf_url ); ?>" class="hc-btn-success">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
					무료 가이드북 받기
				</a>
				<p class="hc-freepdf-micro">이미 850명이 다운로드했습니다</p>
			</div>
			<div class="hc-freepdf-right">
				<div class="hc-freepdf-cover" style="text-align:left;">
					<div class="hc-freepdf-cover-tag">FREE GUIDE</div>
					<h3><?php echo $freepdf_product ? esc_html( $freepdf_product->post_title ) : '온라인 마케팅 무료 가이드북'; ?></h3>
					<ul class="hc-freepdf-checklist">
						<li>
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
							수익화 가능한 주제 선정법
						</li>
						<li>
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
							무료 콘텐츠 → 유료 전환 퍼널 구조
						</li>
						<li>
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
							첫 고객 100명 모집 실전 전략
						</li>
						<li>
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
							마케팅 자동화 시작 가이드
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

add_shortcode( 'terra_home_blog', 'hello_child_home_blog_shortcode' );
function hello_child_home_blog_shortcode() {
	$d = _hello_child_home_data();
	$courses = $d['courses'];
	$blog_posts = $d['blog_posts'];
	$freepdf_product = $d['freepdf_product'];
	ob_start();
	?>
<section class="hc-section hc-blog">
	<div class="hc-section-inner">
		<div class="hc-section-label" style="color:var(--color-primary, #0064FF);">BLOG</div>
		<h2 class="hc-section-title">마케팅에 필요한 인사이트</h2>
		<p class="hc-section-desc">온라인 비즈니스, 마케팅, 콘텐츠 전략에 관한 실전 노하우를 공유합니다.</p>

		<div class="hc-blog-grid">
			<?php if ( ! empty( $blog_posts ) ) : ?>
				<?php foreach ( $blog_posts as $bp ) :
					$thumb_id  = get_post_thumbnail_id( $bp->ID );
					$thumb_url = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium_large' ) : '';
					$cats      = get_the_category( $bp->ID );
					$cat_name  = ! empty( $cats ) ? $cats[0]->name : '';
				?>
				<a href="<?php echo esc_url( get_permalink( $bp->ID ) ); ?>" class="hc-blog-card">
					<?php if ( $thumb_url ) : ?>
						<img class="hc-blog-thumb" src="<?php echo esc_url( $thumb_url ); ?>" alt="<?php echo esc_attr( $bp->post_title ); ?>" loading="lazy">
					<?php else : ?>
						<div class="hc-blog-thumb-placeholder">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
						</div>
					<?php endif; ?>
					<div class="hc-blog-body">
						<?php if ( $cat_name ) : ?>
							<div class="hc-blog-category"><?php echo esc_html( $cat_name ); ?></div>
						<?php endif; ?>
						<h4><?php echo esc_html( $bp->post_title ); ?></h4>
						<p class="hc-blog-excerpt"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $bp->post_content ), 30, '...' ) ); ?></p>
					</div>
				</a>
				<?php endforeach; ?>
			<?php else : ?>
				<div style="grid-column: 1/-1; text-align:center; padding:60px 20px;">
					<p style="color:var(--color-text-tertiary);">블로그 글이 준비 중입니다.</p>
				</div>
			<?php endif; ?>
		</div>
		<div class="hc-text-center">
			<a href="<?php echo esc_url( home_url( '/blogs/' ) ); ?>" class="hc-btn-outline">블로그 전체 보기 →</a>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

add_shortcode( 'terra_home_faq', 'hello_child_home_faq_shortcode' );
function hello_child_home_faq_shortcode() {
	ob_start();
	?>
<section class="hc-section hc-faq">
	<div class="hc-section-narrow">
		<div class="hc-section-label" style="color:var(--color-primary, #0064FF);">FAQ</div>
		<h2 class="hc-section-title" style="margin-bottom:32px;">자주 묻는 질문</h2>

		<div class="hc-faq-item open">
			<button class="hc-faq-q" type="button">완전 초보자도 따라할 수 있나요?</button>
			<div class="hc-faq-a">네, 물론입니다. 모든 강의는 기초부터 단계별로 구성되어 있으며, 막히는 부분은 라이브 Q&A에서 바로 해결할 수 있습니다.</div>
		</div>
		<div class="hc-faq-item">
			<button class="hc-faq-q" type="button">강의는 어떤 형태로 진행되나요?</button>
			<div class="hc-faq-a">녹화 영상 강의 + 실습 자료 + 라이브 세션으로 구성됩니다. 녹화 강의는 영구 수강이며, 라이브 세션은 캘린더에서 일정을 확인하실 수 있습니다.</div>
		</div>
		<div class="hc-faq-item">
			<button class="hc-faq-q" type="button">무료로 체험해볼 수 있나요?</button>
			<div class="hc-faq-a">네, 무료 가이드북 다운로드를 통해 먼저 체험해보실 수 있습니다. 카카오 로그인 한 번이면 바로 PDF를 받을 수 있습니다.</div>
		</div>
		<div class="hc-faq-item">
			<button class="hc-faq-q" type="button">환불 정책은 어떻게 되나요?</button>
			<div class="hc-faq-a">유료 강의는 구매 후 7일 이내, 미수강 시 전액 환불이 가능합니다. 수강 시작 후에는 환불이 불가합니다.</div>
		</div>
		<div class="hc-faq-item">
			<button class="hc-faq-q" type="button">수강 기간 제한이 있나요?</button>
			<div class="hc-faq-a">모든 유료 강의는 영구 수강입니다. 한 번 구매하면 언제든 반복해서 볼 수 있습니다.</div>
		</div>
	</div>
</section>
<script>
document.addEventListener('DOMContentLoaded', function() {
	document.querySelectorAll('.hc-faq-q').forEach(function(btn) {
		btn.addEventListener('click', function() {
			this.closest('.hc-faq-item').classList.toggle('open');
		});
	});
});
</script>
	<?php
	return ob_get_clean();
}

add_shortcode( 'terra_home_cta', 'hello_child_home_cta_shortcode' );
function hello_child_home_cta_shortcode() {
	$d = _hello_child_home_data();
	$courses = $d['courses'];
	$blog_posts = $d['blog_posts'];
	$freepdf_product = $d['freepdf_product'];
	$freepdf_url = $freepdf_product ? get_permalink( $freepdf_product->ID ) : home_url( "/freepdf/" );
	ob_start();
	?>
<section class="hc-final-cta">
	<div class="hc-section-narrow">
		<h2>지금 시작하세요</h2>
		<p>무료 가이드북부터 시작해서, 강의와 실습을 통해<br>당신의 온라인 마케팅 성과를 만드는 여정을 함께합니다.</p>
		<div class="hc-hero-buttons">
			<a href="<?php echo esc_url( $freepdf_url ); ?>" class="hc-btn-primary">무료 가이드북 받기</a>
			<a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>" class="hc-btn-secondary">강의 둘러보기</a>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

// 전체 페이지 렌더링 (하위 호환)
add_shortcode( 'terra_home', 'hello_child_render_home_shortcode' );
function hello_child_render_home_shortcode() {
	$sections = array('hero','stats','problem','solution','roadmap','courses','freepdf','blog','faq','cta');
	$html = '<div class="hc-home">';
	foreach ( $sections as $s ) {
		$html .= do_shortcode( '[terra_home_' . $s . ']' );
	}
	$html .= '</div>';
	return $html;
}